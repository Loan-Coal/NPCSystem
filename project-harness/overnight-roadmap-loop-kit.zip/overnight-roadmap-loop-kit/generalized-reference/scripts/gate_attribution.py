#!/usr/bin/env python3
"""Baseline-mode handler for the tolerant per-task gate (token-free).

Owns the two operations the overnight loop asks for around a red gate, keeping them out
of `scripts/classify_gate_failure.py`, whose one job is routing a red gate to HALT or
AUTOFIX:

  * **seed** — re-run the halt-class checks ``runs`` times at a phase boundary and store
    the *union* of their failing sets as that phase's baseline. Repeated runs are what
    catch load-dependent flakes that are already red before the phase starts; a single
    run misses whichever ones happened to pass, and the phase's first task is then
    charged with them.
  * **attribute** — diff a task's current failing set against that baseline (read-only)
    and confirm the candidate-new ids by re-running them, so only failures that fail
    repeatedly are reported as task-introduced.

Nothing here writes the baseline outside an explicit seed. The old behaviour — writing
the current failing set back on every diff — meant a task that invoked the classifier a
second time diffed against its own breakage and was told it was pre-existing.

Takes its halt-check runner and its re-runner injected, so it neither imports the
classifier (no cycle) nor spawns a subprocess under unit test.
"""

from __future__ import annotations

import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path

# Run directly and Python puts scripts/ on sys.path[0], not the repo root, so the
# `scripts.` package imports below need the repo root added explicitly.
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from scripts.gate_baseline import (  # noqa: E402
    BaselineDiff,
    SeedDelta,
    collect_failing_set,
    diff_failing_set,
    diff_seeds,
    load_baseline,
    union_failing_sets,
    write_baseline,
)
from scripts.gate_confirm import Confirmation, Rerunner, confirm_new_failures  # noqa: E402

# Seed runs per phase boundary. Two is the cost/benefit knee: it catches the flakes that
# are red often enough to matter, and `scripts/gate_confirm.py` covers the tail that only
# reddens mid-phase. A third run would roughly halve the residual for another full
# halt-class run per phase.
DEFAULT_SEED_RUNS = 2

# One halt-class check result as (name, passed, output) — the shape the failing-set
# parser consumes, so the injected runner owes nothing richer.
CheckOutcome = tuple[str, bool, str]

# Injected: run every halt-class check once and return their outcomes.
HaltRunner = Callable[[], Iterable[CheckOutcome]]


@dataclass(frozen=True)
class SeedOutcome:
    """The baseline written at a phase boundary, plus how it moved since the last one."""

    failing: tuple[str, ...]
    runs: int
    delta: SeedDelta


@dataclass(frozen=True)
class Attribution:
    """A task's red attributed to pre-existing vs task-introduced, after confirmation."""

    diff: BaselineDiff
    confirmation: Confirmation

    @property
    def is_regression(self) -> bool:
        """True iff at least one candidate-new failure survived confirmation."""
        return self.confirmation.is_regression


def seed_baseline(path: str, run_halt: HaltRunner, runs: int = DEFAULT_SEED_RUNS) -> SeedOutcome:
    """Union ``runs`` halt-class runs into ``path`` as this phase's baseline."""
    previous = load_baseline(path)
    failing = union_failing_sets(collect_failing_set(run_halt()) for _ in range(max(runs, 1)))
    write_baseline(path, failing)
    return SeedOutcome(tuple(sorted(failing)), max(runs, 1), diff_seeds(failing, previous))


def attribute(current: set[str], baseline_path: str, rerun: Rerunner) -> Attribution:
    """Diff ``current`` against the stored baseline, then confirm the candidate-new ids.

    Read-only with respect to the baseline file: the verdict for a given (current,
    baseline) pair is the same however many times a task asks for it.
    """
    diff = diff_failing_set(current, load_baseline(baseline_path))
    confirmation = confirm_new_failures(set(diff.new_failures), rerun)
    return Attribution(diff, confirmation)


def format_seed_line(outcome: SeedOutcome) -> str:
    """Machine-readable seed summary. ``BASELINE_SEEDED`` leads for the loop's grep."""
    return (
        f"BASELINE_SEEDED={len(outcome.failing)} "
        f"SEED_RUNS={outcome.runs} "
        f"SEED_ENTERED={len(outcome.delta.entered)} "
        f"SEED_LEFT={len(outcome.delta.left)} "
        f"PREVIOUS_KNOWN={int(outcome.delta.previous_known)} "
        f"ENTERED_IDS={','.join(outcome.delta.entered)}"
    )


def format_attribution_line(attribution: Attribution) -> str:
    """Machine-readable attribution summary.

    ``NEW_FAILURES``/``NEW_IDS`` keep their names and their meaning for the skill — the
    failures this task is answerable for — but now count only *confirmed* ones. Cleared
    flakes are reported alongside rather than dropped, so a phase that keeps clearing the
    same ids is visible in the log instead of quietly costing two re-runs a task.
    """
    confirmation = attribution.confirmation
    return (
        f"NEW_FAILURES={len(confirmation.confirmed)} "
        f"PREEXISTING={len(attribution.diff.preexisting)} "
        f"BASELINE_KNOWN={int(attribution.diff.baseline_known)} "
        f"NEW_IDS={','.join(confirmation.confirmed)} "
        f"FLAKY_CLEARED={len(confirmation.cleared)} "
        f"CONFIRM_RERUNS={confirmation.reruns_used} "
        f"CLEARED_IDS={','.join(confirmation.cleared)}"
    )

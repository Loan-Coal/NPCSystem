# CTF Automation

Async 11-stage LLM pipeline that generates cybersecurity CTF challenges, driven by a
human curator through a FastAPI + vanilla-JS demo UI.

## Navigation

| What | Where |
|---|---|
| Development loop + hard rules | `AGENTS.md` |
| Current session state + next task | `NEXT_SESSION.md` |
| Active refactor backlog | `project_harness/ROADMAP.md` |
| Session history log | `project_harness/STATUS.md` |
| Bug log | `project_harness/ISSUES.md` |
| Architecture index | `project_harness/ARCHITECTURE.md` → `project_harness/architecture/` |
| Task skill guides | `project_harness/skills/` |
| Architecture Decision Records | `project_harness/adr/` |
| Claude Code harness detail | `.claude/PROJECT.md` |

## Non-negotiable invariants

1. **State writes go through `update_run_metadata()`** in `core/state/run_state.py` — never write `_run.json` directly; never call `write_run_metadata()` from outside that module.
2. **All JSON state files use `_write_json_atomic()`** — temp file + `Path.replace()`; no direct `write_text` to a live state path.
3. **LLM outputs are Pydantic-validated before they touch disk** — the validated model is the only thing serialized.
4. **Prompts load via `load_prompt_scaffold()`** — never hardcode prompt text in agent files.
5. **No blocking I/O in coroutines** — wrap synchronous file work in `asyncio.to_thread()`.
6. **Retry routing goes through `route_stage_for_category()`** — never branch on failure-category strings inline.
7. **Status transitions must be legal** per `_ALLOWED_STATUS_TRANSITIONS` in `run_state.py`.
8. **JS enum literals mirror `core/models/state.py`** — rename an enum and update the UI in lockstep.

## Coding principles

- No magic numbers — promote to named constants or config.
- Pydantic at every external boundary: LLM responses, state files, API bodies.
- Test the failure path before the happy path — sad-path coverage is the main gap.
- A fix that adds a new branch/condition to shared logic (e.g. an early return for a newly-handled case) must be tested together with the other conditions that function already handles, not just the new one in isolation — otherwise the new branch can silently shadow existing behavior with no test catching it. This has already happened: ISSUE-119's id-only contract branch (added 2026-07-01) silently dropped CSS-class prompt guidance for nearly every web-category run until `/pipeline-review` caught it on 2026-07-13 — three commits and ~12 days later. Fixing an issue is not done until a test proves the fix doesn't shadow a sibling case.
- One responsibility per extracted module; once `agents_src/base.py` exists, subclass its errors.
- Thread `run_id` through every async call chain for traceable logs.
- Fail fast at startup — validate config and prompt symlinks before accepting a run, not mid-run.
- State-shape changes require defaulted fields or a migration shim — never silently break old runs.
- **Advisory-first codegen gates** (strict): any NEW heuristic/proxy code-generation gate ships advisory (log-only) and is promoted to a fatal `CodeGenerationContractMismatchError` only after its false-positive rate is measured. Fatal-capable gates resolve severity through `contract_finding_policy.yaml` (default advisory) via `aggregate_contract_findings`, never a direct `raise` in the `agents_src/code_generation/_finalize.py` tail. The grandfathered high-confidence direct-raisers are a closed allowlist enforced by the structural guard in `tests/unit/test_finalize_direct_raise_guard.py`; adding a new one there fails that test. This is fix (B) of Phase 235 — the standing rule behind ISSUE-202: a blind cap-hit escalation turns any noisy fatal codegen gate into a run-ending, app-restructuring event.
- Commit messages: `<type>(phase-N.task-M): <description>`; mark the completed ROADMAP task `— ✅ DONE`, never delete it. Never mention Claude, Anthropic, or any AI tool anywhere in a commit — no `Co-Authored-By` trailers, no body references.

Rules marked **(strict)** have the same status as the non-negotiable invariants above: violating them is a bug.

### SOLID

- **SRP** (strict): every module belongs to exactly one category — data model, reader, writer, handler/orchestrator, utility, protocol, adapter, or test. Never mix.
- **OCP** (strict): new LLM backends, stage runners, or validation types are added by creating a new file. Never edit existing engine files to add a new variant.
- **DIP** (strict): orchestrator and agents import protocol/abstract types, never concrete adapter classes. All concrete dependencies are injected via function parameters or `__init__`.
- **ISP** (strict): protocols must be small. If not all implementors need a method, split the protocol. Do not add streaming to a protocol if some adapters cannot stream.
- **LSP** (strict): mock adapters must match the real adapter's behavior contract. If `MockLLMClient.generate()` returns `""` for empty input but real adapters raise, that mock is invalid and will produce false-passing tests.

### Structure

- **File length** (strict): no code file may exceed 300 lines. Split into focused modules when the limit is reached.
- **Function length** (strict): no function or method may exceed 40 lines.
- **Nesting** (strict): control-flow nesting (`if`/`for`/`try`) must not exceed 3 levels. Extract inner blocks into named helpers.
- **No magic numbers or strings** (strict): every constant must be named (`ALL_CAPS` module-level or a config key). No raw numeric thresholds. No raw string literals for stage names, status values, or failure categories.

### Types and models

- **Pydantic v2 for all data** (strict): all data crossing module boundaries (API schemas, agent inputs/outputs, state files, config) must be a Pydantic v2 `BaseModel` or `BaseSettings`. No raw `dict` crossing a module boundary.
- **Enums/Literal for fixed sets** (strict): any field with a fixed value set must use `Literal[...]` or `enum.Enum`. No raw strings for stage names, run statuses, or curator action types.
- **Protocols over ABCs** (guideline): prefer `typing.Protocol` for interfaces.

### Error handling

- **Fail fast at boundaries** (strict): validate all external inputs (API requests, LLM responses, state file reads) immediately on receipt.
- **Custom exception hierarchy** (strict): all domain errors are typed exceptions with structured fields. Never `raise Exception("message")`. Examples: `StateIOError`, `AgentStageError`, `LLMRateLimitError`.
- **Never swallow errors** (strict): every `except` block must re-raise, raise a domain error, or log-and-re-raise. No `except: pass` or bare `except Exception: pass`.
- **No try/except around internal invariants** (strict): only validate at system boundaries. Internal calls to functions you control are covered by type hints and Pydantic.

### Dependency injection

- **Constructor/parameter injection only** (strict): all dependencies (LLM client, config, run dir) are injected via function parameters or `__init__`. No module-level instantiation of stateful objects inside agents or the orchestrator.

### Async

- **Async all the way** (strict): all I/O (LLM HTTP, file reads/writes, subprocess) must be `async def`/`await` or wrapped in `asyncio.to_thread()`. Never block in an async context.
- **Semaphore for batch** (strict): `asyncio.gather()` calls that could spawn unbounded coroutines must be capped with `asyncio.Semaphore`.
- **Lock for shared state** (strict): shared mutable state (e.g. the per-`run_id` write lock in `run_state.py`) must be wrapped in `asyncio.Lock()`. Document the lock in the class or module docstring.

### Observability

- **Structured logging** (strict): use Python's `logging` module with `getLogger(__name__)`. Never `print()`. Log as key-value pairs where the context warrants it; always include `run_id` and stage name in pipeline log entries.
- **LLM prompt redaction** (strict): log prompts/responses only in dev/debug contexts. In production log token counts and model name only.

### Prompt hygiene

- **Structured output validated** (strict): all `generate()` output passes through a Pydantic model before any field is accessed.
- **Idempotent assembly** (strict): prompt-building helpers are pure functions of their inputs. No timestamps, UUIDs, or randomness injected into prompt content.

### Security

- **Input caps at API boundary** (strict): user-supplied strings are length-capped before reaching the LLM or disk. Never pass unconstrained user input to the pipeline or file system.

## Slash commands

| Command | What it does |
|---|---|
| `/continue` | **Main workhorse.** Load context, implement next task, verify, update docs, write next `NEXT_SESSION.md`. |
| `/fix-next` | Roadmap-driven task runner: pick the first unmarked `project_harness/ROADMAP.md` item, load per-phase context, implement failure-path-first, gate on `make check` + `make principles` + `/code-review`, then stop before commit. |
| `/next-session` | End a session manually: summarize work, write `NEXT_SESSION.md`, update `project_harness/STATUS.md`. |
| `/phase-status` | Print a phase completion table from `project_harness/ROADMAP.md`. |
| `/checkpoint` | Run `make check`, report results, suggest a commit message. |
| `/update-docs` | Cross-reference recent edits against the Doc Update Map; apply updates. |
| `/pipeline-review` | Deep single-run post-mortem: root-cause every failure and self-heal from the run's artifacts + LLM traces, ground in `core/`/`agents_src/`, refine fixes via AskUserQuestion, then write fix-next-ready ROADMAP phases (backed by ISSUE entries). Read-only over `runs/`. |
| `/plan-issues` | Issue-driven planner: for each un-planned Active `ISSUES.md` entry, ground its claims in the current code via parallel read-only subagents, confirm it still reproduces (flag likely-resolved ones for close-out), refine each fix per-finding via AskUserQuestion, then write fix-next-ready ROADMAP phases. Read-only over `core/`/`agents_src/`/`runs/`; writes only `ISSUES.md` + `ROADMAP.md`. |

#!/usr/bin/env python3
"""Enforce the CLAUDE.md structural coding principles that `make check` cannot.

`make check` (ruff + mypy + pytest) does not catch over-length functions, deep
nesting, bare `raise Exception`, swallowed excepts, or stray `print()`. This
script does, so `/fix-next` can gate on them.

Scans Python files (default: those changed vs the base branch, restricted to the
application packages in SCAN_ROOTS) for:
  - files over MAX_FILE_LINES lines
  - functions/methods over MAX_FUNC_LINES lines
  - control-flow nesting deeper than MAX_NESTING
  - `raise Exception(...)` / `raise RuntimeError(...)` (use a domain error)
  - swallowed excepts (body is only `pass`/`continue`)
  - `print(...)` calls (use logging)

Exit 1 if any violation is found in the scanned files. Magic numbers/strings and
the finer SOLID rules are intentionally left to the scoped self-review step in
`/fix-next` — they are too noisy to flag mechanically.

Usage:
  python scripts/check_principles.py                  # changed vs main, app packages
  python scripts/check_principles.py core/foo.py ...  # explicit files
  python scripts/check_principles.py --all            # every file under SCAN_ROOTS
  python scripts/check_principles.py --base develop   # diff against another base
"""

from __future__ import annotations

import argparse
import ast
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

MAX_FILE_LINES = 300
MAX_FUNC_LINES = 40
MAX_NESTING = 3
BANNED_RAISES = frozenset({"Exception", "RuntimeError", "BaseException"})
SWALLOW_BODY = (ast.Pass, ast.Continue)
SCAN_ROOTS = ("core", "agents_src", "demo", "scripts")
NESTING_NODES = (
    ast.If,
    ast.For,
    ast.AsyncFor,
    ast.While,
    ast.With,
    ast.AsyncWith,
    ast.Try,
)

# Per-file rule waivers — explicit documented exceptions to the gate.
# Format: (path_prefix, rule) → reason with linked follow-up phase.
# A violation is suppressed when violation.path.startswith(path_prefix) and
# violation.rule == rule.  A silent skip is never acceptable; every entry here
# must name a linked follow-up phase (Phase 158 scheduled for scripts/ cleanup).
WAIVERS: dict[tuple[str, str], str] = {
    # scripts/ are standalone CLI executables; print() is their intended stdout
    # mechanism, not a logging-hygiene failure.  Phase 158.
    ("scripts/", "print"): "CLI scripts write to stdout by design; Phase 158",
}


@dataclass(frozen=True)
class Violation:
    """One structural-principle breach at a source location."""

    path: str
    line: int
    rule: str
    detail: str


def changed_py_paths(base: str) -> list[Path]:
    """Return changed .py files under SCAN_ROOTS vs the base branch."""
    result = subprocess.run(
        ["git", "diff", "--name-only", f"{base}...HEAD"],
        capture_output=True,
        text=True,
        check=True,
    )
    paths: list[Path] = []
    for name in result.stdout.splitlines():
        path = Path(name)
        if path.suffix == ".py" and path.parts and path.parts[0] in SCAN_ROOTS and path.exists():
            paths.append(path)
    return paths


def _banned_raise_name(exc: ast.expr | None) -> str | None:
    """Return the banned exception name if `raise` constructs one directly, else None."""
    if not (isinstance(exc, ast.Call) and isinstance(exc.func, ast.Name)):
        return None
    return exc.func.id if exc.func.id in BANNED_RAISES else None


def _max_nesting(node: ast.AST, depth: int = 0) -> int:
    """Deepest control-flow nesting reached within a node."""
    best = depth
    for child in ast.iter_child_nodes(node):
        child_depth = depth + 1 if isinstance(child, NESTING_NODES) else depth
        best = max(best, _max_nesting(child, child_depth))
    return best


class PrincipleVisitor(ast.NodeVisitor):
    """Collects structural-principle violations for one module."""

    def __init__(self, path: str) -> None:
        self.path = path
        self.found: list[Violation] = []

    def _add(self, line: int, rule: str, detail: str) -> None:
        self.found.append(Violation(self.path, line, rule, detail))

    def _check_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        # Measure the function body only (excluding the def/argument signature lines).
        # Signature lines are declarative; only the body reflects cognitive complexity.
        body_start = node.body[0].lineno if node.body else node.lineno
        length = (node.end_lineno or body_start) - body_start + 1
        if length > MAX_FUNC_LINES:
            self._add(
                node.lineno,
                "function-length",
                f"{node.name}() body is {length} lines (max {MAX_FUNC_LINES})",
            )
        nesting = _max_nesting(node)
        if nesting > MAX_NESTING:
            self._add(
                node.lineno,
                "nesting",
                f"{node.name}() nests {nesting} deep (max {MAX_NESTING})",
            )

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:  # noqa: N802
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:  # noqa: N802
        self._check_function(node)
        self.generic_visit(node)

    def visit_Raise(self, node: ast.Raise) -> None:  # noqa: N802
        banned = _banned_raise_name(node.exc)
        if banned is not None:
            self._add(node.lineno, "bare-raise", f"raise {banned}(...) — use a domain error")
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:  # noqa: N802
        if node.body and all(isinstance(stmt, SWALLOW_BODY) for stmt in node.body):
            self._add(
                node.lineno,
                "swallowed-except",
                "except body is only pass/continue — log or re-raise",
            )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:  # noqa: N802
        if isinstance(node.func, ast.Name) and node.func.id == "print":
            self._add(node.lineno, "print", "print() call — use logging")
        self.generic_visit(node)


def _count_lines(text: str) -> int:
    """Line count matching ``wc -l`` semantics for the common (newline-terminated)
    case, plus a final unterminated line if present.

    ``text.count("\\n") + 1`` overcounts by one for every file that ends in a
    newline — i.e. essentially all of them — so a file with exactly
    ``MAX_FILE_LINES`` real lines was reported as ``MAX_FILE_LINES + 1`` and
    falsely flagged. Counting newlines and only adding one for a trailing
    unterminated line matches ``wc -l``/editor line numbers and, unlike
    ``str.splitlines()``, never treats a stray ``\\f``/``\\r``/``\\v`` inside a
    string literal as an extra line.
    """
    if not text:
        return 0
    return text.count("\n") + (0 if text.endswith("\n") else 1)


def scan_file(path: Path) -> list[Violation]:
    """Return all structural violations in one Python file."""
    text = path.read_text(encoding="utf-8")
    found: list[Violation] = []
    line_count = _count_lines(text)
    if line_count > MAX_FILE_LINES:
        found.append(
            Violation(str(path), 1, "file-length", f"{line_count} lines (max {MAX_FILE_LINES})")
        )
    visitor = PrincipleVisitor(str(path))
    visitor.visit(ast.parse(text, filename=str(path)))
    found.extend(visitor.found)
    return found


def parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse the CLI arguments."""
    parser = argparse.ArgumentParser(description="Check CLAUDE.md structural principles.")
    parser.add_argument("paths", nargs="*", help="Files to scan (default: changed vs base).")
    parser.add_argument("--base", default="main", help="Base branch for the diff (default: main).")
    parser.add_argument("--all", action="store_true", help="Scan every file under SCAN_ROOTS.")
    return parser.parse_args(argv)


def resolve_paths(args: argparse.Namespace) -> list[Path]:
    """Resolve the set of files to scan from the parsed arguments."""
    if args.paths:
        return [Path(p) for p in args.paths if Path(p).exists()]
    if args.all:
        return [path for root in SCAN_ROOTS for path in Path(root).rglob("*.py")]
    return changed_py_paths(args.base)


def _is_waived(violation: Violation) -> bool:
    """Return True when the violation is covered by an explicit named waiver."""
    return any(
        violation.path.startswith(prefix) and violation.rule == rule for prefix, rule in WAIVERS
    )


def main(argv: list[str]) -> int:
    """Scan the resolved files and report violations; return the exit code."""
    args = parse_args(argv)
    paths = sorted(set(resolve_paths(args)))
    if not paths:
        print("principles: no Python files to scan.")
        return 0
    all_violations: list[Violation] = []
    for path in paths:
        all_violations.extend(scan_file(path))
    active = [v for v in all_violations if not _is_waived(v)]
    if not active:
        print(f"principles: OK ({len(paths)} file(s) scanned, 0 violations).")
        return 0
    for violation in sorted(active, key=lambda v: (v.path, v.line)):
        print(f"{violation.path}:{violation.line}: [{violation.rule}] {violation.detail}")
    print(f"\nprinciples: {len(active)} violation(s) in {len(paths)} file(s).")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

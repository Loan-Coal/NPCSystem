#!/usr/bin/env bash
# git_askpass.sh — GIT_ASKPASS credential helper for the nightly roadmap runner.
#
# git invokes this script with a prompt string as $1 whenever it needs a
# credential. git may ask for a username AND a password (when the remote URL
# has no embedded user), so we branch on the prompt: a "Username" prompt gets
# GIT_USERNAME (default oauth2); anything else gets the GitLab PAT stored in
# PAT_FILE. git reads our stdout directly via a pipe — the token never appears
# in process listings, shell history, .git/config, or log files.
#
# Setup (one-time):
#   echo '<your-gitlab-pat>' > ~/.ctf-pat
#   chmod 600 ~/.ctf-pat
#   chmod 700 scripts/git_askpass.sh
#
# Then in expand_loop.sh (already done):
#   export GIT_ASKPASS="$REPO_ROOT/scripts/git_askpass.sh"
#   export GIT_USERNAME="oauth2"   # GitLab PAT username
#
# The PAT should have read_repository + write_repository scope on the project,
# with a short expiry (30 days). Rotate before expiry.

PAT_FILE="${PAT_FILE:-$HOME/.ctf-pat}"

# A "Username" prompt is answered without touching the PAT file so a missing
# token surfaces only on the password prompt, where it actually matters.
case "$1" in
  Username*) echo "${GIT_USERNAME:-oauth2}"; exit 0 ;;
esac

if [[ ! -f "$PAT_FILE" ]]; then
  echo "git_askpass.sh: PAT_FILE not found at $PAT_FILE" >&2
  exit 1
fi

cat "$PAT_FILE"

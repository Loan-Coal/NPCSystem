#!/usr/bin/env python3
"""Confirm candidate-new gate failures by re-running them (token-free).

`scripts/gate_baseline.py` answers "is this failing id in the phase baseline?". That is a
set diff, and a set diff cannot tell a task-introduced regression from a test that simply
lost a race this time. The overnight loop runs unattended on a loaded machine, so
load-dependent flakes are routine: on 2026-07-31 two timing-sensitive background-subprocess
tests were charged to phase 247.3, which had not touched that code, and the loop abandoned
the rest of the phase on the strength of it.

So a candidate-new failure is not believed until it fails a re-run of *only* those ids —
twice. Requiring two consecutive confirmations is the point: a test that flakes one run in
five survives a single confirmation run 20% of the time, but two 4% of the time, and the
reruns are node-id-scoped so both cost seconds rather than a full suite.

Every uncertain path resolves toward *confirming* the failure: a rerun that times out, a
crash before pytest prints its summary, an id that cannot be re-run at all (a
``<check>:red`` sentinel from a non-pytest check), or a candidate set too large to be
anything but systemic breakage. Under-reporting a real regression is the expensive
direction; over-reporting one now only costs an ``UNVERIFIED`` marker, since a regression
no longer forfeits its phase.

The policy is pure and takes its runner injected, so the unit tests drive it with a fake
and never spawn pytest.
"""

from __future__ import annotations

import re
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

# Run directly and Python puts scripts/ on sys.path[0], not the repo root, so the
# `scripts.` package import below needs the repo root added explicitly.
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from scripts.gate_baseline import extract_failed_ids  # noqa: E402

# Consecutive re-runs a candidate must fail before it counts as task-introduced.
CONFIRMATION_RERUNS = 2

# Wall-clock cap for one confirmation re-run. Generous for a handful of node ids; a
# timeout confirms the candidates rather than clearing them.
RERUN_TIMEOUT_SECS = 600

# Above this many candidates, skip confirmation and confirm them all. A task that newly
# reddens dozens of tests is systemic breakage, not a flake, and re-running the set twice
# would cost most of a full suite run to tell us what we already know.
MAX_CONFIRMABLE_IDS = 50

# ``<check-name>:red`` — the sentinel gate_baseline emits for a red check whose output had
# no parseable node ids (schema-check, or a pytest crash before the summary). There is
# nothing to hand back to pytest, so these are confirmed without a re-run.
_SENTINEL_RE = re.compile(r"^[a-z][a-z0-9-]*:red$")

# The re-run only needs the failure summary; quiet output keeps the captured text small.
_RERUN_CMD_PREFIX = ("uv", "run", "pytest", "-q", "--no-header")

# Synthetic check name for parsing a re-run's output through extract_failed_ids.
_RERUN_CHECK_NAME = "confirm-rerun"

# Injected re-runner: given ids to re-run, return the subset that failed.
Rerunner = Callable[[tuple[str, ...]], set[str]]


@dataclass(frozen=True)
class Confirmation:
    """Which candidate-new failures survived confirmation, and which were cleared.

    ``reruns_used`` is 0 when the policy short-circuited (nothing to confirm, or a
    candidate set past ``MAX_CONFIRMABLE_IDS``), so callers can report that confirmation
    was skipped rather than silently imply the ids were re-tested.
    """

    confirmed: tuple[str, ...]
    cleared: tuple[str, ...]
    reruns_used: int

    @property
    def is_regression(self) -> bool:
        """True iff at least one candidate failed every confirmation re-run."""
        return bool(self.confirmed)


def is_rerunnable(failure_id: str) -> bool:
    """True iff the id names something pytest can be asked to run again."""
    return not _SENTINEL_RE.match(failure_id)


def confirm_new_failures(
    candidates: set[str],
    rerun: Rerunner,
    reruns: int = CONFIRMATION_RERUNS,
) -> Confirmation:
    """Re-run ``candidates`` up to ``reruns`` times; confirm only those failing every time.

    Each round narrows the surviving set, so the second re-run is cheaper than the first
    and a fully-cleared set exits early. Non-rerunnable sentinels bypass the re-runs and
    are confirmed directly.
    """
    if not candidates:
        return Confirmation((), (), 0)
    sentinels = {c for c in candidates if not is_rerunnable(c)}
    surviving = candidates - sentinels
    if len(candidates) > MAX_CONFIRMABLE_IDS:
        return Confirmation(tuple(sorted(candidates)), (), 0)
    rounds = 0
    while surviving and rounds < reruns:
        surviving &= rerun(tuple(sorted(surviving)))
        rounds += 1
    confirmed = sentinels | surviving
    return Confirmation(tuple(sorted(confirmed)), tuple(sorted(candidates - confirmed)), rounds)


def pytest_rerun(ids: tuple[str, ...]) -> set[str]:
    """Re-run exactly ``ids`` under pytest; return the subset that failed again.

    Conservative on every failure of the mechanism itself: a timeout, or a non-zero exit
    with no parseable summary, returns the full input set so the caller confirms rather
    than clears failures it could not actually re-test.
    """
    try:
        proc = subprocess.run(
            [*_RERUN_CMD_PREFIX, *ids],
            capture_output=True,
            text=True,
            timeout=RERUN_TIMEOUT_SECS,
        )
    except subprocess.TimeoutExpired:
        return set(ids)
    if proc.returncode == 0:
        return set()
    failed = extract_failed_ids(_RERUN_CHECK_NAME, False, (proc.stdout + proc.stderr).strip())
    if failed == {f"{_RERUN_CHECK_NAME}:red"}:
        return set(ids)
    return failed & set(ids)

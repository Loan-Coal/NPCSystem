# loop.config.sh — every project-specific knob the overnight loop needs.
#
# Sourced by scripts/expand_loop.sh before any of its own defaults, so anything set
# here wins. This file and scripts/loop_gates.py are the only two files you should
# need to edit to move the loop to a new repo.
#
# Uncomment and adjust what differs from the defaults shown.

# ── layout ────────────────────────────────────────────────────────────────────
# Directory holding ROADMAP.md, ISSUES.md, human_verification.md and the loop's
# own run reports. Committed — these are project records, not scratch files.
# The shipped .claude/commands/*.md skills refer to `project_harness/` by name, so
# if you rename this you must update those prompts to match.
# HARNESS_DIR="project_harness"

# Full path to the roadmap. Defaults to $HARNESS_DIR/ROADMAP.md. Also exported to
# scripts/roadmap_cursor.py, which reads ROADMAP_FILE from the environment.
# ROADMAP_FILE="$REPO_ROOT/$HARNESS_DIR/ROADMAP.md"

# ── commands ──────────────────────────────────────────────────────────────────
# Interpreter prefix for this loop's own helper scripts. Word-split, so a prefix
# like `uv run python` or `poetry run python` works as-is. Use plain `python` if
# your project has no venv manager.
# PY_RUN="uv run python"

# The three deterministic gate commands, run straight from bash at every phase
# boundary — no LLM involved. Each must exit 0 for green.
#   GATE_CHECK_CMD            the full quality gate (lint + types + tests)
#   GATE_PRINCIPLES_CMD       structural rules (scripts/check_principles.py)
#   GATE_ROADMAP_VERIFY_CMD   roadmap grammar doctor (roadmap_cursor.py --verify)
# templates/Makefile defines all three; point them anywhere if you'd rather not
# use make (e.g. GATE_CHECK_CMD="uv run nox -s check").
# GATE_CHECK_CMD="uv run make check"
# GATE_PRINCIPLES_CMD="uv run make principles"
# GATE_ROADMAP_VERIFY_CMD="uv run make roadmap-verify"

# ── git ───────────────────────────────────────────────────────────────────────
# 0 (or --no-push) runs the loop fully local: commits still land on the branch that
# was checked out at start, but nothing is pushed and no credential setup runs.
# Start here — turn pushing on once you've watched a night succeed.
# PUSH_ENABLED=1

# Token file for HTTPS pushes, read via scripts/git_askpass.sh so the token never
# appears in a process listing or a log. Ignored when PUSH_ENABLED=0, and unnecessary
# if your remote is SSH or git-credential-manager already has you authenticated.
#   echo '<token>' > ~/.roadmap-loop-pat && chmod 600 ~/.roadmap-loop-pat
# PAT_FILE="$HOME/.roadmap-loop-pat"
# GIT_USERNAME="oauth2"          # GitHub over HTTPS: any non-empty value works

# ── pacing ────────────────────────────────────────────────────────────────────
# Timezone for the morning-stop, halt-retry and usage-limit clocks.
# RESTART_TZ="Europe/Paris"

# Stop STARTING new work past this local time. Never interrupts work already running.
# MORNING_STOP_HOUR_LOCAL="08:00:00"

# Per-task cap on the implementing claude session (90 min).
# CLAUDE_TIMEOUT=5400

# Pause after each pushed phase, to let subscription usage headroom regenerate.
# PHASE_SLEEP_SECS=400

# ── models ────────────────────────────────────────────────────────────────────
# Implementation sessions use the account default unless pinned here.
# MODEL=""
# Cheap model for the per-phase soft code review (not the implementation).
# REVIEW_MODEL="claude-haiku-4-5-20251001"

# ── tolerances ────────────────────────────────────────────────────────────────
# These are the settings that decide whether one bad test costs you the whole night.
# The defaults are the ones this loop converged on after several lost nights; raise
# them only once you've seen why.
# MAX_CONSECUTIVE_RED_GATES=2       # red phase gates in a row before a real HALT
# MAX_RED_COMMITS=3                 # task-introduced regressions in a row before a HALT
# MAX_CONSECUTIVE_BLOCKED_PHASES=2  # blocked-prerequisite skips in a row before a HALT
# RED_COMMIT_TOLERANCE=1            # 0 = HALT (uncommitted) on any red per-task gate
# AUTOFIX_ENABLED=1                 # one bounded repair session per auto-fixable red gate

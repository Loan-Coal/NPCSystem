#!/usr/bin/env python3
"""Failing-set attribution for the overnight loop's tolerant per-task gate (token-free).

`scripts/classify_gate_failure.py` decides *whether* a red gate is halt-worthy or
auto-fixable. This module answers a different question the tolerant loop asks on a
halt-class red: did *this task* introduce the failure, or was it already red before
the task ran? That is a set diff — the current halt-class failing set minus a stored
baseline (the failing set as of the previous commit):

  * empty new set  → **pre-existing** (the task added nothing; commit as baseline-red)
  * non-empty      → **regression**   (the task introduced ≥1 failure; commit + flag)

The baseline is **re-seeded once per phase** from a union of repeated halt-class runs
and is then immutable for that phase's tasks — it is never written back mid-phase.
Writing the current failing set back on every diff (the old carry-forward) let a task
that ran the classifier twice launder its own regression into the baseline and be
reported as pre-existing on the second call; that is precisely what happened on
2026-07-31 to phase 249.1's ten `test_orchestrator_cli` failures.

Kept separate from the classifier so each module has one responsibility: that one
routes green/red, this one attributes red to pre-existing vs introduced. Pure and
subprocess-free — it operates on already-captured check output, so it is trivially
testable and has no dependency on the classifier (no import cycle).

The baseline file is scratch state (`/tmp`), not pipeline state, so it is written
with a plain atomic-enough `write_text`; a missing file is an *expected* condition
(a fresh run that has not been seeded yet) and yields ``None`` so the caller can fall
back conservatively — treating every current failure as new — rather than crash.
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

# Bump if the on-disk shape changes; an unknown version is treated as unreadable.
_SCHEMA_VERSION = 1

# pytest's short-summary failure/error lines: ``FAILED path::test - reason`` or
# ``ERROR path - reason``. The node-id (or file, for a collection error) is group 1.
_FAILED_RE = re.compile(r"^(?:FAILED|ERROR)\s+(\S+)")


@dataclass(frozen=True)
class BaselineDiff:
    """The pre-existing-vs-introduced verdict for one gate run.

    ``baseline_known`` is False when no baseline file existed (fresh/un-seeded run);
    the caller then gets every current failure as ``new_failures`` — the conservative
    fallback that treats an unknown baseline as "the task introduced everything".
    """

    new_failures: tuple[str, ...]
    preexisting: tuple[str, ...]
    baseline_known: bool

    @property
    def is_regression(self) -> bool:
        """True iff the task introduced at least one failure absent from the baseline."""
        return bool(self.new_failures)


@dataclass(frozen=True)
class SeedDelta:
    """What changed in the baseline across a per-phase re-seed.

    ``previous_known`` is False for the first seed of a run (no prior baseline file), where
    every id is trivially "entered" and the delta carries no signal worth flagging.
    """

    entered: tuple[str, ...]
    left: tuple[str, ...]
    previous_known: bool


def extract_failed_ids(name: str, passed: bool, output: str) -> set[str]:
    """Parse the stable failing ids from one check's captured output.

    Returns pytest node-ids (or collection-error file paths) for a red pytest check.
    A check that failed but yielded no parseable ids (e.g. schema-check, or a pytest
    crash before the summary) contributes a single ``<name>:red`` sentinel so the set
    still records that the check is red and remains diffable. A passing check adds none.
    """
    if passed:
        return set()
    ids: set[str] = set()
    for line in output.splitlines():
        match = _FAILED_RE.match(line.strip())
        if match:
            ids.add(match.group(1))
    return ids or {f"{name}:red"}


def collect_failing_set(results: Iterable[tuple[str, bool, str]]) -> set[str]:
    """Union the failing ids across every (name, passed, output) check result."""
    ids: set[str] = set()
    for name, passed, output in results:
        ids |= extract_failed_ids(name, passed, output)
    return ids


def diff_failing_set(current: set[str], baseline: set[str] | None) -> BaselineDiff:
    """Classify ``current`` failures as new vs pre-existing against ``baseline``.

    ``baseline is None`` (no seeded file) → every current failure is treated as new.
    The diff is robust to a stale *superset* baseline: ids present in the baseline but
    absent now simply drop out of both buckets.

    Pure and idempotent: repeated calls with the same arguments return the same verdict
    and touch nothing on disk. The unsafe direction — a genuinely pre-existing failure
    missing from the baseline, reported as a regression — is covered by seeding from a
    union of repeated runs (load-dependent flakes red at phase start land in the
    baseline) and by ``scripts/gate_confirm.py`` (flakes that first appear mid-phase are
    re-run before they can be called new), not by mutating the baseline mid-phase.
    """
    if baseline is None:
        return BaselineDiff(tuple(sorted(current)), (), baseline_known=False)
    new = current - baseline
    preexisting = current & baseline
    return BaselineDiff(tuple(sorted(new)), tuple(sorted(preexisting)), baseline_known=True)


def union_failing_sets(sets: Iterable[set[str]]) -> set[str]:
    """Union the failing sets of repeated seed runs.

    A load-dependent flake red in *either* run must land in the baseline, otherwise the
    first task of the phase is charged with a failure it did not introduce. Union is the
    only safe combinator here: intersection would silently drop exactly those flakes.
    """
    combined: set[str] = set()
    for failing in sets:
        combined |= failing
    return combined


def diff_seeds(new: set[str], previous: set[str] | None) -> SeedDelta:
    """Report which ids entered and left the baseline across a re-seed.

    A per-phase re-seed absorbs whatever is red at the phase boundary — including real
    failures a previous phase committed as debt. Absorbing them is deliberate (otherwise
    every later task re-flags them and every phase reads as a regression), but silently
    absorbing them would relaunder exactly what this module stopped laundering. The
    caller logs ``entered`` so the debt stays visible in the verification queue.
    """
    if previous is None:
        return SeedDelta(tuple(sorted(new)), (), previous_known=False)
    return SeedDelta(tuple(sorted(new - previous)), tuple(sorted(previous - new)), True)


def write_baseline(path: str, failing: set[str]) -> None:
    """Persist a failing set as the baseline the current phase's tasks diff against."""
    payload = {"version": _SCHEMA_VERSION, "failing": sorted(failing)}
    Path(path).write_text(json.dumps(payload), encoding="utf-8")


def load_baseline(path: str) -> set[str] | None:
    """Load a stored baseline failing set, or ``None`` if absent or unreadable.

    A missing file is an expected, non-error state (a run that has not been seeded);
    a malformed/old-version file is surfaced on stderr and also degrades to ``None``
    so a corrupt scratch file degrades the attribution gracefully rather than crashing
    the unattended loop.
    """
    file = Path(path)
    if not file.exists():
        return None
    try:
        payload = json.loads(file.read_text(encoding="utf-8"))
        if payload.get("version") != _SCHEMA_VERSION:
            raise ValueError(f"unknown baseline version {payload.get('version')!r}")
        return set(payload["failing"])
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print(f"gate_baseline: ignoring unreadable baseline {path}: {exc}", file=sys.stderr)
        return None

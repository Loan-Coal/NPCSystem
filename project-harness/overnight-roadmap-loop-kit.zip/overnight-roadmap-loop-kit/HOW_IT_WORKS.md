# Overnight Roadmap Loop — how it works, and how to port it

**Read this first if you are an AI assistant asked to adapt this system to another project.**
This is a porting brief, not marketing. It describes a working system extracted from a Linux
work repo, and tells you exactly which parts are universal, which are project-specific, and
which will not survive the move to Windows.

The source system runs unattended overnight: it reads a roadmap of numbered phases and tasks,
implements one task per Claude Code session, gates each one, commits it, and keeps going until
the roadmap is drained or something genuinely warrants a human. It has been running nightly for
months. Most of its complexity is not features — it is scar tissue from specific nights that
were lost, and §6 documents each scar so you do not sand them off.

---

## 0. What is in this package

```
verbatim/                       Byte-identical copies from the source repo. Source of truth.
  scripts/expand_loop.sh        The loop itself (2384 lines of bash).
  scripts/roadmap_cursor.py     The ONLY reader/writer of the roadmap's grammar.
  scripts/_roadmap_cursor_core.py   Pure parsing/marking functions behind that CLI.
  scripts/classify_gate_failure.py  Routes a red gate to AUTOFIX or HALT.
  scripts/gate_baseline.py      Snapshots the set of already-failing tests.
  scripts/gate_attribution.py   Diffs a red gate against that baseline.
  scripts/gate_confirm.py       Re-runs a failure to prove it is not a flake.
  scripts/scan_fix_diff.py      Scans a repair diff for gate-gaming.
  scripts/check_principles.py   Structural rules a linter cannot express.
  scripts/git_askpass.sh        Feeds a token to git without it hitting a process listing.
  .claude/commands/expand-linear-next.md   The skill that implements one task.
  .claude/commands/fix-make-failure.md     The bounded repair skill.
  .claude/commands/clean-slate.md          The deterministic gate skill.
  Makefile                      Source project's; only `check`, `principles`, `roadmap-verify` matter.
  CLAUDE.md                     Source project's quality bar — the skill reads this every task.

generalized-reference/          One worked example of the conversion. NOT authoritative.
                                CTF-specific blocks removed, project knobs lifted into
                                loop.config.sh + scripts/loop_gates.py, smoke-tested on a
                                throwaway repo. Read it for ideas; prefer verbatim + this doc.

ROADMAP_GRAMMAR.md              The roadmap format, in detail. Read it before touching a roadmap.
```

---

## 1. The core idea

Three things cooperate. Keep the separation — it is what makes the system resumable.

**The roadmap** (`project_harness/ROADMAP.md`) is a numbered backlog: `## Phase N:` headings,
each containing `- **N.M —` task bullets with an explicit acceptance criterion. A finished task
gets a `— ✅ DONE (phase-N.task-M, DATE)` marker appended.

**The skill** (`/expand-linear-next`) is a prompt. Invoked headlessly as
`claude -p "/expand-linear-next --auto --single-task"`, it finds the next unfinished task,
implements it to the quality bar in `CLAUDE.md`, runs the gate, marks the task DONE, commits,
and prints a status token. It holds no state.

**The loop** (`scripts/expand_loop.sh`) is bash. It runs one fresh Claude session per task,
reads the status token, and decides what happens next: continue, run the phase gate, attempt a
repair, skip ahead, sleep until the usage window resets, or halt for a human.

### Why the state lives in the roadmap and nowhere else

This is the single most important design decision. **The DONE markers in ROADMAP.md are the
only record of progress.** There is no cursor file, no run-state JSON, no session ID to resume.

The consequence: a task is complete if and only if its DONE-marked commit landed. Kill the loop
at any moment — power cut, `kill -9`, laptop lid closed — and there is nothing to reconcile.
The next launch reads the roadmap, finds the first unmarked task, and continues. This is why
each task gets its own commit including its own DONE marker: the commit is the transaction.

**If you port nothing else, port this.** A design that tracks progress in a side file has to
answer "what if we crashed between updating the file and committing?" and every answer is worse
than not having the file.

### Why one session per task

The loop launches a fresh `claude -p` per task rather than one long session for the whole night.

- **Bounded context.** Each session sees one task, so context stays small and the work stays
  sharp. A session running 9 hours degrades.
- **No incentive to background work.** The session's only job is one task, so it has no reason
  to background the slow gate and "check later" — a headless turn that stops calling tools ends,
  taking uncommitted work with it. §6.1 is that failure.
- **Atomic crash recovery.** Nothing partial survives a session boundary.

---

## 2. The lifecycle

### Per task

1. Loop runs `claude -p "/expand-linear-next --auto --single-task"` under a timeout (default
   5400s / 90 min).
2. Skill reads `roadmap_cursor.py --next` to get the phase, `--slice N` to load only that
   phase's body — never the whole 2000-line backlog.
3. Skill implements the task, runs the full gate in the **foreground**, marks the task DONE via
   `roadmap_cursor.py --mark N.M`, commits everything as one commit.
4. Skill prints `AUTO_STATUS: <TOKEN>` as its last line.
5. Loop parses the token and branches.

### Status tokens

| Token | Meaning | Loop's response |
|---|---|---|
| `TASK_COMPLETE` | Task done, gate green | Next task |
| `PHASE_COMPLETE` | Last task of the phase done | Run the phase boundary (§3) |
| `ALL_DONE` | No unfinished tasks left | Finish successfully |
| `TASK_COMPLETE_BASELINE_RED` | Gate red, but every failure pre-existed | Treat as complete, continue |
| `TASK_COMMITTED_REGRESSION` | Gate red with a NEW failure, confirmed by re-run | Commit + flag, continue; halt after 3 in a row |
| `HALT <reason>` | Cannot proceed | Depends on reason (§6.4 for `blocked-prerequisite`) |

### Per phase (the boundary)

When a phase's tasks are all marked done, the loop — **not** the skill — runs the boundary. It
is deterministic bash, no LLM:

1. **Phase gate**: `make check`, then `make principles`, then `make roadmap-verify`.
2. If red: `classify_gate_failure.py` routes it (§4).
3. **Soft review**: a cheap model reviews the phase's own diff, findings appended to a report.
4. **Push** the start branch.
5. **Re-seed the failure baseline** (§4) for the next phase.
6. Sleep (default ~7 min) to let subscription usage headroom regenerate.

The gate is bash, not a Claude session, because it is a deterministic command. Never spend a
model call on something `make` can answer.

---

## 3. Branch policy

The loop **never creates a branch and never opens a PR/MR**. It commits directly onto whatever
branch was checked out when it started, and pushes that branch.

This is deliberate. A loop that opens merge requests generates a morning queue of manual merges,
which defeats the point of unattended work. Review happens in the morning against the branch.

For a personal project this is even simpler — you likely run it straight on a working branch.

---

## 4. The red-gate machinery (the subtle part)

Naive design: gate red → halt. That loses whole nights to failures the loop did not cause. The
real system distinguishes four cases.

**Baseline.** Before each phase, `gate_baseline.py` runs the halt-class checks a couple of times
and records the set of already-failing tests. It is written at phase boundaries and **never
mid-phase** — otherwise a task could launder its own regression into the baseline.

**Attribution.** When a task's gate is red, `gate_attribution.py` diffs the failing set against
that baseline:
- No new failures → `TASK_COMPLETE_BASELINE_RED`. Pre-existing debt, not this task's fault.
  Commit and continue.
- New failures → candidate regression, go to confirmation.

**Confirmation.** `gate_confirm.py` re-runs the new failures. Only a failure reproducing on two
consecutive runs is charged to the task. This stops a flaky test from costing a phase.

**Classification.** `classify_gate_failure.py` splits checks into two classes:
- **HALT-class** — tests, schema checks. Anything asserting *behaviour*. Never auto-fixed: a
  repair session would be guessing at intent, and the easiest way to make a red test green is to
  edit the test, which is fraud.
- **AUTOFIX-class** — lint, formatting, types, structural rules. Anything asserting *form*.
  These have mechanical, verifiable fixes.

An AUTOFIX-class red gets **one** bounded `/fix-make-failure` session. Its diff is then scanned
by `scan_fix_diff.py` for gate-gaming — added `# noqa`, `# type: ignore`, `except: pass`, edits
to test files, edits to the gate scripts themselves — and the full gate is re-run before the
repair is committed **separately** and flagged for morning review. If the repair fails, it
reverts only itself, never the phase's task commits.

**Tolerance.** A still-red gate does not halt. It is logged to `human_verification.md` and the
phase's commits are pushed anyway. Only `MAX_CONSECUTIVE_RED_GATES` (default 2) in a row halts,
on the theory that a genuinely broken base should not get more phases piled on it.

> **Porting note.** The classifier's check definitions are the most project-specific code in the
> package (`HALT_CHECKS` / `AUTOFIX_CHECKS` near the top of `classify_gate_failure.py`, hardcoded
> to `uv run pytest tests/unit`, `mypy core/ agents_src/`, etc.). `generalized-reference/` shows
> one way to lift them into an editable `scripts/loop_gates.py`. The HALT/AUTOFIX *split* is
> universal; the commands are not.

---

## 5. Timing, pacing, and the subscription

The loop drives Claude Code on a subscription, not an API key, so usage limits are a first-class
concern rather than an error.

- **`--start-at 20:00`** — launch during the day, sleep until evening before any work.
- **`--stop-at 08:00`** (morning stop, `RESTART_TZ`) — past this time the loop stops *starting*
  new work but never interrupts anything already running. A clean stop, not a halt.
- **Inter-phase sleep** (~7 min default) lets usage headroom regenerate. `--trim-sleep` cuts it,
  `--no-sleep` removes both sleeps for maximum throughput at higher usage burn.
- **Usage-limit auto-restart** — if a session's output looks like the subscription's own usage
  limit, the loop stashes any uncommitted work, sleeps until the ~5h rolling window resets, and
  `exec`s itself with the original argv. Because the skill is stateless it simply resumes at the
  next unfinished task. §6.3 covers the guards that keep this from becoming an infinite loop.
- **Halt retry** — one re-attempt at 03:00 after a roadmap halt, if the last attempt made
  progress.

---

## 6. The scars — do not remove these

Every item here is a night that was lost. If a defense looks like over-engineering, this section
is why it exists. Preserve the behaviour even if you restructure the code.

**6.1 — Never background the gate.** A headless `claude -p` turn ends the moment it stops calling
tools. A session that backgrounds `make check` and says "I'll check the result shortly" dies with
its work uncommitted. The skill prompt says this in bold, three times, in its own section. Keep
that emphasis when you adapt the prompt — it is load-bearing.

**6.2 — Commit before you stop.** Same root cause. If a turn ends with edits in the working
tree, the next run's clean-tree gate refuses them and the work is lost.

**6.3 — Usage-limit restart needs runaway guards.** Auto-restart on usage limit will loop forever
if the "limit" detection false-positives. Four independent guards, any one of which halts instead
of restarting: a restart cap per exec lineage; a no-progress check (two hits with the same
roadmap DONE-count between them); a rapid-repeat check (hits closer than 300s are a bug, not real
quota exhaustion); and a stash-pileup check (unresolved auto-restart stashes accumulating means
restarts are not recovering).

**6.4 — A blocked prerequisite should skip, not halt.** If a task cannot start because it needs
something that does not exist yet, the skill emits `HALT blocked-prerequisite` rather than
implementing a guess. The loop logs it and force-advances to the next phase for the rest of the
run. The blocked phase's tasks stay unmarked, so a later run naturally retries it first. Backstop:
`MAX_CONSECUTIVE_BLOCKED_PHASES` (default 2) with zero progress between them halts for real.

**6.5 — A red per-task gate must not lose the work.** Originally a red unit test in a task's own
gate halted the run with the work uncommitted. Six pre-existing, unrelated test-isolation
failures once halted every task of a phase. Now the work is committed, marked
`✅ DONE ⚠️ UNVERIFIED`, and flagged. Visible debt beats lost work.

**6.6 — A regression must not forfeit the rest of the phase.** It used to. That cost a phase its
irreversible cutover task over two flakes the task never touched. Now the loop continues to the
phase's next task and only halts after `MAX_RED_COMMITS` (default 3) regressions in a row.

**6.7 — Never let the loop's own log file be tracked by git.** An earlier version wrote its live
log into a tracked path; the startup auto-commit raced the file being appended to and crashed the
loop at launch. Gitignore the run logs. Relatedly, a failed startup auto-commit must halt
cleanly, not crash.

**6.8 — Report artifacts must be checkpointed.** The loop appends to several markdown reports
during the night. The skill refuses to run on a dirty tree, so uncommitted reports would halt the
loop one task into the next phase. There is a `checkpoint_reports()` that commits them.

**6.9 — Status tokens must not be wrapped in backticks.** A skill that prints
`` `AUTO_STATUS: TASK_COMPLETE` `` breaks the loop's parse and reads as a halt. The token must be
bare on its own line.

**6.10 — Phase caps must count roadmap state, not tokens.** `--max-phases` originally counted
`PHASE_COMPLETE` tokens; a red-committed final task suppresses that token, so the cap silently
never tripped. It now asks the roadmap whether the phase's tasks are all done.

---

## 7. Porting checklist

### 7.1 Windows — read this before anything else

**The loop is bash and depends on a real Linux userland.** It uses `flock`, `setsid`, `nohup`,
`timeout`, `date -d`, process groups and signal semantics. `flock` and `setsid` do not exist in
Git Bash, and detached-background behaviour there is unreliable — which is precisely what an
unattended 8-hour run leans on hardest.

**Recommended: run it under WSL2.** Ubuntu in WSL2, Claude Code installed inside WSL, the target
project cloned into the WSL filesystem (`~/proj`, **not** `/mnt/c/...` — that path is slow and
breaks file watching). Everything then runs unmodified, and §6's defenses stay intact.

A PowerShell rewrite is a multi-day project that would re-introduce most of §6. Do not start
there.

The one case where WSL2 is not enough: if the target project's own gate needs Windows-native
tooling. Then run the loop in WSL and have the gate command shell out — set the gate to invoke
`powershell.exe -Command "..."` from inside WSL. Everything else is unaffected.

Also check: `wsl --shutdown` and Windows sleep will kill an overnight run. Disable sleep, or set
the Windows power plan to keep the machine awake on AC.

### 7.2 What is project-specific and must be replaced

| Thing | Where | What to do |
|---|---|---|
| `make check` / `principles` / `roadmap-verify` | `expand_loop.sh`, skill prompt | Keep the three names, change what they run. Only these three targets in the shipped `Makefile` matter — the rest is CTF machinery. |
| Gate check definitions | `classify_gate_failure.py` `HALT_CHECKS` / `AUTOFIX_CHECKS` | Rewrite for the target's test/lint/type commands. Preserve the HALT vs AUTOFIX split. |
| `SCAN_ROOTS` | `check_principles.py` | Point at the target's source dirs. A typo silently makes the structural gate a no-op. |
| `uv run` prefix | throughout | Replace with the target's venv runner, or drop it. |
| `project_harness/` | everywhere incl. skill prompt | Renameable, but the skill prompt names it. Easiest to keep the name. |
| GitLab PAT, `~/.ctf-pat`, `oauth2` | credential setup | GitHub/SSH for a personal project — or set pushing off entirely and run local-only. |
| Pipeline smoke runs (`--smoke`) | `_smoke_run_one`, `run_pipeline_smoke` | **Delete.** Runs the CTF generation pipeline. No analogue. |
| Post-roadmap review cycle | `_review_*`, `run_review_cycle`, `/pipeline-review` | **Delete.** CTF-pipeline post-mortem. Off with `--no-review`; `generalized-reference/` shows the excision. Note `REVIEW_SESSION_TIMEOUT` is reused by the generic soft-review filer — keep that one variable. |
| `CLAUDE.md` | repo root | **Write a real one.** The skill enforces it as a hard gate; it is the only description of the quality bar the unattended loop ever sees. A vague CLAUDE.md produces vague overnight work. |

### 7.3 What ports unchanged

`roadmap_cursor.py` + `_roadmap_cursor_core.py` (pure roadmap grammar), `gate_baseline.py`,
`gate_attribution.py`, `gate_confirm.py`, `scan_fix_diff.py` (bar its frozen-path list), the
entire loop skeleton, and the whole of §6.

The skill prompts port with light edits — mostly the `make` target names and the harness
directory. Their structure, the headless-execution warnings, and the quality-bar section are
project-independent.

### 7.4 Bring-up order

1. WSL2 + Claude Code inside it; confirm `claude -p "say hi"` works.
2. Copy `verbatim/scripts/` and `verbatim/.claude/commands/` into the target repo.
3. Write `CLAUDE.md`. Do not skip this.
4. Wire the three make targets; confirm each exits 0 by hand.
5. Point `roadmap_cursor.py` at the roadmap; `--verify`, then `--next`, then `--slice N`.
   Fix grammar drift now, not at 2am.
6. **Run one task in the foreground**, watching: `bash scripts/expand_loop.sh --max-tasks 1`.
7. Then one full phase: `--max-phases 1`.
8. Then a real night: `--background --start-at 20:00 --stop-at 08:00`.

Turn pushing on only after a full night has succeeded locally.

### 7.5 Verifying an adaptation without burning a night

Create a throwaway git repo with a two-phase roadmap, stub gate commands that just `exit 0`, and
a fake `claude` executable earlier on `PATH` that marks the task done, commits, and echoes
`AUTO_STATUS: PHASE_COMPLETE`. The whole loop — config, cursor, gate, attribution, boundary,
push, sleep — then runs end to end in about a minute with no model calls. This is how
`generalized-reference/` was validated, and it catches unbound-variable and path errors that only
appear at 3am otherwise.

---

## 8. Reading order

1. This document.
2. `ROADMAP_GRAMMAR.md` — the format everything hinges on.
3. `verbatim/scripts/expand_loop.sh` header comment — ~250 lines documenting every mechanism
   above at the source. It is the authoritative description of the loop's behaviour.
4. `verbatim/.claude/commands/expand-linear-next.md` — the skill; note how much of it is spent
   preventing §6.1 and §6.2.
5. `verbatim/CLAUDE.md` — an example of a quality bar written to be enforced by an unattended
   agent, for calibration when writing the target project's.

#!/usr/bin/env python3
"""Scan an auto-fix diff for gate-gaming patterns (token-free guardrail).

After the overnight loop dispatches a bounded LLM repair for an auto-fixable
gate failure, it runs this scanner over the staged diff BEFORE committing. The
scanner exists because an LLM told to make the gate green will, under a time
budget, take the cheapest path — which is usually to weaken the gate rather than
fix the code. If the diff does that, the loop reverts and halts for a human
instead of committing a silent degradation.

A diff is rejected if it:
  - adds a suppression comment (`# type: ignore`, `# noqa`, `# pragma`) or a
    `cast(` — the classic ways to fake a green ruff/mypy pass
  - adds a swallowed or over-broad except (`except:` / `except Exception: pass`)
  - modifies a frozen guardrail file (the checkers themselves, the Makefile, or
    the pyproject limits) — the gate must not be edited to pass
  - deletes a test file or removes an `assert` from one (weakening coverage)

Exit 0 if clean; exit 1 (printing every reason) if any pattern is found.

Usage:
  python scripts/scan_fix_diff.py --staged            # scan `git diff --cached`
  python scripts/scan_fix_diff.py --base <sha>         # scan `git diff <sha>`
  python scripts/scan_fix_diff.py --diff-file <path>   # scan a saved diff (tests)
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

# Suppressions that turn a real lint/type error green without fixing it. Matched
# case-sensitively so SQL "CAST(" in a string literal is not a false positive.
FORBIDDEN_ADDED = (
    "# type: ignore",
    "#type:ignore",
    "# noqa",
    "#noqa",
    "# pragma",
    "#pragma",
    "cast(",
)
# Broad/swallowed excepts, matched against the stripped, lower-cased added line.
BANNED_EXCEPT = ("except:", "except exception: pass")
# Files the auto-fixer may never touch — editing them games the gate directly.
FROZEN_PATHS = (
    "scripts/check_principles.py",
    "scripts/classify_gate_failure.py",
    "scripts/scan_fix_diff.py",
    "scripts/roadmap_cursor.py",
    "scripts/_roadmap_cursor_core.py",
    "scripts/loop_gates.py",
    "scripts/gate_baseline.py",
    "scripts/gate_attribution.py",
    "scripts/gate_confirm.py",
    "makefile",
    "pyproject.toml",
)
ASSERT_TOKEN = "assert"
GIT_HEADER_SPLIT = " b/"


@dataclass(frozen=True)
class Violation:
    """One gate-gaming pattern found in the diff."""

    path: str
    reason: str


@dataclass
class FileDiff:
    """The added/removed lines for one file in a unified diff."""

    path: str
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    deleted: bool = False


def _git_header_path(line: str) -> str:
    """Extract the b-side path from a `diff --git a/x b/x` header."""
    parts = line.split(GIT_HEADER_SPLIT, 1)
    return parts[1].strip() if len(parts) == 2 else line.strip()


def _update_file_diff(
    line: str, current: FileDiff | None, files: list[FileDiff]
) -> FileDiff | None:
    """Apply one unified-diff line; return the updated current FileDiff."""
    if line.startswith("diff --git "):
        new = FileDiff(_git_header_path(line))
        files.append(new)
        return new
    if current is None:
        return None
    if line.startswith("deleted file mode"):
        current.deleted = True
    elif line.startswith("+") and not line.startswith("+++"):
        current.added.append(line[1:])
    elif line.startswith("-") and not line.startswith("---"):
        current.removed.append(line[1:])
    return current


def parse_diff(diff_text: str) -> list[FileDiff]:
    """Parse a unified diff into per-file added/removed line lists."""
    files: list[FileDiff] = []
    current: FileDiff | None = None
    for line in diff_text.splitlines():
        current = _update_file_diff(line, current, files)
    return files


def _check_added(file_diff: FileDiff) -> list[Violation]:
    """Reject added suppressions and swallowed excepts."""
    out: list[Violation] = []
    for line in file_diff.added:
        for token in FORBIDDEN_ADDED:
            if token in line:
                reason = f"adds forbidden suppression '{token.strip()}'"
                out.append(Violation(file_diff.path, reason))
        if line.strip().lower() in BANNED_EXCEPT:
            out.append(Violation(file_diff.path, "adds a swallowed/broad except"))
    return out


def _check_frozen(file_diff: FileDiff) -> list[Violation]:
    """Reject any edit to a frozen guardrail file."""
    if file_diff.path.lower() in FROZEN_PATHS:
        return [Violation(file_diff.path, "modifies a frozen guardrail file")]
    return []


def _check_tests(file_diff: FileDiff) -> list[Violation]:
    """Reject test deletions and removed assertions."""
    if not file_diff.path.startswith(TEST_DIR_PREFIX):
        return []
    out: list[Violation] = []
    if file_diff.deleted:
        out.append(Violation(file_diff.path, "deletes a test file"))
    out.extend(
        Violation(file_diff.path, "removes an assertion from a test")
        for line in file_diff.removed
        if ASSERT_TOKEN in line
    )
    return out


def scan_diff(diff_text: str) -> list[Violation]:
    """Return every gate-gaming violation found in the diff."""
    violations: list[Violation] = []
    for file_diff in parse_diff(diff_text):
        violations.extend(_check_frozen(file_diff))
        violations.extend(_check_added(file_diff))
        violations.extend(_check_tests(file_diff))
    return violations


def load_diff(args: argparse.Namespace) -> str:
    """Load the diff text from a file, the staged index, or a base commit."""
    if args.diff_file:
        return Path(args.diff_file).read_text(encoding="utf-8")
    cmd = ["git", "diff", "--cached"] if args.staged else ["git", "diff", args.base]
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout


def parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse the CLI arguments."""
    parser = argparse.ArgumentParser(description="Scan an auto-fix diff for gate-gaming.")
    parser.add_argument("--staged", action="store_true", help="Scan `git diff --cached`.")
    parser.add_argument("--base", default="HEAD", help="Scan `git diff <base>` (default HEAD).")
    parser.add_argument("--diff-file", help="Scan a saved diff file instead of git.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    """Scan the loaded diff and report; return 1 if any forbidden pattern is found."""
    args = parse_args(argv)
    violations = scan_diff(load_diff(args))
    if not violations:
        print("scan: clean (0 forbidden patterns).")
        return 0
    for violation in violations:
        print(f"{violation.path}: {violation.reason}")
    print(f"\nscan: {len(violations)} forbidden pattern(s) — rejecting fix.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

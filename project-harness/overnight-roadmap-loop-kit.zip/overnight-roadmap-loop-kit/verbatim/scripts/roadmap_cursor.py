#!/usr/bin/env python3
"""Read/slice/mark the next unfinished ROADMAP phase (token-free CLI).

Boundary: invoked by ``/expand-linear-next`` (and its overnight driver
``scripts/expand_loop.sh``) so the skill loads only ONE phase body into context
instead of the whole ~2000-line ``project_harness/ROADMAP.md``. It is also the
single owner of the DONE-marker format: because the same parser both finds and
writes markers, a marker it appends is guaranteed to parse back cleanly, and the
reader/writer can never drift apart.

``project_harness/ROADMAP.md`` stays the single source of truth — this script only
derives from it (``--next``/``--slice``/``--verify``) or does a localized in-place
edit (``--mark``). It never persists a second store and never commits; the caller
folds the marked file into the task's own commit.

Modes (all print machine-readable stdout; human errors go to stderr):
  --next                 -> ``PHASE=<N> TASKS=<N.M,...> DEFERRED=<0|1>`` or ``ALL_DONE``
  --next-after N         -> same, but only phases numbered >= N (the overnight loop's
                            skip-ahead fallback: resume forward from a forced phase
                            instead of re-selecting the earliest unfinished one)
  --exclude "A B ..."    -> (with --next/--next-after) skip these phase numbers so an
                            already-skipped/blocked phase can't be re-selected
  --slice N              -> phase N's body (heading .. line before next heading)
  --mark N.M --date D    -> ``MARKED=N.M`` (or ``ALREADY_MARKED=N.M``); ``--unverified R``
                            renders the tolerant-gate ``⚠️ UNVERIFIED`` variant
  --verify               -> one finding per line; exit 1 if any (phase-gate doctor)

Exit codes: 0 = ok (incl. ALL_DONE / ALREADY_MARKED / clean verify); 1 = problem
(parse error, phase/task not found or duplicated, missing --date, write failure).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Run directly (`python scripts/roadmap_cursor.py`) puts scripts/ on sys.path[0],
# not the repo root, so the `scripts.` import below needs the repo root added — the
# same pattern classify_gate_failure.py and the unit tests use.
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from scripts._roadmap_cursor_core import (  # noqa: E402
    RoadmapCursorError,
    compute_next,
    find_task,
    parse_roadmap,
    render_marked,
    slice_range,
    verify,
)

_DEFAULT_ROADMAP = _REPO_ROOT / "project_harness" / "ROADMAP.md"
_ALL_DONE = "ALL_DONE"


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read/slice/mark the next ROADMAP phase.")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--next", action="store_true", dest="do_next")
    mode.add_argument("--next-after", type=int, metavar="N", dest="next_after")
    mode.add_argument("--slice", type=int, metavar="N", dest="slice_phase")
    mode.add_argument("--mark", metavar="N.M", dest="mark_task")
    mode.add_argument("--verify", action="store_true", dest="do_verify")
    parser.add_argument("--date", help="YYYY-MM-DD stamp for --mark (caller-supplied).")
    parser.add_argument("--unverified", help="tolerant-gate reason:checks for --mark.")
    parser.add_argument(
        "--exclude",
        help="Space/comma-separated phase numbers to skip (--next/--next-after only).",
    )
    parser.add_argument("--file", help="Roadmap path (defaults to project_harness/ROADMAP.md).")
    return parser.parse_args(argv)


def _parse_exclude(raw: str | None) -> frozenset[int]:
    """Parse the ``--exclude`` list ("234 235" or "234,235") into phase numbers."""
    if not raw:
        return frozenset()
    tokens = raw.replace(",", " ").split()
    try:
        return frozenset(int(token) for token in tokens)
    except ValueError as exc:
        raise RoadmapCursorError(
            f"--exclude expects space/comma-separated phase numbers, got {raw!r}.",
            kind="args",
        ) from exc


def _read_lines(path: Path) -> list[str]:
    try:
        return path.read_text(encoding="utf-8").splitlines(keepends=True)
    except OSError as exc:
        raise RoadmapCursorError(f"Cannot read {path}: {exc}", kind="io") from exc


def _atomic_write(path: Path, lines: list[str]) -> None:
    temp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        temp_path.write_text("".join(lines), encoding="utf-8")
        temp_path.replace(path)
    except OSError as exc:
        temp_path.unlink(missing_ok=True)
        raise RoadmapCursorError(f"Failed to write {path}: {exc}", kind="io") from exc


def _run_next(phases: tuple, after: int | None, exclude: frozenset[int]) -> int:
    if not phases:
        # Zero phases means the roadmap is missing/corrupt, NOT that everything is
        # done — routing this to ALL_DONE would make the overnight loop falsely stop.
        raise RoadmapCursorError(
            "No ## Phase headings found (roadmap missing/corrupt).", kind="empty"
        )
    nxt = compute_next(phases, after=after, exclude=exclude)
    if nxt is None:
        print(_ALL_DONE)
        return 0
    deferred = 1 if nxt.deferred else 0
    print(f"PHASE={nxt.number} TASKS={','.join(nxt.pending)} DEFERRED={deferred}")
    return 0


def _run_slice(phases: tuple, lines: list[str], number: int) -> int:
    start, end = slice_range(phases, number)
    sys.stdout.write("".join(lines[start:end]))
    return 0


def _run_mark(path: Path, phases: tuple, lines: list[str], args: argparse.Namespace) -> int:
    task = find_task(phases, args.mark_task)
    if task.done:
        print(f"ALREADY_MARKED={args.mark_task}")
        return 0
    _atomic_write(path, render_marked(lines, task, args.date, args.unverified))
    print(f"MARKED={args.mark_task}")
    return 0


def _run_verify(phases: tuple, lines: list[str]) -> int:
    findings = verify(phases, lines)
    for finding in findings:
        print(finding)
    return 1 if findings else 0


def _dispatch(path: Path, args: argparse.Namespace) -> int:
    lines = _read_lines(path)
    phases = parse_roadmap(lines)
    if args.do_next:
        return _run_next(phases, None, _parse_exclude(args.exclude))
    if args.next_after is not None:
        return _run_next(phases, args.next_after, _parse_exclude(args.exclude))
    if args.slice_phase is not None:
        return _run_slice(phases, lines, args.slice_phase)
    if args.mark_task is not None:
        return _run_mark(path, phases, lines, args)
    return _run_verify(phases, lines)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.mark_task is not None and not args.date:
        print("roadmap_cursor: --mark requires --date", file=sys.stderr)
        return 1
    path = Path(args.file) if args.file else _DEFAULT_ROADMAP
    try:
        return _dispatch(path, args)
    except RoadmapCursorError as exc:
        print(f"roadmap_cursor: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

# <Project name>

One-paragraph description of what this project is and does.

## Navigation

| What | Where |
|---|---|
| Active roadmap | `project_harness/ROADMAP.md` |
| Bug log | `project_harness/ISSUES.md` |
| Overnight-loop flags for morning review | `project_harness/human_verification.md` |

## Why this file matters to the overnight loop

`/expand-linear-next` reads this file before every task and enforces the rules below as a
hard gate — it is the *only* description of your quality bar the unattended loop ever sees.
A vague CLAUDE.md produces vague overnight work. Rules marked **(strict)** are treated as
non-negotiable: a change that violates one is not done, however correct it otherwise is.

Two things make these rules bite rather than decorate:

1. Whatever can be checked mechanically should be — `scripts/check_principles.py` enforces
   the structural block below, and `make check` enforces the rest. A rule no gate can see
   is a rule the loop will drift away from over a long night.
2. State the *reason* next to any rule that has cost you something. The loop reads the
   rationale, not just the rule, and applies it to cases you didn't enumerate.

## Coding principles

- No magic numbers or strings **(strict)**: promote to named constants or config.
- Validate at every external boundary **(strict)**: parse and type-check anything arriving
  from a network call, a config file, or disk, at the moment it arrives.
- Test the failure path before the happy path — sad-path coverage is where gaps hide.
- A fix that adds a new branch to shared logic must be tested together with the other
  conditions that function already handles, not just the new one in isolation — otherwise
  the new branch can silently shadow existing behaviour with no test catching it.
- Prefer deleting or reusing over adding. The best diff is the smallest one that meets the
  acceptance criterion.

## Structure

- **File length (strict)**: no code file over 300 lines. Split into focused modules.
- **Function length (strict)**: no function over 40 lines.
- **Nesting (strict)**: control-flow nesting must not exceed 3 levels; extract helpers.
- **One responsibility per module (strict)**: a module is a data model, a reader, a writer,
  a handler, a utility, a protocol, an adapter, or a test — never a mix.

## Error handling

- **Custom exception hierarchy (strict)**: never `raise Exception("…")`; domain errors carry
  structured fields.
- **Never swallow errors (strict)**: every `except` re-raises, raises a domain error, or
  logs and re-raises. No `except: pass`.
- **Validate only at boundaries (strict)**: internal calls you control are covered by types.

## Observability

- **Structured logging (strict)**: `logging.getLogger(__name__)`, never `print()`.

## Commits

- Format: `<type>(phase-N.task-M): <description>`.
- Mark the completed ROADMAP task `— ✅ DONE`, never delete it.
- State the task's acceptance criterion in the commit body.

# Overnight roadmap loop — transfer package

Extracted from a Linux work repo, to be adapted for a Windows personal project.

**Start here:** open `HOW_IT_WORKS.md`. It is written as a porting brief — hand it to Claude
Code in the target project and ask it to adapt the system, or read it yourself first.

## Contents

- **`HOW_IT_WORKS.md`** — architecture, lifecycle, the failure modes each defense exists for,
  and the porting checklist. The main document.
- **`ROADMAP_GRAMMAR.md`** — the roadmap format, the cursor CLI, and how to write a roadmap that
  survives an unattended night.
- **`verbatim/`** — byte-identical copies of the working files. Source of truth. Nothing here
  has been modified.
- **`generalized-reference/`** — one worked example of the conversion (CTF-specific blocks
  removed, project knobs lifted into `loop.config.sh` and `scripts/loop_gates.py`, smoke-tested
  against a throwaway repo). Reference only — prefer `verbatim/` plus the brief.

## The one-line summary

Reads a numbered roadmap, runs one Claude Code session per task, gates and commits each one, and
keeps going overnight until the roadmap is drained. Progress lives entirely in the roadmap's DONE
markers, so it resumes cleanly from any crash.

## The one thing to know before starting

It is bash and needs a real Linux userland (`flock`, `setsid`, process groups). **Run it under
WSL2**, with the project in the WSL filesystem — not Git Bash, and not `/mnt/c/`. See
`HOW_IT_WORKS.md` §7.1.

---
description: Repair an auto-fixable make-gate failure (ruff lint/format, mypy typecheck, or structural principles) to the CLAUDE.md quality bar, within scope, without gaming the gate. Dispatched by the overnight loop as a bounded single-attempt session; never invoked for test/schema failures (those halt for a human upstream).
argument-hint: "[path-to-classifier-report]   (the report lists exactly which auto-fixable checks are red and their output)"
---

# /fix-make-failure — bounded auto-repair of an auto-fixable gate failure

The overnight loop's classifier has already proven that **every test is green** and that the only
red checks are auto-fixable ones: ruff lint/format, mypy typecheck, or the structural principles in
`scripts/check_principles.py`. Your job is to make those checks green by **fixing the code
properly** — not by weakening the gate. A separate bash guardrail scans your diff after you finish
and **reverts everything + halts** if you take a shortcut, so a gamed fix wastes the whole attempt.

You run inside a single non-interactive `claude -p` turn with a hard time budget. There is no event
loop and no human to wake. Work in the foreground, finish, and **stop** — do not background anything.

## Step 0 — Read the failure report

`$ARGUMENTS` is the path to the classifier's report file. Read it. It contains one section per red
auto-fixable check with that check's captured output (the exact files, lines, and rules to fix).
Fix **only** what the report lists.

## Step 1 — Fix the root cause, to the quality bar

For each reported violation, apply the **smallest, simplest, paradigm-respecting** change that makes
it genuinely correct — the same bar as `/expand-linear-next`:

- **Structural principles** (file >300 lines, function >40 lines, nesting >3): extract along a **real
  responsibility boundary** — a named helper, a focused module — never an arbitrary split at the line
  count. A mechanically-shorter-but-incoherent split is a failure, not a fix.
- **ruff lint/format**: fix the actual issue (unused import, ordering, style). For formatting, apply
  the formatter's own result.
- **mypy typecheck**: fix the real type mismatch. A mypy error often signals a genuine design defect
  (a protocol that does not match its implementor — a DIP/LSP break); fix the design, not the symptom.
- Reuse existing helpers, constants, error types, and idioms from the surrounding module. Obey every
  CLAUDE.md strict rule.

## Step 2 — Hard prohibitions (the diff scanner enforces these — a hit reverts your whole fix)

- **Never** add `# type: ignore`, `# noqa`, `# pragma`, or `cast(...)` to silence a checker.
- **Never** add a swallowed or over-broad except (`except:` / `except Exception: pass`).
- **Never** edit a test to make it pass — no removing assertions, no deleting test files. (You should
  rarely need to touch `tests/` at all; a real fix lives in the source.)
- **Never** edit the guardrails themselves: `scripts/check_principles.py`, `scripts/classify_gate_failure.py`,
  `scripts/scan_fix_diff.py`, the `Makefile`, or `pyproject.toml` limits. Do not relax a threshold.
- Stay in scope: touch only the files named in the report and new modules you extract from them.

## Step 3 — Verify, then STOP — do NOT commit

1. Re-run the relevant checks in the foreground to confirm green, e.g. `uv run make principles`,
   `uv run ruff check .`, `uv run ruff format --check .`, `uv run mypy core/ agents_src/`.
2. Leave every edit **unstaged in the working tree**. **Do not `git add` and do not `git commit`** —
   the loop stages, scans, re-runs the full gate, and commits the repair itself as a separate marked
   commit. Committing here would break that flow.
3. Report the files you changed and the violations you fixed, then stop.

If you cannot fix a violation without a shortcut, a test edit, a guardrail edit, or a human decision:
**do not force it.** Leave the tree as-is and say so plainly — the loop will revert and halt for
review, which is the correct outcome.

---
description: Full deterministic quality gate — lint, typecheck, unit tests, integration tests, schema check, and structural principles. Reports a clear per-check breakdown with a PASS/FAIL verdict. No LLM calls; entirely token-free.
argument-hint: "(no arguments)"
---

# /clean-slate — full deterministic quality gate

Run every check in sequence. Do not skip or reorder steps.

---

## Steps

1. **Run `make check`** via Bash with a 15-minute timeout (`timeout: 900000`).
   This runs in order: lint → typecheck → unit tests → integration tests → schema-check.

2. **Parse the output** and report each sub-check on its own line:
   - `lint:         ✓` or `lint:         ✗  (<first error line>)`
   - `typecheck:    ✓` or `typecheck:    ✗  (<first error line>)`
   - `unit tests:   ✓ (N passed)` or `unit tests:   ✗`
   - `integration:  ✓ (N passed)` or `integration:  ✗`
   - `schema-check: ✓` or `schema-check: ✗`

3. **Run `make principles`** via Bash with a 3-minute timeout (`timeout: 180000`).
   Report:
   - `principles:   ✓` or `principles:   ✗  (<violations summary>)`

4. **Print a verdict line:**

   If all checks passed:
   ```
   ══ CLEAN SLATE: PASS ══  (lint ✓ typecheck ✓ tests ✓ integration ✓ schema ✓ principles ✓)
   ```

   If any check failed, print all failing sub-check outputs (first 10 lines each), then:
   ```
   ══ CLEAN SLATE: FAIL ══  (<list of failing checks>)
   ```

5. If any check failed, **stop here**. Do not suggest fixes or edit files unless the user asks.

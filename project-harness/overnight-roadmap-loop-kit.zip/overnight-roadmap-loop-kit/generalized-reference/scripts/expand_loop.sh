#!/usr/bin/env bash
# expand_loop.sh — Overnight expand-linear-next --auto --single-task loop
#
# Runs /expand-linear-next --auto --single-task in a fresh Claude Code session for
# each roadmap task sequentially until all phases are done, a task halts for human
# review, or the safety cap is reached.
#
# Why per-task sessions (--single-task):
#   Each session implements exactly one roadmap task, bounding context growth to
#   ~20K tokens per turn and removing any incentive to background a long make check
#   (the only work in each session). Crash recovery is atomic: a task is done iff
#   its DONE-marked commit landed — no partial session state to reconcile.
#
# Phase lifecycle (managed by this script, not the skill):
#   1. Per-task: claude -p "/expand-linear-next --auto --single-task"
#      → implements one task, commits, emits AUTO_STATUS: TASK_COMPLETE or PHASE_COMPLETE
#      (or, when its own per-task `make check` is a HALT-class red and the tolerant gate
#      is on, TASK_COMPLETE_BASELINE_RED / TASK_COMMITTED_REGRESSION — see "Per-task
#      tolerant gate" below).
#   2. On PHASE_COMPLETE: run_phase_gate() runs make check + make principles in bash
#      (no Claude session needed — the gate is a deterministic command, not an LLM task).
#      2a. If the gate is red: classify_gate_failure.py routes it. An auto-fixable
#          failure (ruff/mypy/principles) gets ONE bounded `claude -p /fix-make-failure`
#          attempt (AUTOFIX_TIMEOUT); its diff is scanned for gate-gaming
#          (scan_fix_diff.py) and the full gate re-run before the repair is committed
#          SEPARATELY and flagged in human_verification.md. If that repair attempt
#          fails to land, it reverts only itself (never the phase's own task commits).
#      2b. Curator policy: a gate that's still red after that (repair not attempted,
#          or attempted and unsuccessful) does NOT halt the loop — it's logged to
#          human_verification.md for morning review and the phase's commits are
#          pushed regardless. Only MAX_CONSECUTIVE_RED_GATES red gates in a row
#          (default 2 — see _gate_red_continue) escalates to a real HALT, on the
#          theory that a genuinely broken base shouldn't get more phases piled on
#          top of it. Tune with --max-red-gates; --no-autofix skips the repair
#          attempt but still only counts toward the same tolerance, not an instant
#          HALT. The pre-flight and post-roadmap clean-slate gates
#          (run_clean_slate_gate) are unaffected by this — they still HALT on any
#          red gate, since by construction those are opt-in / already-finished-work
#          checks, not a mid-roadmap phase boundary.
#   3. Gate passes: run_soft_review() writes per-phase findings to nightly_review_report.md
#      (best-effort; never blocks or halts the loop). At the tail, file_soft_review_issues()
#      files this run's flagged findings into ISSUES.md as NEEDS-VERIFICATION entries.
#   4. git push origin <start_branch>
#   5. Loop back to the next task
#
# Blocked-prerequisite skip-ahead:
#   If a task's own acceptance criterion can't be started yet — it needs something
#   (another not-yet-done task's output, a curator sign-off) that doesn't exist —
#   the skill emits `AUTO_STATUS: HALT blocked-prerequisite phase-<N> task-<id>`
#   instead of implementing a guess. Rather than HALT the whole run, this is almost
#   always a transient blocker (true tomorrow, not tonight), so the loop logs it to
#   human_verification.md and force-advances to the next ROADMAP phase for the rest
#   of this run (see next_roadmap_phase_after) — the blocked phase's tasks stay
#   un-DONE, so a fresh run naturally re-attempts it first, same as any other
#   unfinished phase. MAX_CONSECUTIVE_BLOCKED_PHASES (default 2, --max-blocked-phases)
#   is the same kind of backstop as the red-gate tolerance above: that many phases in
#   a row blocked with zero progress between them halts for real instead of skipping
#   through the rest of the roadmap for nothing.
#
# Per-task tolerant gate (RED_COMMIT_TOLERANCE, default on; --no-red-commit to disable):
#   Historically a HALT-class red (a unit/integration test or schema-check) in a task's
#   OWN per-task `make check` halted the entire run with the work uncommitted — one such
#   red could burn a whole night (the motivating incident: 6 PRE-EXISTING, unrelated
#   test-isolation failures halted every Phase 242 task). Now the skill instead commits
#   the work, marked `✅ DONE ⚠️ UNVERIFIED` in ROADMAP.md and flagged in
#   human_verification.md, and scripts/gate_attribution.py attributes the red against a
#   PER-PHASE baseline (EXPAND_BASELINE_FILE) of pre-existing failures — re-seeded at
#   every phase boundary from the union of BASELINE_SEED_RUNS halt-class runs, and never
#   written mid-phase, so a task cannot launder its own regression into it:
#     * TASK_COMPLETE_BASELINE_RED — the task added NO new failure vs the baseline
#       (zero real debt): treated like TASK_COMPLETE, continue to the next task.
#     * TASK_COMMITTED_REGRESSION — the task INTRODUCED >=1 new failure that reproduced
#       on two consecutive re-runs (scripts/gate_confirm.py, so a flake is not charged
#       to it): committed + flagged, and the loop CONTINUES with the phase's next task.
#       It used to forfeit the rest of the phase; that cost phase 247 its irreversible
#       cutover task on 2026-07-31 over two flakes the task never touched.
#   MAX_RED_COMMITS (default 3, --max-red-commits) is the backstop: that many
#   regressions in a row (no clean/baseline-red task between) halts for real, since it
#   signals a systemically broken tree rather than isolated debt. Committed-red work is
#   local until the next completing phase pushes the branch (or a fresh run recovers it).
#
# Claude usage-limit auto-restart:
#   If a task's output looks like the Claude Code subscription's own usage/rate limit
#   (not a pipeline LLM call — the outer `claude -p` session driving this script), the
#   loop does not HALT outright. It stashes any uncommitted work the interrupted task
#   left behind (reversible — never committed, since it has no DONE marker and would
#   break the one-commit-per-task convention), sleeps until the usage window resets
#   (a rolling ~5h from the hit — NOT next midnight, which used to lose the rest of the
#   night plus the next day on an early hit), then re-execs this script with its
#   original argv (`exec "$0" ...`), which re-runs pre-flight and resumes from the
#   next unfinished ROADMAP task (the skill is stateless — DONE markers are the only
#   source of truth). Caveat: if --phase was passed on the original invocation, it is
#   re-applied on restart too since argv is replayed verbatim; harmless once that
#   phase is done (the skill still auto-advances) but worth knowing if you forced a
#   specific phase.
#
#   Runaway-loop guards (usage_limit_should_halt()), any one of which halts instead of
#   chaining another restart:
#     - restart cap:   MAX_USAGE_LIMIT_RESTARTS (default 1) auto-restarts per exec
#                       lineage. A brand-new top-level launch (cron/manual) starts a
#                       fresh lineage since it inherits no env, so this resets nightly.
#     - no progress:   two hits with the same ROADMAP DONE-count in between (nothing
#                       completed since the last hit) — a robust, format-agnostic
#                       stand-in for "stuck on the same work"; ROADMAP.md's phase
#                       headers are not reliably parseable (older phases can carry
#                       stale unfinished tasks under an otherwise-archived heading).
#     - rapid repeat:  two hits closer than MIN_USAGE_LIMIT_REPEAT_GAP_SECONDS (300s)
#                       apart — real usage-limit exhaustion takes hours to recur, so
#                       this fast a repeat means a marker false-positive or an outage.
#     - stash pileup:  MAX_USAGE_LIMIT_STASHES (default 2) unresolved auto-restart
#                       stashes already accumulated — restarts aren't recovering.
#   Separately, past_morning_stop() (MORNING_STOP_HOUR_LOCAL, default 08:00 RESTART_TZ)
#   applies to every lineage, not just restarted ones: once past it, the loop stops
#   STARTING new work (the next task or phase) but never interrupts anything
#   already running — see its own comment below for why this is a clean stop, not a HALT.
#
# Branch policy (GitLab — manual merges break the overnight flow):
#   This loop NEVER creates or moves a top-level branch and NEVER opens a merge
#   request. The linear skill commits every task directly onto the branch that is
#   checked out when the loop starts (the "start branch") and this script pushes
#   only that branch after each phase gate passes. No ephemeral branches or
#   worktrees are created. A branch-drift guard halts the loop if the repo HEAD
#   ever leaves the start branch.
#
# Easiest launch (no hand-typed nohup; fire during the day, starts at 8pm):
#   ./scripts/expand_loop.sh --background --start-at 20:00
#     → self-detaches (setsid/nohup), logs to project_harness/overnight_<ts>.log
#       (gitignored), prints the PID + tail/stop hints, returns immediately, then
#       sleeps until 20:00 RESTART_TZ before doing any work. Drop --start-at to
#       begin right away; drop --background to run in the foreground.
#
# Usage:
#   ./scripts/expand_loop.sh [--background] [--start-at HH:MM] [--stop-at HH:MM]
#                            [--max-tasks N] [--max-phases N] [--sleep-secs S] [--phase N]
#                            [--timeout-secs T] [--model MODEL] [--review-model MODEL]
#                            [--pat-file PATH] [--no-push] [--preflight]
#                            [--spaced | --no-sleep] [--no-commit-dirty]
#
# Roadmap-halt one-shot retry:
#   A roadmap HALT (red gate, timeout, unexpected stop — anything but a usage
#   limit) triggers ONE overnight re-attempt at HALT_RETRY_HOUR_LOCAL (03:00
#   RESTART_TZ) when the repo is still on the start branch, the retry budget
#   (MAX_HALT_RETRIES=1) is unspent, the last retry made ROADMAP progress, and
#   that time is within MAX_HALT_RETRY_WAIT_SECONDS (12h). If any of those fail
#   the loop stops for morning review and exits non-zero.
#
# Flags:
#   --background      Self-detach and run the loop in the background (setsid, or
#     (--daemon)      nohup fallback), logging to project_harness/overnight_<ts>.log;
#                     prints the PID + tail/stop hints and returns. Saves you from
#                     wrapping the command in `nohup … &` by hand.
#   --start-at HH:MM  Sleep until the next HH:MM in RESTART_TZ (default Europe/Paris)
#     (--at 8pm)      before doing ANY work — launch during the day, start in the
#                     evening. Accepts 24h ("20:00") or am/pm ("8pm"). Only the
#                     original launch defers; usage-limit/halt re-execs skip it.
#   --stop-at HH:MM   Override the morning stop (default 08:00 RESTART_TZ) past which
#     (--morning-stop) the loop stops STARTING new phases and runs only the reviews.
#                     Push it later on weekends (e.g. --stop-at 14:00) to drain more
#                     phases. Survives usage-limit/halt re-execs (rides ORIGINAL_ARGS).
#                     crypto/pyjail) after the roadmap loop. OFF by default now — the
#   --max-tasks N     Hard cap on task iterations (default 100) — the outer-loop
#                     safety bound.
#   --max-phases N    Stop cleanly after N fully-COMPLETED phases (each gated, soft-
#                     reviewed, and pushed); 0 = unlimited (default). Independent of
#                     --max-tasks; whichever cap trips first stops the loop. Built for
#                     a bounded daytime smoke test — e.g. --max-phases 2 to verify the
#                     per-phase machinery end-to-end before a full overnight run. NOTE:
#                     this caps PHASES, not task iterations (it no longer aliases
#                     --max-tasks).
#                     A phase counts as completed when the ROADMAP says its tasks are
#                     all done (roadmap_cursor --next-after), not when the skill emits a
#                     particular token — a red-committed last task used to suppress the
#                     PHASE_COMPLETE token and with it the whole boundary, so the cap
#                     silently never tripped.
#   --sleep-secs S    Pause between tasks in seconds (default 15). Ignored under
#                     --no-sleep (which zeroes it).
#   --spaced          Pace mode: keep the default inter-task (15s) and inter-phase
#                     (~7min) sleeps. This is the default behaviour; the flag is an
#                     explicit alias for it. Mutually exclusive with --no-sleep.
#   --trim-sleep      Cut ONLY the inter-phase regen pause to 60s (leaves the inter-task
#                     sleep intact). OFF by default. Use on nights where task throughput
#                     matters more than spacing phases out for usage-headroom regen.
#   --no-sleep        Pace mode: run tasks and phases back-to-back — zero BOTH the
#                     inter-task pause and the inter-phase regen pause. Fastest
#                     throughput, but burns Claude-subscription usage faster (may trip
#                     the usage-limit → window-reset restart path sooner). The SIGTERM-retry
#                     backoff and usage-limit restart sleep are recovery mechanisms, not
#                     pacing, and are left intact. Mutually exclusive with --spaced.
#   --phase N         Force phase N on the first iteration; subsequent iterations
#                     auto-advance.
#   --timeout-secs T  Per-task claude timeout in seconds (default 5400 = 90 min).
#   --model MODEL     Pin the implementation sessions to a specific model.
#   --review-model M  Model for the per-phase soft review (default haiku).
#   --pat-file PATH   Path to the GitLab PAT file (default ~/.ctf-pat, chmod 600).
#   --commit-dirty    If the tree is dirty at startup, auto-commit everything
#                      (git add -A + chore commit) instead of HALTing. This is now
#                      the DEFAULT — an unattended launch should never be blocked by
#                      leftover local edits (which is exactly what stalled the loop
#                      before). The flag remains accepted as an explicit no-op alias.
#   --no-commit-dirty Restore the old safety: HALT at startup if the tree is dirty,
#                      instead of auto-committing. Use when you'd rather resolve
#                      unreviewed local work by hand before the loop bakes it into
#                      the run's history.
#
# Environment:
#   PERMISSION_MODE   claude permission flag (default --dangerously-skip-permissions).
#   PAT_FILE          Override for --pat-file.
#   GIT_USERNAME      GitLab username for HTTPS auth (default oauth2).
#   REVIEW_MODEL      Override for --review-model.
#   EXPAND_NOTIFY_CMD Optional command run once at exit for alerting. Receives
#                     the final status as $1 and a one-line summary as $2 (also
#                     exported as EXPAND_STATUS / EXPAND_SUMMARY). Best-effort:
#                     failures here never change the loop's exit code. Unset by
#                     default (no notification).
#   RESTART_TZ        IANA timezone used to compute "midnight" for the usage-limit
#                     auto-restart (default Europe/Paris).
#   MORNING_STOP_HOUR_LOCAL  RESTART_TZ time (default 08:00:00) past which the loop
#                     stops STARTING new work (the next task or phase)
#                     but never interrupts anything already running. Applies to
#                     every lineage, not just restarted ones. Override per-launch
#                     with --stop-at HH:MM (precedence: --stop-at > env var > default).
#
# Credential setup:
#   Store the GitLab PAT in ~/.ctf-pat (chmod 600). Create scripts/git_askpass.sh
#   (chmod 700) — see that file for details. Set GIT_ASKPASS to the script path
#   before git operations so the token never appears in process listings or logs.
#
# Output:
#   project_harness/expand_auto_log.md       — machine-readable run log (appended)
#   project_harness/human_verification.md   — HALT reasons for morning review
#   <harness>/nightly_review_report.md      — per-phase soft code review findings
#   <harness>/ISSUES.md                     — findings filed from those soft reviews
#   /tmp/expand_loop_<PID>.log              — full stdout/stderr for this session

set -euo pipefail

# ── project configuration ─────────────────────────────────────────────────────
# Everything project-specific lives in loop.config.sh next to this script's parent
# directory (override the path with LOOP_CONFIG_FILE). It is sourced BEFORE every
# default below, so a value it exports wins over the `${VAR:-default}` fallbacks.
# Nothing else in this file should need editing to move it to a new project.
_LOOP_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOOP_CONFIG_FILE="${LOOP_CONFIG_FILE:-$_LOOP_SELF_DIR/../loop.config.sh}"
if [[ -f "$LOOP_CONFIG_FILE" ]]; then
  # shellcheck source=/dev/null
  source "$LOOP_CONFIG_FILE"
fi

# Harness directory (ROADMAP.md, ISSUES.md and every report this loop writes).
HARNESS_DIR="${HARNESS_DIR:-project_harness}"
# Interpreter prefix for the helper scripts. Word-split intentionally.
PY_RUN="${PY_RUN:-uv run python}"
# The three deterministic gate commands. Word-split intentionally.
GATE_CHECK_CMD="${GATE_CHECK_CMD:-uv run make check}"
GATE_PRINCIPLES_CMD="${GATE_PRINCIPLES_CMD:-uv run make principles}"
GATE_ROADMAP_VERIFY_CMD="${GATE_ROADMAP_VERIFY_CMD:-uv run make roadmap-verify}"
# Set 0 (or --no-push) to run fully local: every push becomes a no-op and no
# credential setup is attempted. Commits still land on the start branch.
PUSH_ENABLED="${PUSH_ENABLED:-1}"

# ── self-backgrounding (--background / --daemon) ──────────────────────────────
# Detach the loop so it survives the terminal closing, WITHOUT the caller having
# to type `nohup … &` by hand. When --background is present we re-launch this same
# script detached (setsid, or nohup as a fallback), pointed at a dated log under
# project_harness/ (gitignored: overnight_*.log/*.pid), print the PID + tail/stop
# hints, and exit. The relaunched child's argv has --background stripped, so it
# runs the loop normally and never re-backgrounds — and neither does the
# usage-limit / halt-retry re-exec, since it replays that already-stripped argv.
#
# PID caveat (util-linux setsid): `setsid CMD &` forks internally whenever the
# caller (this shell's backgrounded job) is already a process-group leader —
# true here — and, without -w, the setsid WRAPPER exits the instant it has
# forked, well before the real work starts. `$!` captured right after therefore
# names a process that is already gone (verified empirically on this host:
# util-linux 2.32.1), so `kill $!` silently no-ops instead of stopping anything.
# Fixed below by having the detached CHILD report its own `$$` through a
# pidfile once it's actually running, instead of trusting the parent's `$!`.
_bg_want=""; _bg_filtered=()
for _a in "$@"; do
  case "$_a" in
    --background|--daemon) _bg_want=1 ;;
    *) _bg_filtered+=("$_a") ;;
  esac
done
if [[ -n "$_bg_want" && -z "${EXPAND_LOOP_BACKGROUNDED:-}" ]]; then
  _bg_repo="$(cd "$(dirname "$0")/.." && pwd)"
  _bg_stamp="$(date +%Y-%m-%d_%H%M%S)"
  _bg_log="$_bg_repo/$HARNESS_DIR/overnight_${_bg_stamp}.log"
  _bg_pidfile="$_bg_repo/$HARNESS_DIR/overnight_${_bg_stamp}.pid"
  export EXPAND_LOOP_BACKGROUNDED=1
  export EXPAND_LOOP_PIDFILE="$_bg_pidfile"
  if command -v setsid >/dev/null 2>&1; then
    setsid "$0" "${_bg_filtered[@]+"${_bg_filtered[@]}"}" >"$_bg_log" 2>&1 </dev/null &
  else
    nohup "$0" "${_bg_filtered[@]+"${_bg_filtered[@]}"}" >"$_bg_log" 2>&1 </dev/null &
  fi
  # Poll briefly for the child's self-reported PID (see the write below); it
  # appears within milliseconds of forking. Fall back to `$!` — with a caveat
  # printed — only if it never shows up (defensive; shouldn't happen).
  _bg_pid=$!
  for _bg_wait in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
    [[ -s "$_bg_pidfile" ]] && break
    sleep 0.1
  done
  if [[ -s "$_bg_pidfile" ]]; then
    _bg_real_pid="$(cat "$_bg_pidfile")"
    echo "expand_loop.sh detached in the background (PID $_bg_real_pid)."
  else
    _bg_real_pid="$_bg_pid"
    echo "expand_loop.sh detached in the background (PID $_bg_real_pid — unconfirmed, pidfile never appeared)."
  fi
  echo "  log:  $_bg_log"
  echo "  pid:  $_bg_pidfile"
  echo "  tail: tail -f \"$_bg_log\""
  echo "  stop: kill $_bg_real_pid"
  exit 0
fi

# Runs in the detached child only (EXPAND_LOOP_BACKGROUNDED set, whether this is
# the original background launch or a later usage-limit/halt-retry `exec "$0"`
# of it — same PID survives exec, so this is safe to re-run and just rewrites
# the same value): report our own PID so the launcher above has a real,
# live-for-the-whole-run handle instead of the wrapper's short-lived `$!`.
if [[ -n "${EXPAND_LOOP_BACKGROUNDED:-}" && -n "${EXPAND_LOOP_PIDFILE:-}" ]]; then
  echo "$$" > "$EXPAND_LOOP_PIDFILE" 2>/dev/null || true
fi

# Captured before arg parsing consumes "$@" so a usage-limit restart can re-exec
# this script with the exact flags it was originally invoked with.
ORIGINAL_ARGS=("$@")

# ── defaults ─────────────────────────────────────────────────────────────────
MAX_TASKS=100        # hard cap on task iterations (outer-loop safety bound)
MAX_PHASES=0         # cap on COMPLETED phases (0 = unlimited). Set via --max-phases for a
                     # bounded daytime smoke test: stop cleanly after N fully-finished phases
                     # (each gated, soft-reviewed, and pushed). Independent of MAX_TASKS;
                     # whichever cap trips first stops the loop.
SLEEP_SECS=15        # pause between tasks
FORCE_PHASE=""       # "phase N" to force a starting phase (iteration 1 only)
CLAUDE_TIMEOUT=5400  # per-task claude timeout in seconds (90 min)
MODEL=""             # optional --model pin for implementation sessions
REVIEW_MODEL="${REVIEW_MODEL:-claude-haiku-4-5-20251001}"
SIGTERM_RETRIES=1    # retries on a transient signal-kill of the outer `claude` driver process
# 137 (SIGKILL) and 143 (SIGTERM) — the same pair core/llm/_claude_cli_common.py's
# _SIGNAL_TERMINATION_EXIT_CODES already treats as transient/retryable for the pipeline's
# own inner claude_cli calls. Matching that existing, validated convention rather than
# retrying every nonzero exit — a real CLI error (bad args, auth, a genuine crash) should
# still surface as a HALT, not burn a retry.
SIGNAL_KILL_RETRY_EXIT_CODES="137 143"
SIGTERM_RETRY_BACKOFF_SECS=15  # backoff before the one signal-kill retry — a recovery delay,
                     # kept independent of pacing so --no-sleep can't turn it into a hot loop
PERMISSION_MODE="${PERMISSION_MODE:---dangerously-skip-permissions}"
PAT_FILE="${PAT_FILE:-$HOME/.roadmap-loop-pat}"
GIT_USERNAME="${GIT_USERNAME:-oauth2}"
LOCKFILE="/tmp/expand_loop.lock"
RESTART_TZ="${RESTART_TZ:-Europe/Paris}"  # tz for the morning-stop / halt-retry / usage-limit clocks
NO_PREFLIGHT=1       # default: SKIP the pre-flight clean-slate gate so the loop always attempts the
                     # roadmap instead of refusing to start on a slow/red tree and building nothing
                     # overnight. Per-phase gates (run_phase_gate) still verify every phase. Opt the
                     # startup gate back in with --preflight.
COMMIT_DIRTY=1       # 1 (default) = auto-commit a dirty tree at startup; --no-commit-dirty restores the HALT-on-dirty safety
PHASE_SLEEP_SECS="${PHASE_SLEEP_SECS:-400}"  # ~7 min pause after a phase push, to let usage headroom regen
TRIM_PHASE_SLEEP=""       # --trim-sleep sets this; OFF by default. When on, the inter-phase pause is cut to
                          # TRIM_PHASE_SLEEP_SECS — prioritise task throughput over usage-headroom regen.
TRIM_PHASE_SLEEP_SECS=60  # inter-phase pause (seconds) when --trim-sleep is active
PACE_MODE=""         # "" = default spaced pacing; "spaced" = explicit alias; "nosleep" = back-to-back (--no-sleep)
START_AT=""          # "" = start immediately; "HH:MM"/"8pm" (RESTART_TZ) = sleep until that time before any work
DEFERRED_START_DRIFT_WARN_SECONDS=600  # log a loud warning if the --start-at sleep overshot by more than
                     # this (10 min) — likely host suspend/hibernate eating into the overnight window

# ── soft review ───────────────────────────────────────────────────────────────
# After each green phase gate, run_soft_review() code-reviews the phase's own diff in a
# cheap headless session and records findings; file_soft_review_issues() drains them into
# ISSUES.md at the tail. Entirely best-effort — no path here HALTs or changes the exit code.
REVIEW_SESSION_TIMEOUT="${REVIEW_SESSION_TIMEOUT:-1800}"  # cap on the issue-filing session (30 min)

# ── auto-fix repair (single bounded attempt on an auto-fixable red phase gate) ─
# When run_phase_gate() goes red, the loop classifies the failure in bash
# (scripts/classify_gate_failure.py). Only auto-fixable classes (ruff, mypy,
# structural principles) — never test/schema failures — trigger a single bounded
# `claude -p /fix-make-failure` repair. The repair's diff is scanned for
# gate-gaming (scripts/scan_fix_diff.py) and the full gate re-run before it is
# committed separately; any failure reverts to the pre-fix SHA and HALTs.
AUTOFIX_ENABLED="${AUTOFIX_ENABLED:-1}"   # set 0 (or --no-autofix) to always HALT on a red gate
AUTOFIX_TIMEOUT="${AUTOFIX_TIMEOUT:-900}" # hard cap on the single repair session (15 min)
AUTOFIX_CLASSIFY_TIMEOUT=1800             # cap on classification (may re-run the test suite)
GATE_TIMEOUT_KILL_AFTER=10                # SIGKILL this long after a `timeout`-delivered SIGTERM
                                           # if the target ignores it — a hung child (e.g. a leftover
                                           # docker process holding stdout open) otherwise blocks the
                                           # `| tee` pipeline forever even after `timeout` "fires".

# ── phase-gate red-gate tolerance (curator policy: throughput over cleanliness) ─
# A red make check / make principles at phase-gate time — even after the single
# autofix attempt couldn't green it — no longer halts the whole overnight run.
# Curator policy: lint noise (file-length, magic numbers, ...) and even a red
# test suite are morning cleanup, not a reason to stop attempting further
# ROADMAP phases. The phase's commits are pushed either way; the red gate is
# only logged to VERIFICATION_MD for morning review. MAX_CONSECUTIVE_RED_GATES
# is the one backstop that still halts: that many phase gates in a row staying
# red is a signal the base itself is broken (not just cosmetically red), and
# grinding out further phases on top of it would just compound garbage instead
# of buying real progress.
MAX_CONSECUTIVE_RED_GATES="${MAX_CONSECUTIVE_RED_GATES:-2}"

# ── tolerant per-task gate: commit a red task, flag it, keep going ─────────────
# (curator policy: never lose a whole night to a red gate — accumulate small,
# visible debt instead.) When /expand-linear-next's per-task `make check` is red
# on a HALT-class check (a unit/integration test or schema-check), the skill no
# longer stops the run. It commits the task's work anyway — marked
# `✅ DONE ⚠️ UNVERIFIED` in ROADMAP.md (still counts as DONE so it is never
# re-attempted, but greppable as debt) and flagged in VERIFICATION_MD for morning
# review — and emits one of two tokens the loop acts on:
#   * TASK_COMPLETE_BASELINE_RED — the red is PRE-EXISTING: the task added no new
#     failure vs the phase baseline (scripts/gate_baseline.py did the set diff).
#     Zero real debt; treated exactly like a clean TASK_COMPLETE — continue.
#   * TASK_COMMITTED_REGRESSION — the task INTRODUCED >=1 new failure that survived
#     re-running (scripts/gate_confirm.py). Committed + flagged loudly, and the loop
#     CONTINUES to the phase's next task. It used to skip the rest of the phase; that
#     cost phase 247 its cutover task on 2026-07-31 over two flaky tests the task had
#     not touched, and left the two-ring migration half-applied. Abandoning a phase is
#     the expensive failure, so the debt is now carried task-by-task instead.
# MAX_RED_COMMITS is the backstop, mirroring MAX_CONSECUTIVE_RED_GATES: that many
# regressions in a row (each adding NEW failures, no green/baseline-red task
# between) means the tree is systemically broken, not isolated debt — halt for
# real. --no-red-commit restores the old behaviour: a HALT-class red HALTs the run
# with the work left uncommitted. The skill reads RED_COMMIT_TOLERANCE (on/off) and
# EXPAND_BASELINE_FILE (the phase baseline to diff against) from the environment —
# both exported here so the child `claude -p` inherits them.
RED_COMMIT_TOLERANCE="${RED_COMMIT_TOLERANCE:-1}"   # 0 (or --no-red-commit) = old HALT-on-red-task behaviour
MAX_RED_COMMITS="${MAX_RED_COMMITS:-3}"             # consecutive task-introduced regressions before a real HALT
EXPAND_BASELINE_FILE="/tmp/expand_baseline_$$.json" # per-phase seeded pre-existing failing set (never written mid-phase)
# Re-seeded at every phase boundary from the union of this many halt-class runs, so a
# load-dependent flake that is red in either run lands in the baseline instead of being
# charged to the phase's first task. One run misses whichever flakes happened to pass.
BASELINE_SEED_RUNS="${BASELINE_SEED_RUNS:-2}"
BASELINE_SEED_TIMEOUT_SECS=1800                     # covers BASELINE_SEED_RUNS full halt-class runs
export RED_COMMIT_TOLERANCE EXPAND_BASELINE_FILE

# ── blocked-prerequisite skip-ahead (curator policy: don't burn the night on a task
# that can't start yet) ────────────────────────────────────────────────────────
# `/expand-linear-next` emits `AUTO_STATUS: HALT blocked-prerequisite phase-<N>
# task-<id>` when a task's acceptance criterion depends on something that genuinely
# doesn't exist yet (another not-yet-done task's output, a curator sign-off with no
# recorded result, ...) — nothing was implemented, so unlike gate-red there is no
# repair attempt. The blocker is almost always transient (true tomorrow, not tonight),
# so rather than HALT the whole run, the loop force-advances past that phase to the
# next one for the REST of this run (see next_roadmap_phase_after below) — the
# skipped phase's tasks stay un-DONE, so a fresh run (tonight's halt-retry, or
# tomorrow) naturally re-attempts it first, same as any other unfinished phase.
# MAX_CONSECUTIVE_BLOCKED_PHASES is the same kind of backstop as
# MAX_CONSECUTIVE_RED_GATES: that many phases in a row blocked with zero task
# progress between them means something systemic (e.g. every remaining phase
# shares one unmet dependency), not independent stalls — halt for real instead of
# skipping through the entire rest of the roadmap for nothing.
MAX_CONSECUTIVE_BLOCKED_PHASES="${MAX_CONSECUTIVE_BLOCKED_PHASES:-2}"

# ── usage-limit runaway-loop guards ───────────────────────────────────────────
# All four are independent tripwires evaluated in usage_limit_should_halt(); any one
# tripping halts instead of chaining another auto-restart. State that must survive
# the "exec $0" restart (restart count, done-count and epoch of the last hit) rides
# across as exported env vars — exec preserves the environment, and a brand-new
# top-level launch (cron/manual) starts with none of these set, so the guards reset
# per lineage rather than accumulating across separate nights.
MAX_USAGE_LIMIT_RESTARTS=2     # hard ceiling on chained auto-restarts per exec lineage (an ~8h night can
                               # span two 5h windows, so allow recovering from a hit in each)
MIN_USAGE_LIMIT_REPEAT_GAP_SECONDS=300  # hits closer than this look like a bug/outage, not real quota use
MAX_USAGE_LIMIT_STASHES=2      # accumulated auto-restart stashes beyond this: restarts aren't recovering
USAGE_LIMIT_STASH_TAG="expand_loop usage-limit auto-restart WIP"
# The Claude-subscription usage limit resets on a rolling ~5h window, NOT at midnight.
# Waiting this long FROM the hit provably clears the window: it started <=5h before the
# hit, so hit+5h is at or past the reset — tokens are back on resume. This is why the
# wait is a reset-window, not a fixed "next midnight" (which lost the rest of the night
# plus the next day whenever a limit hit early).
USAGE_LIMIT_RESET_WAIT_SECONDS="${USAGE_LIMIT_RESET_WAIT_SECONDS:-18000}"  # 5h rolling-window length
MAX_USAGE_LIMIT_WAIT_SECONDS=21600  # 6h defensive ceiling — never sleep longer than this for a reset

# ── morning stop (every lineage) ──────────────────────────────────────────────
# Past this RESTART_TZ time, stop STARTING new work — the next task, the next
# phase — but never interrupt anything already
# running (see past_morning_stop() below and its call sites). Applies uniformly
# to the original launch, a usage-limit restart, and a halt-retry alike: the
# point is "day is for humans," not "this specific recovery path looks stuck."
MORNING_STOP_HOUR_LOCAL="${MORNING_STOP_HOUR_LOCAL:-08:00:00}"

# ── roadmap-halt one-shot retry ───────────────────────────────────────────────
# Distinct from the usage-limit restart above: when the roadmap loop HALTs with
# tasks still unfinished (a red gate, timeout, or unexpected stop — anything but a
# usage limit), give it ONE more overnight attempt at HALT_RETRY_HOUR_LOCAL before
# giving up. If that attempt still cannot drain the roadmap (or the budget / wait
# window is exhausted, or the repo drifted off the start branch), the loop falls
# through to the tail report checkpoint and exits for morning review. State
# rides across the exec as env vars, exactly like the usage-limit lineage guards.
MAX_HALT_RETRIES=1                  # one overnight re-attempt per exec lineage after a roadmap HALT
HALT_RETRY_HOUR_LOCAL="03:00:00"    # re-attempt a halted roadmap at this RESTART_TZ time
MAX_HALT_RETRY_WAIT_SECONDS=43200   # 12h: if the next HALT_RETRY_HOUR_LOCAL is further off, skip the retry and just
                                    # verify. 12h covers any evening/overnight halt (3am is within reach) while a
                                    # post-3am daytime halt (next 3am ~24h away) correctly skips straight to verify.
HALT_RETRY_STASH_TAG="expand_loop halt-retry WIP"

# ── arg parsing ───────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --max-tasks)              MAX_TASKS="$2"; shift 2 ;;
    --max-phases)             MAX_PHASES="$2"; shift 2 ;;
    --sleep-secs)             SLEEP_SECS="$2"; shift 2 ;;
    --phase)                  FORCE_PHASE="phase $2"; shift 2 ;;
    --timeout-secs)           CLAUDE_TIMEOUT="$2"; shift 2 ;;
    --model)                  MODEL="$2"; shift 2 ;;
    --review-model)           REVIEW_MODEL="$2"; shift 2 ;;
    --pat-file)               PAT_FILE="$2"; shift 2 ;;
    --no-preflight)           NO_PREFLIGHT=1; shift ;;   # no-op alias: pre-flight is skipped by default now
    --preflight)              NO_PREFLIGHT=""; shift ;;   # opt back in to the startup clean-slate gate
    --start-at|--at)          START_AT="$2"; shift 2 ;;
    --stop-at|--morning-stop) MORNING_STOP_HOUR_LOCAL="$2"; shift 2 ;;
    --background|--daemon)    shift ;;                 # handled before arg parsing; ignored here
    --no-push)                PUSH_ENABLED=0; shift ;;
    --trim-sleep)             TRIM_PHASE_SLEEP=1; shift ;;
    --no-autofix)             AUTOFIX_ENABLED=0; shift ;;
    --commit-dirty)           COMMIT_DIRTY=1; shift ;;
    --no-commit-dirty)        COMMIT_DIRTY=0; shift ;;
    --max-red-gates)          MAX_CONSECUTIVE_RED_GATES="$2"; shift 2 ;;
    --max-blocked-phases)     MAX_CONSECUTIVE_BLOCKED_PHASES="$2"; shift 2 ;;
    --max-red-commits)        MAX_RED_COMMITS="$2"; shift 2 ;;
    --no-red-commit)          RED_COMMIT_TOLERANCE=0; shift ;;
    --spaced)
      if [[ -n "$PACE_MODE" && "$PACE_MODE" != "spaced" ]]; then
        echo "Error: --spaced and --no-sleep are mutually exclusive" >&2; exit 1
      fi
      PACE_MODE="spaced"; shift ;;
    --no-sleep)
      if [[ -n "$PACE_MODE" && "$PACE_MODE" != "nosleep" ]]; then
        echo "Error: --spaced and --no-sleep are mutually exclusive" >&2; exit 1
      fi
      PACE_MODE="nosleep"; shift ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

# ── pace mode ─────────────────────────────────────────────────────────────────
# --no-sleep zeroes BOTH pacing sleeps (inter-task + the inter-phase regen
# pause). Applied here, after parsing, so it authoritatively overrides any earlier
# --sleep-secs on the same command line. Recovery sleeps (SIGTERM-retry backoff,
# usage-limit window-reset restart) are deliberately NOT pacing and stay untouched.
if [[ "$PACE_MODE" == "nosleep" ]]; then
  SLEEP_SECS=0
  PHASE_SLEEP_SECS=0
fi

# --trim-sleep cuts ONLY the inter-phase regen pause (not the inter-task sleep) to
# TRIM_PHASE_SLEEP_SECS, trading usage-headroom regen for throughput. Applied after
# --no-sleep so it never resurrects a pause the latter already zeroed (nosleep wins).
if [[ -n "$TRIM_PHASE_SLEEP" && "$PACE_MODE" != "nosleep" ]]; then
  PHASE_SLEEP_SECS=$TRIM_PHASE_SLEEP_SECS
fi

# --stop-at HH:MM (alias --morning-stop) overrides MORNING_STOP_HOUR_LOCAL, the
# RESTART_TZ time past which the loop stops STARTING new phases and runs only the
# reviews. Default 08:00:00 is the weekday window; a weekend launch can push it
# later (e.g. --stop-at 14:00) to drain more phases. Validated fail-fast here so a
# typo dies at startup, not hours later when MORNING_STOP_EPOCH is resolved.
if ! TZ="$RESTART_TZ" date -d "today $MORNING_STOP_HOUR_LOCAL" +%s >/dev/null 2>&1; then
  echo "Error: --stop-at '$MORNING_STOP_HOUR_LOCAL' is not a valid time (want HH:MM, e.g. 14:00)." >&2
  exit 1
fi

# --max-phases N caps COMPLETED phases (0 = unlimited). Validated fail-fast so a
# non-integer or negative value dies at startup rather than silently disabling the cap.
if ! [[ "$MAX_PHASES" =~ ^[0-9]+$ ]]; then
  echo "Error: --max-phases '$MAX_PHASES' is not a non-negative integer (0 = unlimited)." >&2
  exit 1
fi

# ── paths ─────────────────────────────────────────────────────────────────────
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="$REPO_ROOT/$HARNESS_DIR"
SESSION_LOG="/tmp/expand_loop_$$.log"
VERIFICATION_MD="$LOG_DIR/human_verification.md"
AUTO_LOG="$LOG_DIR/expand_auto_log.md"
REVIEW_REPORT="$LOG_DIR/nightly_review_report.md"
ISSUES_FILE="$LOG_DIR/ISSUES.md"
ROADMAP_FILE="${ROADMAP_FILE:-$LOG_DIR/ROADMAP.md}"
# Run-scoped accumulator (NOT a committed report — /tmp, per PID) of this run's soft-review
# findings, populated by run_soft_review only for phases that flagged something and drained by
# file_soft_review_issues() at the tail. Per-PID, so a usage-limit re-exec starts a fresh one:
# findings from before such a restart stay in nightly_review_report.md but are not re-filed.
SOFT_REVIEW_ACCUM="/tmp/expand_soft_review_$$.md"
GIT_ASKPASS_SCRIPT="$REPO_ROOT/scripts/git_askpass.sh"
TIMESTAMP() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
# The append-only reports this run writes to. All appends use `>>`, which
# creates a missing file on first write — so these are never pre-`touch`ed;
# doing so would manufacture an untracked/empty file right before the
# clean-tree gate below, tripping it for no reason.
ACTIVE_REPORT_FILES=("$VERIFICATION_MD" "$AUTO_LOG" "$REVIEW_REPORT")

mkdir -p "$LOG_DIR"

trap 'rm -f /tmp/expand_task_*_$$.txt "${EXPAND_LOOP_PIDFILE:-}"' EXIT

log()        { echo "[$(TIMESTAMP)] $*" | tee -a "$SESSION_LOG"; }
log_verify() {
  # Appends a HALT block to human_verification.md (also written by the skill).
  {
    echo ""
    echo "## [$(TIMESTAMP)] SHELL-LEVEL HALT — $1"
    echo ""
    echo "$2"
    echo ""
  } >> "$VERIFICATION_MD"
}

# ── unexpected-failure trap ────────────────────────────────────────────────────
# Only fires for genuine unguarded failures: the handler no-ops whenever errexit
# is disabled (the `$-` check), so it stays silent inside the many `set +e` gate
# regions where non-zero exits are expected and handled explicitly. Purely
# diagnostic — it never calls exit, so the original exit code is preserved.
on_err() {
  case $- in *e*) ;; *) return 0 ;; esac
  log "ERROR: unexpected shell failure (exit $1) near line $2 — see $SESSION_LOG"
}
trap 'on_err "$?" "$LINENO"' ERR

# ── terminal-status notification (opt-in) ──────────────────────────────────────
# If EXPAND_NOTIFY_CMD is set, it is run once at exit with the final status as
# $1 and a one-line summary as $2 (e.g. EXPAND_NOTIFY_CMD='curl -s -d "$2" URL'
# or a script that pushes to Slack/ntfy/email). Best-effort: any failure here is
# swallowed so notification problems never change the loop's own exit status.
notify() {
  [[ -n "${EXPAND_NOTIFY_CMD:-}" ]] || return 0
  local status="$1" summary="$2"
  EXPAND_STATUS="$status" EXPAND_SUMMARY="$summary" \
    bash -c "$EXPAND_NOTIFY_CMD" _ "$status" "$summary" \
    >>"$SESSION_LOG" 2>&1 || log "WARNING: EXPAND_NOTIFY_CMD failed (non-fatal)."
}

# ── single-instance guard ─────────────────────────────────────────────────────
# Two overlapping runs would corrupt each other's git state.
exec 200>"$LOCKFILE"
if command -v flock >/dev/null 2>&1; then
  if ! flock -n 200; then
    echo "Another expand_loop.sh holds $LOCKFILE — exiting." >&2
    exit 1
  fi
else
  echo "WARNING: flock not available; skipping concurrency guard." >&2
fi

# ── archive last run's reports on a genuinely fresh launch ────────────────────
# These five files are append-only across the whole script's life, so left
# alone they'd accumulate every night forever — making it hard to tell last
# night's findings from a run two weeks ago. On a brand-new top-level launch
# (never a usage-limit/halt-retry re-exec, which inherits EXPAND_LOOP_STARTED=1
# and must keep appending to THIS run's own active files), move any existing
# content aside into a dated archive folder and commit that move by itself —
# before the clean-tree gate runs — so it never gets mistaken for the user's
# own uncommitted work or trips a HALT under --no-commit-dirty. Runs after the
# single-instance guard above so two overlapping launches can't race the mv.
archive_previous_reports() {
  [[ -z "${EXPAND_LOOP_STARTED:-}" ]] || return 0
  local f has_content=""
  for f in "${ACTIVE_REPORT_FILES[@]}"; do
    [[ -s "$f" ]] && has_content=1
  done
  [[ -n "$has_content" ]] || return 0
  local archive_dir="$LOG_DIR/reports_archive/$(date -u +%Y-%m-%dT%H%M%SZ)"
  mkdir -p "$archive_dir"
  for f in "${ACTIVE_REPORT_FILES[@]}"; do
    [[ -s "$f" ]] || continue
    mv "$f" "$archive_dir/$(basename "$f")"
  done
  # Only stage the archive dir. The ACTIVE_REPORT_FILES were just mv'd away above
  # (and are gitignored anyway), so naming them here makes `git add` hit a
  # nonexistent pathspec, abort the WHOLE add (exit 128), and stage nothing — which
  # silently skipped the archive commit every run, leaving the snapshot untracked.
  git -C "$REPO_ROOT" add -A -- "$LOG_DIR/reports_archive" 2>/dev/null || true
  if ! git -C "$REPO_ROOT" diff --cached --quiet 2>/dev/null; then
    git -C "$REPO_ROOT" commit -q -m "chore(project-harness): archive previous overnight-loop reports" || true
    log "Archived previous run's reports to $archive_dir ($(git -C "$REPO_ROOT" rev-parse --short HEAD))."
  fi
}
archive_previous_reports

log "=== expand_loop.sh starting ==="
log "repo:          $REPO_ROOT"
log "max-tasks:     $MAX_TASKS"
log "max-phases:    $([[ $MAX_PHASES -gt 0 ]] && echo "$MAX_PHASES (stop after this many completed phases — bounded test run)" || echo "(unlimited)")"
log "sleep-secs:    $SLEEP_SECS"
log "pace:          $([[ "$PACE_MODE" == "nosleep" ]] && echo "back-to-back (--no-sleep — all pacing sleeps zeroed)" || echo "spaced (${SLEEP_SECS}s/task, ${PHASE_SLEEP_SECS}s/phase)")"
log "timeout:       ${CLAUDE_TIMEOUT}s"
log "model:         ${MODEL:-"(claude default)"}"
log "review-model:  $REVIEW_MODEL"
log "perm-mode:     ${PERMISSION_MODE:-"(settings.json allowlist)"}"
log "force-phase:   ${FORCE_PHASE:-"(auto — next unfinished)"}"
log "start-at:      ${START_AT:-"(now)"}${START_AT:+" $RESTART_TZ (defers first work until then)"}"
log "pre-flight:    $([[ -n "$NO_PREFLIGHT" ]] && echo "SKIPPED (default; always attempt the roadmap — per-phase gates still verify)" || echo "enabled (--preflight)")"
log "commit-dirty:  $([[ "$COMMIT_DIRTY" == "1" ]] && echo "auto-commit dirty tree at startup (default)" || echo "HALT on dirty tree (--no-commit-dirty)")"
log "push:          $([[ "$PUSH_ENABLED" == "1" ]] && echo "enabled (origin/$START_BRANCH)" || echo "DISABLED (--no-push) — commits stay local")"
log "autofix:       $([[ "$AUTOFIX_ENABLED" == "1" ]] && echo "enabled (1 attempt, ${AUTOFIX_TIMEOUT}s)" || echo "(disabled — HALT on red gate)")"
log "red-gate cap:  $MAX_CONSECUTIVE_RED_GATES consecutive red phase gates tolerated before halting (red gates never revert a phase's commits)"
log "blocked cap:   $MAX_CONSECUTIVE_BLOCKED_PHASES consecutive blocked-prerequisite phases tolerated before halting (each skips ahead to the next phase instead)"
log "red-commit:    $([[ "$RED_COMMIT_TOLERANCE" == "1" ]] && echo "tolerant — a HALT-class red per-task gate commits the work (⚠️ UNVERIFIED) + flags it; pre-existing red continues, introduced regression skips the phase; $MAX_RED_COMMITS consecutive regressions before halting" || echo "strict (--no-red-commit) — a HALT-class red per-task gate HALTs with the work left uncommitted")"
log "restart-tz:    $RESTART_TZ (usage-limit auto-restart)"
log "phase-sleep:   ${PHASE_SLEEP_SECS}s between phases${TRIM_PHASE_SLEEP:+ (--trim-sleep: trimmed for throughput)}"
log "restart-cap:   $MAX_USAGE_LIMIT_RESTARTS auto-restart(s)/lineage, min-gap ${MIN_USAGE_LIMIT_REPEAT_GAP_SECONDS}s, max-stashes $MAX_USAGE_LIMIT_STASHES"
log "usage-reset:   wait ${USAGE_LIMIT_RESET_WAIT_SECONDS}s (~$(( USAGE_LIMIT_RESET_WAIT_SECONDS / 3600 ))h rolling window) after a limit hit, then restart — unless the reset lands past the morning stop, then stop for tonight"
log "morning-stop:  ${MORNING_STOP_HOUR_LOCAL} $RESTART_TZ — stop starting new work past this time (every lineage); resolved to a fixed target once work actually starts, below"
log "halt-retry:    $MAX_HALT_RETRIES retry/lineage at ${HALT_RETRY_HOUR_LOCAL} $RESTART_TZ (within ${MAX_HALT_RETRY_WAIT_SECONDS}s), then stop for morning review"
log "this-lineage:  usage-restart #${EXPAND_LOOP_RESTART_COUNT:-0}, halt-retry #${EXPAND_LOOP_HALT_RETRY_COUNT:-0} (0/0 = original launch)"
log "session-log:   $SESSION_LOG"
log "verification:  $VERIFICATION_MD"
log "review-report: $REVIEW_REPORT"

# ── verify claude CLI is available ────────────────────────────────────────────
if ! command -v claude &>/dev/null; then
  log "ERROR: 'claude' CLI not found in PATH. Install Claude Code first."
  log_verify "claude CLI not found" \
    "The 'claude' binary was not in PATH when expand_loop.sh ran."
  exit 1
fi

# ── PAT / GIT_ASKPASS credential setup ───────────────────────────────────────
# The GIT_ASKPASS script prints the token to git's credential pipe on demand.
# The token never appears in process listings, logs, or .git/config.

push_branch() {
  # Single choke point for every push. A no-op when PUSH_ENABLED=0 (--no-push),
  # so the loop runs fully local without a remote or a token. Returns the push's
  # own exit code otherwise, so existing callers' error handling is unchanged.
  if [[ "$PUSH_ENABLED" != "1" ]]; then
    log "Push skipped (PUSH_ENABLED=0): commits stay local on $START_BRANCH."
    return 0
  fi
  git push origin "$START_BRANCH" "$@"
}

_setup_credentials() {
  if [[ "$PUSH_ENABLED" != "1" ]]; then
    log "Push disabled (--no-push): skipping git credential setup."
    return 0
  fi
  if [[ ! -f "$PAT_FILE" ]]; then
    log "WARNING: PAT file not found at $PAT_FILE — pushes will fail."
    log "  Create: echo '<your-pat>' > $PAT_FILE && chmod 600 $PAT_FILE"
    return 0  # non-fatal: loop runs, HALT only on actual push failure
  fi
  local perms
  perms="$(stat -c '%a' "$PAT_FILE" 2>/dev/null || echo "unknown")"
  if [[ "$perms" != "600" ]]; then
    log "WARNING: $PAT_FILE permissions are $perms (expected 600). Run: chmod 600 $PAT_FILE"
  fi
  if [[ ! -x "$GIT_ASKPASS_SCRIPT" ]]; then
    log "WARNING: $GIT_ASKPASS_SCRIPT not found or not executable — pushes will fail."
    log "  See scripts/git_askpass.sh and run: chmod 700 scripts/git_askpass.sh"
    return 0
  fi
  export GIT_ASKPASS="$GIT_ASKPASS_SCRIPT"
  export GIT_USERNAME="$GIT_USERNAME"
  # Do NOT log the token value or PAT_FILE contents.
  log "Credential setup: GIT_ASKPASS=$GIT_ASKPASS_SCRIPT (token file: $PAT_FILE)"

  # Actually exercise the token now, before the (possibly hours-long) --start-at
  # sleep — a token that merely exists with the right chmod can still be
  # expired/revoked, and that's only caught here or at the first push otherwise.
  # Runs before any deferred start so a launch-time `tail -f` on the session log
  # (printed by --background) shows this within seconds; non-fatal by the same
  # philosophy as the rest of this function — the loop still runs, giving a
  # window to fix the PAT before real work starts, and only a later actual push
  # failure HALTs.
  local ls_remote_exit
  set +e
  timeout 20 git -C "$REPO_ROOT" ls-remote --exit-code origin HEAD >/dev/null 2>>"$SESSION_LOG"
  ls_remote_exit=$?
  set -e
  if [[ $ls_remote_exit -ne 0 ]]; then
    log "WARNING: PAT check failed — 'git ls-remote origin' exited $ls_remote_exit. The token in"
    log "  $PAT_FILE may be expired/wrong/revoked. Fix it now; pushes will fail until you do."
  else
    log "Credential setup: PAT verified against origin (git ls-remote OK)."
  fi
}
_setup_credentials

cd "$REPO_ROOT"

# ── deferred start (--start-at HH:MM / --at 8pm) ──────────────────────────────
# Sleep until the next START_AT in RESTART_TZ before ANY work, so you can launch
# during the day (ideally with --background) and have the loop begin in the evening.
# Placed before the clean-tree gate on purpose: the dirty-tree/auto-commit decision
# and pre-flight are then evaluated at work-start time (e.g. 20:00), after you've
# finished editing for the day — not at launch. Only the ORIGINAL launch defers: a
# usage-limit or halt re-exec inherits EXPAND_LOOP_STARTED=1 and skips straight to
# work, so it never re-defers to the next 20:00. The lock (held since startup) keeps
# a single instance across the wait. Invalid time strings fail fast, before sleeping.
if [[ -n "$START_AT" && -z "${EXPAND_LOOP_STARTED:-}" ]]; then
  _sa_now="$(date +%s)"
  if ! _sa_target="$(TZ="$RESTART_TZ" date -d "today $START_AT" +%s 2>/dev/null)"; then
    log "ERROR: --start-at '$START_AT' is not a valid time (want HH:MM, e.g. 20:00, or 8pm)."
    log_verify "Invalid --start-at value" "--start-at '$START_AT' could not be parsed as a time; loop did not start."
    exit 1
  fi
  [[ $_sa_target -gt $_sa_now ]] || _sa_target="$(TZ="$RESTART_TZ" date -d "tomorrow $START_AT" +%s)"
  _sa_wait=$(( _sa_target - _sa_now ))
  log "Deferred start: sleeping ${_sa_wait}s until $START_AT $RESTART_TZ ($(TZ="$RESTART_TZ" date -d "@$_sa_target"))..."
  sleep "$_sa_wait"
  log "Deferred start: reached $START_AT $RESTART_TZ — starting now."
  # Sanity-check how long that sleep actually took. Plain `sleep` has no defense
  # against the host suspending/hibernating mid-wait (a laptop lid closing, a VM
  # pausing) — the process just resumes whenever the host does, arbitrarily late.
  # This can't recover lost time, but it turns a silently-shifted schedule into a
  # loud, diagnosable log line instead of a mystery in the morning.
  _sa_actual_wait=$(( $(date +%s) - _sa_now ))
  _sa_drift=$(( _sa_actual_wait - _sa_wait ))
  if [[ $_sa_drift -gt $DEFERRED_START_DRIFT_WARN_SECONDS ]]; then
    log "WARNING: deferred-start sleep took ${_sa_actual_wait}s, expected ~${_sa_wait}s (${_sa_drift}s drift) — the host likely suspended/hibernated mid-wait. Check system power/suspend settings if this loop must run unattended overnight."
    log_verify "Deferred-start sleep drifted ${_sa_drift}s" \
      "The --start-at sleep expected ~${_sa_wait}s but took ${_sa_actual_wait}s. This usually means the host suspended or hibernated while the loop waited, eating into the overnight window. If this loop needs to run unattended, disable suspend/sleep on this host (e.g. systemd-inhibit, power settings) rather than relying on the process staying scheduled."
  fi
fi
# Marks the deferred-start wait as satisfied so re-execs (usage-limit / halt-retry)
# inherit it and never re-defer. Harmless when START_AT is unset.
export EXPAND_LOOP_STARTED=1

# Resolved ONCE here, to the next occurrence of MORNING_STOP_HOUR_LOCAL at or
# after WORK actually starts — deliberately AFTER the --start-at sleep above,
# not at script-launch time. Computing it before that sleep was itself a bug:
# launching before MORNING_STOP_HOUR_LOCAL (e.g. 07:30, ordinary for
# `--start-at 20:00`) resolves "today 08:00" as still in the future at launch,
# pins the epoch there, and then the ~12h deferred-start sleep carries the
# clock straight past it — so past_morning_stop() is already true the instant
# work begins at 20:00 and the loop does zero work, the same silent-failure
# shape as the original bug this mechanism fixed. Anchoring here instead means
# "next occurrence" is always resolved relative to when the loop is actually
# about to start working, which is the only reference point that makes sense.
MORNING_STOP_EPOCH="$(TZ="$RESTART_TZ" date -d "today $MORNING_STOP_HOUR_LOCAL" +%s)"
[[ $MORNING_STOP_EPOCH -gt $(date +%s) ]] \
  || MORNING_STOP_EPOCH="$(TZ="$RESTART_TZ" date -d "tomorrow $MORNING_STOP_HOUR_LOCAL" +%s)"
log "morning-stop:  resolved to $(TZ="$RESTART_TZ" date -d "@$MORNING_STOP_EPOCH") ($MORNING_STOP_HOUR_LOCAL $RESTART_TZ) — stop starting new work past this; never interrupts work already running"

# ── start-branch capture + clean-tree gate ────────────────────────────────────
START_BRANCH="$(git rev-parse --abbrev-ref HEAD)"
if [[ "$START_BRANCH" == "HEAD" ]]; then
  log "ERROR: detached HEAD — check out a branch before running the overnight loop."
  exit 1
fi
if [[ -n "$(git status --porcelain)" ]]; then
  if [[ "$COMMIT_DIRTY" == "1" ]]; then
    log "Working tree is dirty — auto-committing before start (--commit-dirty)."
    git add -A
    # A failed auto-commit (a pre-commit hook rejecting the staged tree) must HALT with a
    # clear reason, never crash the loop via `set -e` with an opaque "unexpected shell
    # failure". The classic trigger is a git-TRACKED file being written concurrently — a
    # nohup log the loop itself appends to — which pre-commit sees mutate mid-run and fails
    # ("files were modified by this hook"). Reset the half-staged index so a re-run starts
    # from the same pre-start state rather than a partially-staged one.
    if ! git commit -q -m "chore(overnight-loop): auto-commit pending work before run" \
         >>"$SESSION_LOG" 2>&1; then
      log "ERROR: startup auto-commit failed — a pre-commit hook rejected the staged tree (see $SESSION_LOG)."
      log_verify "Startup auto-commit failed — loop did NOT start" \
        "git commit of the dirty tree failed at startup. Most common cause: a staged file is being written concurrently (a tracked log the loop appends to — gitignore/untrack it), or a pre-commit hook rejected a staged file (a newly-added file >500KB, a runs//.cache path, or a merge-conflict marker). The staged changes were reset so the tree is back to its pre-start state; nothing was committed. Resolve the offending file, then re-run."
      git reset -q >>"$SESSION_LOG" 2>&1 || true
      exit 1
    fi
    log "Auto-commit landed: $(git rev-parse --short HEAD)"
    log_verify "Dirty tree auto-committed at startup" \
      "git status --porcelain was non-empty; --commit-dirty was set, so everything was staged and committed as $(git rev-parse --short HEAD) before the loop started. Review that commit's diff — it was never inspected by a human."
  else
    log "ERROR: working tree is not clean. Commit or stash before running."
    log_verify "Dirty working tree at startup" \
      "git status --porcelain was non-empty; refusing to start."
    exit 1
  fi
fi
log "start-branch: $START_BRANCH (all commits land here; script never creates a branch)"

# ── pre-flight crash recovery ─────────────────────────────────────────────────
# The linear skill creates no worktrees or en/* branches; this sweep clears
# any leftovers from a prior parallel /expand-next run or manual experiment.
preflight_sweep() {
  git worktree prune 2>/dev/null || true
  while IFS= read -r wt; do
    [[ -n "$wt" ]] || continue
    log "preflight: removing orphaned worktree $wt"
    git worktree remove --force "$wt" 2>/dev/null || true
  done < <(git worktree list --porcelain 2>/dev/null \
             | awk '/^worktree /{print $2}' | grep "/.claude/worktrees/" || true)
  while IFS= read -r br; do
    [[ -n "$br" ]] || continue
    log "preflight: deleting stray task branch $br"
    git branch -D "$br" 2>/dev/null || true
  done < <(git for-each-ref --format='%(refname:short)' refs/heads/en/ 2>/dev/null || true)
}
preflight_sweep

# ── divergence check (fetch only — never rebases or moves the branch) ─────────
if git fetch origin "$START_BRANCH" --quiet 2>/dev/null; then
  if git rev-parse "origin/$START_BRANCH" >/dev/null 2>&1 \
     && ! git merge-base --is-ancestor "origin/$START_BRANCH" HEAD 2>/dev/null; then
    log "WARNING: origin/$START_BRANCH has commits not in local HEAD; pushes may be rejected (non-fast-forward)."
  fi
else
  log "WARNING: git fetch failed (offline or no remote?) — continuing without divergence check."
fi

# ── helpers ───────────────────────────────────────────────────────────────────
assert_on_start_branch() {
  local cur
  cur="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo UNKNOWN)"
  [[ "$cur" == "$START_BRANCH" ]] && return 0
  log "ERROR: repo left on branch '$cur', expected '$START_BRANCH'. Halting."
  log_verify "Branch drift (iteration $1)" \
    "After the task the repo HEAD was on '$cur', not the start branch '$START_BRANCH'. Inspect git status/log and restore HEAD to '$START_BRANCH' manually before resuming."
  return 1
}

# Phase numbers from every `## Phase N: ...` heading in ROADMAP.md, in file order —
# the same heading shape /expand-linear-next itself parses (Step 1.3).
roadmap_phase_numbers() {
  grep -oE '^## Phase [0-9]+' "$ROADMAP_FILE" 2>/dev/null | grep -oE '[0-9]+'
}

# First ROADMAP phase number strictly after $1 that is not in the space-separated
# skip list $2. Prints it and returns 0; prints nothing and returns 1 if none remain.
# Used only to skip ahead past a blocked-prerequisite phase — it does not check
# whether that phase still has undone tasks, because it doesn't need to: the skill
# itself now falls back to the next not-done phase when a forced phase turns out
# already complete (expand-linear-next.md Step 1.5), so forcing a finished phase
# number here is always safe, just a wasted round trip in the rare case it happens.
next_roadmap_phase_after() {
  local after="$1" skip=" $2 " num
  while IFS= read -r num; do
    [[ -n "$num" && "$num" -gt "$after" ]] || continue
    [[ "$skip" == *" $num "* ]] && continue
    echo "$num"
    return 0
  done < <(roadmap_phase_numbers)
  return 1
}

# True iff ROADMAP phase $1 has no task left to do. Read straight off the roadmap via
# roadmap_cursor (`--next-after N` prints the first not-done phase >= N, or ALL_DONE),
# NOT inferred from which AUTO_STATUS token the skill happened to emit.
#
# That distinction is the whole point. Phase completion used to be signalled solely by
# `AUTO_STATUS: PHASE_COMPLETE`, but the skill deliberately replaces that token with
# TASK_COMPLETE_BASELINE_RED / TASK_COMMITTED_REGRESSION when the last task of a phase
# commits red. On 2026-07-31 that swallowed four consecutive phase boundaries: no gate,
# no review, no push, and --max-phases never counted a single completed phase, so a
# 2-phase run walked to phase 251. The roadmap markers are the source of truth the skill
# itself resumes from, so they cannot disagree with what was actually committed.
#
# Conservative on failure: a cursor error returns 1 (not a boundary), leaving the run to
# continue task-by-task exactly as before rather than gating and pushing on a guess.
phase_now_complete() {
  local phase_num="$1" cursor_out next_num
  [[ "$phase_num" =~ ^[0-9]+$ ]] || return 1
  cursor_out="$(cd "$REPO_ROOT" && $PY_RUN scripts/roadmap_cursor.py \
    --next-after "$phase_num" 2>/dev/null)" || return 1
  grep -q '^ALL_DONE' <<<"$cursor_out" && return 0
  next_num="$(grep -oE '^PHASE=[0-9]+' <<<"$cursor_out" | grep -oE '[0-9]+' | head -1)"
  [[ -n "$next_num" && "$next_num" -gt "$phase_num" ]]
}

# Same substrings core/llm/_claude_cli_common.py uses to classify a claude CLI
# reply as a usage/rate limit — kept in sync so both layers agree on wording.
USAGE_LIMIT_MARKERS_REGEX='usage limit|rate limit|rate_limit|limit reached|limit will reset|too many requests|session limit'
# How many trailing lines of a task's output to check for a usage-limit marker
# (matches the window already used elsewhere for the non-zero-exit diagnostic
# dump). A real usage-limit refusal is the CLI's own last message before it
# stops; scanning the WHOLE transcript instead risks matching incidental
# prose anywhere in it — several ROADMAP tasks touch this repo's own
# rate-limit handling code, so a diff/test/docstring can legitimately contain
# these words without the run itself hitting any limit.
USAGE_LIMIT_TAIL_LINES=20

looks_like_usage_limit() {
  tail -n "$USAGE_LIMIT_TAIL_LINES" "$1" 2>/dev/null | grep -qiE "$USAGE_LIMIT_MARKERS_REGEX"
}

# Stashes any uncommitted work (tracked + untracked, .gitignore respected) left
# behind by a task the usage limit interrupted mid-way. Not a commit: this is
# partial/untested work with no DONE marker, and committing it would break the
# one-commit-per-task convention and could bake broken code into history. Not
# skipped either: both this script's own pre-flight gate and the
# /expand-linear-next skill's internal gate refuse to run on a dirty tree, so
# leaving it dirty would make the restart halt immediately for the same reason
# it was trying to avoid. Stashing is reversible — see human_verification.md
# for recovery instructions.
stash_dirty_tree_before_restart() {
  [[ -n "$(git status --porcelain)" ]] || return 0
  local stash_msg="$USAGE_LIMIT_STASH_TAG ($(TIMESTAMP))"
  log "Working tree is dirty after the usage-limit hit — stashing before restart: $stash_msg"
  if git stash push -u -m "$stash_msg" >>"$SESSION_LOG" 2>&1; then
    log_verify "Uncommitted work stashed before usage-limit restart" \
      "The task interrupted by the usage limit left uncommitted changes, stashed (not committed — untested, no DONE marker) as \"$stash_msg\". Run 'git stash list' to inspect. The retried task most likely redid this work from scratch on resume — compare with 'git stash show -p' before 'git stash drop'; use 'git stash pop' instead if it wasn't redone."
  else
    log "ERROR: git stash failed — working tree remains dirty; the restarted process's pre-flight gate will HALT."
    log_verify "Stash failed before usage-limit restart" \
      "git stash push -u failed while preparing for the usage-limit auto-restart (see $SESSION_LOG). The tree is still dirty; the restarted process will hit the pre-flight clean-tree gate and HALT. Inspect and stash/commit manually, then re-run."
  fi
}

# Four independent tripwires against a runaway restart cycle. Any one tripping
# means "restarting again is unlikely to help" — logs why and returns 0 (halt).
# Returns 1 when none trip (proceed with restart_after_usage_reset). DONE_BEFORE
# is the main loop's global (this iteration's pre-task ROADMAP DONE count).
usage_limit_should_halt() {
  local now_epoch gap stash_count
  now_epoch="$(date +%s)"

  if [[ -n "${EXPAND_LOOP_LAST_LIMIT_EPOCH:-}" ]]; then
    gap=$(( now_epoch - EXPAND_LOOP_LAST_LIMIT_EPOCH ))
    if [[ $gap -lt $MIN_USAGE_LIMIT_REPEAT_GAP_SECONDS ]]; then
      log "ERROR: usage limit hit again only ${gap}s after the last one (threshold ${MIN_USAGE_LIMIT_REPEAT_GAP_SECONDS}s)."
      log_verify "Rapid repeat usage-limit hit (${gap}s apart)" \
        "Two usage-limit signals arrived ${gap}s apart. Real usage-limit exhaustion takes hours to recur, so this fast a repeat looks like a marker false-positive or a provider outage, not real quota use. Halting instead of restarting again. Check $SESSION_LOG and the claude CLI's own status before resuming."
      return 0
    fi
  fi

  if [[ "${EXPAND_LOOP_RESTART_COUNT:-0}" -ge $MAX_USAGE_LIMIT_RESTARTS ]]; then
    log "ERROR: usage limit hit again after ${EXPAND_LOOP_RESTART_COUNT:-0} prior auto-restart(s) (cap: $MAX_USAGE_LIMIT_RESTARTS)."
    log_verify "Usage-limit restart cap reached" \
      "This run already auto-restarted ${EXPAND_LOOP_RESTART_COUNT:-0} time(s) after a usage-limit hit and just hit the limit again. Halting rather than chaining another restart. Re-run manually once you've confirmed the account has usage headroom."
    return 0
  fi

  if [[ -n "${EXPAND_LOOP_LAST_LIMIT_DONE_COUNT:-}" && "${EXPAND_LOOP_LAST_LIMIT_DONE_COUNT}" == "$DONE_BEFORE" ]]; then
    log "ERROR: usage limit hit again with zero ROADMAP progress (still $DONE_BEFORE DONE marker(s)) since the last hit."
    log_verify "No ROADMAP progress between usage-limit hits" \
      "The ROADMAP DONE-marker count was $DONE_BEFORE at both the previous usage-limit hit and this one — no task completed in between. Restarting again is unlikely to help; halting for review."
    return 0
  fi

  stash_count="$(git stash list 2>/dev/null | grep -c "$USAGE_LIMIT_STASH_TAG" || true)"
  if [[ $stash_count -ge $MAX_USAGE_LIMIT_STASHES ]]; then
    log "ERROR: $stash_count unresolved usage-limit auto-restart stash(es) already accumulated (cap: $MAX_USAGE_LIMIT_STASHES)."
    log_verify "Usage-limit stash pileup" \
      "$stash_count stashes tagged \"$USAGE_LIMIT_STASH_TAG\" are already on the stash list — prior restarts aren't converting into completed tasks. Halting instead of adding another. Run 'git stash list' to review and clear resolved ones before resuming."
    return 0
  fi

  return 1
}

# True once MORNING_STOP_EPOCH (resolved once, near script start — see above)
# has passed, for ANY lineage — not halt-worthy, not urgent, just "stop
# starting new work; the day is for humans." Compares against that fixed
# epoch rather than re-deriving "today HH:MM" here: recomputed at check time,
# "today 08:00" means a past timestamp for the entire evening/night the loop
# actually runs, which would trip this on its very first check every launch.
# Deliberately checked only at task/phase/seed BOUNDARIES (see call sites),
# never mid-flight: a task, phase gate, or review run already underway always
# finishes normally — this only gates what starts *next*, so nothing in-flight
# is ever interrupted and no tokens/effort already spent are wasted.
past_morning_stop() {
  [[ "$(date +%s)" -ge "$MORNING_STOP_EPOCH" ]]
}

# One bounded overnight re-attempt after a roadmap HALT (distinct from the
# usage-limit restart). Re-execs at the next HALT_RETRY_HOUR_LOCAL when ALL hold:
# the repo is still on the start branch (a drifted HEAD is unsafe to replay),
# the retry budget is unspent, the last retry made ROADMAP progress (else it is
# a deterministic failure a wait won't fix), and that time is within
# MAX_HALT_RETRY_WAIT_SECONDS (so a late-night halt doesn't sleep ~24h). Otherwise
# it RETURNS so the caller falls through to the tail report checkpoint.
# Never returns on a scheduled retry — exec replaces the process, holding the flock.
schedule_halt_retry() {
  local cur done_now now_epoch target_epoch wait_secs
  cur="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo UNKNOWN)"
  if [[ "$cur" != "$START_BRANCH" ]]; then
    log "Halt-retry: repo on '$cur', not start branch '$START_BRANCH' — unsafe to replay; skipping to verification."
    return 0
  fi
  if [[ "${EXPAND_LOOP_HALT_RETRY_COUNT:-0}" -ge $MAX_HALT_RETRIES ]]; then
    log "Halt-retry: budget spent (${EXPAND_LOOP_HALT_RETRY_COUNT:-0}/$MAX_HALT_RETRIES) — skipping to verification."
    return 0
  fi
  done_now="$(grep -c '✅ DONE' "$ROADMAP_FILE" 2>/dev/null || true)"
  if [[ -n "${EXPAND_LOOP_LAST_HALT_DONE_COUNT:-}" && "${EXPAND_LOOP_LAST_HALT_DONE_COUNT}" == "$done_now" ]]; then
    log "Halt-retry: no ROADMAP progress since the last halt (still $done_now DONE) — deterministic failure; skipping to verification."
    return 0
  fi
  now_epoch="$(date +%s)"
  target_epoch="$(TZ="$RESTART_TZ" date -d "today $HALT_RETRY_HOUR_LOCAL" +%s)"
  [[ $target_epoch -gt $now_epoch ]] || target_epoch="$(TZ="$RESTART_TZ" date -d "tomorrow $HALT_RETRY_HOUR_LOCAL" +%s)"
  wait_secs=$(( target_epoch - now_epoch ))
  if [[ $wait_secs -gt $MAX_HALT_RETRY_WAIT_SECONDS ]]; then
    log "Halt-retry: next $HALT_RETRY_HOUR_LOCAL $RESTART_TZ is ${wait_secs}s away (> ${MAX_HALT_RETRY_WAIT_SECONDS}s) — skipping to verification."
    return 0
  fi
  # Stash any partial work the halted task left (reversible — no DONE marker, so
  # committing it would break the one-commit-per-task convention); otherwise the
  # restarted pre-flight clean-tree gate re-halts immediately. Own tag so this
  # never inflates the usage-limit stash-pileup guard.
  if [[ -n "$(git status --porcelain)" ]]; then
    local smsg="$HALT_RETRY_STASH_TAG ($(TIMESTAMP))"
    if git stash push -u -m "$smsg" >>"$SESSION_LOG" 2>&1; then
      log_verify "Uncommitted work stashed before halt-retry" \
        "A halted task left uncommitted changes, stashed (not committed — untested, no DONE marker) as \"$smsg\". Run 'git stash list' to inspect; compare 'git stash show -p' before dropping, or 'git stash pop' if the retry didn't redo it."
    else
      log "ERROR: git stash failed before halt-retry — tree still dirty; the restarted pre-flight gate will HALT."
    fi
  fi
  log_verify "Roadmap HALT — one overnight retry scheduled" \
    "The roadmap loop halted with tasks still unfinished. Scheduling a single re-attempt at $HALT_RETRY_HOUR_LOCAL $RESTART_TZ (in ${wait_secs}s). If it still cannot drain the roadmap, the loop exits for morning review."
  log "Halt-retry: sleeping ${wait_secs}s until $HALT_RETRY_HOUR_LOCAL $RESTART_TZ, then re-attempting the roadmap..."
  sleep "$wait_secs"
  export EXPAND_LOOP_HALT_RETRY_COUNT=$(( ${EXPAND_LOOP_HALT_RETRY_COUNT:-0} + 1 ))
  export EXPAND_LOOP_LAST_HALT_DONE_COUNT="$done_now"
  log "Halt-retry: re-execing expand_loop.sh now ($(date)) — halt-retry #$EXPAND_LOOP_HALT_RETRY_COUNT this lineage."
  exec "$0" "${ORIGINAL_ARGS[@]}"
}

# Waits for the usage window to reset (USAGE_LIMIT_RESET_WAIT_SECONDS from the hit —
# a rolling ~5h window, NOT "next midnight"), then re-execs this script with its
# original argv, carrying lineage state (restart count, last-hit done-count and epoch)
# forward as exported env vars so usage_limit_should_halt() sees it after the restart.
# A brand-new top-level launch (cron/manual, no inherited env) starts fresh, so the
# guards reset per lineage. Never returns when it re-execs — exec replaces the process.
# RETURNS 1 (no sleep, no re-exec) when the reset lands at/after the morning stop or
# beyond MAX_USAGE_LIMIT_WAIT_SECONDS: sleeping ~5h only to stop for the day is
# pointless, so the caller ends the lineage cleanly and the next launch resumes.
restart_after_usage_reset() {
  local matched now_epoch resume_epoch wait_secs
  matched="$(tail -n "$USAGE_LIMIT_TAIL_LINES" "$TASK_OUTPUT_FILE" 2>/dev/null | grep -iE "$USAGE_LIMIT_MARKERS_REGEX" | head -1)"
  now_epoch="$(date +%s)"
  wait_secs=$USAGE_LIMIT_RESET_WAIT_SECONDS
  resume_epoch=$(( now_epoch + wait_secs ))
  log "Claude usage limit detected on iteration $ITERATION: $matched"
  if [[ $wait_secs -gt $MAX_USAGE_LIMIT_WAIT_SECONDS || $resume_epoch -ge $MORNING_STOP_EPOCH ]]; then
    log "Usage-limit reset (~$(( wait_secs / 3600 ))h) lands past the ${MORNING_STOP_HOUR_LOCAL} $RESTART_TZ morning stop — not sleeping; stopping this lineage for tonight."
    log_verify "Usage limit hit — reset lands past the morning stop" \
      "iteration $ITERATION reported a usage/rate limit: \"$matched\". Its ~$(( wait_secs / 3600 ))h reset lands at/after the ${MORNING_STOP_HOUR_LOCAL} $RESTART_TZ morning stop, so the loop stops for tonight instead of sleeping to no purpose. The next scheduled launch resumes from the ROADMAP DONE markers — completed tasks are committed; any in-flight work stays in the tree."
    return 1
  fi
  log_verify "Claude usage limit hit — waiting for the window to reset" \
    "iteration $ITERATION's claude session reported a usage/rate limit: \"$matched\". The loop is sleeping ${wait_secs}s until the ~$(( wait_secs / 3600 ))h rolling window resets ($(TZ="$RESTART_TZ" date -d "@$resume_epoch")), then restarts itself automatically (exec \"\$0\" with the original flags). No action needed unless it fails to resume."
  stash_dirty_tree_before_restart
  log "Sleeping ${wait_secs}s until the usage window resets, then restarting expand_loop.sh..."
  rm -f "$TASK_OUTPUT_FILE"
  sleep "$wait_secs"
  export EXPAND_LOOP_RESTART_COUNT=$(( ${EXPAND_LOOP_RESTART_COUNT:-0} + 1 ))
  export EXPAND_LOOP_LAST_LIMIT_DONE_COUNT="$DONE_BEFORE"
  export EXPAND_LOOP_LAST_LIMIT_EPOCH="$now_epoch"
  log "Restarting expand_loop.sh now ($(date)) — restart #$EXPAND_LOOP_RESTART_COUNT this lineage."
  exec "$0" "${ORIGINAL_ARGS[@]}"
}

run_task() {
  # Invokes claude for one task; sets global CLAUDE_EXIT.
  set +e
  timeout "$CLAUDE_TIMEOUT" claude \
    -p "/expand-linear-next $SKILL_ARG" \
    --output-format text \
    ${PERMISSION_MODE} \
    ${MODEL:+--model "$MODEL"} \
    2>&1 | tee "$TASK_OUTPUT_FILE" >> "$SESSION_LOG"
  CLAUDE_EXIT=${PIPESTATUS[0]}
  set -e
}

_autofix_revert() {
  # Restore the tree to the pre-fix commit: reset tracked files, drop new untracked
  # ones (git clean respects .gitignore, so caches/artifacts are untouched).
  local pre_sha="$1"
  git reset --hard "$pre_sha" >>"$SESSION_LOG" 2>&1 || true
  git clean -fd >>"$SESSION_LOG" 2>&1 || true
}

try_autofix() {
  # Single bounded attempt to auto-repair an auto-fixable red phase gate.
  # Returns 0 iff a repair landed and the FULL gate is green again (caller
  # continues); returns 1 in every other case (caller HALTs). Preconditions: a
  # clean tree (the phase-gate invariant — all tasks already committed).
  local phase_label="$1" red_gate="$2"
  [[ "$AUTOFIX_ENABLED" == "1" ]] || return 1
  if ! git diff --quiet || ! git diff --cached --quiet; then
    log "Autofix: working tree not clean — skipping, HALTing."
    return 1
  fi

  local pre_sha report fix_log verdict_line classify_exit checks
  pre_sha="$(git rev-parse HEAD)"
  report="/tmp/autofix_report_$$.txt"
  fix_log="/tmp/autofix_fix_$$.log"

  log "Autofix: classifying red gate ($red_gate, $phase_label)..."
  set +e
  verdict_line="$(timeout "$AUTOFIX_CLASSIFY_TIMEOUT" $PY_RUN scripts/classify_gate_failure.py \
    --report "$report" 2>>"$SESSION_LOG" | grep -E '^VERDICT:')"
  classify_exit=$?
  set -e
  if [[ $classify_exit -ne 0 || -z "$verdict_line" ]]; then
    log "Autofix: classifier failed/timed out — HALTing."
    return 1
  fi
  log "Autofix: $verdict_line"
  if ! grep -qE '^VERDICT: AUTOFIX' <<<"$verdict_line"; then
    log "Autofix: not an auto-fixable failure class — HALTing for human review."
    return 1
  fi
  checks="$(sed -n 's/.*checks=\([^ ]*\).*/\1/p' <<<"$verdict_line")"

  log "Autofix: dispatching bounded repair (timeout ${AUTOFIX_TIMEOUT}s, checks=$checks)..."
  set +e
  timeout "$AUTOFIX_TIMEOUT" claude \
    -p "/fix-make-failure $report" \
    --output-format text \
    ${PERMISSION_MODE} \
    ${MODEL:+--model "$MODEL"} \
    >"$fix_log" 2>&1
  set -e

  # ── forbidden-diff scan (stage first so new files are included) ─────────────
  git add -A >>"$SESSION_LOG" 2>&1 || true
  if git diff --cached --quiet; then
    log "Autofix: repair produced no changes — HALTing."
    _autofix_revert "$pre_sha"
    return 1
  fi
  set +e
  $PY_RUN scripts/scan_fix_diff.py --staged 2>>"$SESSION_LOG" | tee -a "$SESSION_LOG"
  local scan_exit=${PIPESTATUS[0]}
  set -e
  if [[ $scan_exit -ne 0 ]]; then
    log "Autofix: forbidden pattern in fix diff — reverting to $pre_sha, HALTing."
    log_verify "Autofix REJECTED (gate-gaming diff) — $phase_label" \
      "A bounded auto-fix for $red_gate ($checks) produced a diff that games the gate (see $SESSION_LOG). Reverted to $pre_sha. Fix the real cause manually before resuming."
    _autofix_revert "$pre_sha"
    return 1
  fi

  # ── re-run the FULL gate before trusting the repair ─────────────────────────
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 900 $GATE_CHECK_CMD >>"$SESSION_LOG" 2>&1 \
    && timeout -k "$GATE_TIMEOUT_KILL_AFTER" 120 $GATE_PRINCIPLES_CMD >>"$SESSION_LOG" 2>&1
  local regate_exit=$?
  set -e
  if [[ $regate_exit -ne 0 ]]; then
    log "Autofix: gate still red after repair — reverting to $pre_sha, HALTing."
    log_verify "Autofix FAILED to green the gate — $phase_label" \
      "A bounded auto-fix for $red_gate ($checks) did not make make check + make principles pass. Reverted to $pre_sha. Resolve manually before resuming."
    _autofix_revert "$pre_sha"
    return 1
  fi

  # ── commit the repair separately + flag it for morning review ───────────────
  git commit -q -m "fix(${phase_label}.autofix): auto-repair ${checks} gate failure"
  local fix_sha; fix_sha="$(git rev-parse --short HEAD)"
  log "Autofix: committed repair $fix_sha; gate is green."

  # Push immediately: this repair can land during pre-flight or the post-roadmap
  # gate, neither of which is followed by a phase push, so without this the
  # commit would otherwise sit local-only until (or unless) a later phase
  # completes this same run. Best-effort — a push failure here is flagged but
  # never reverts a gate-green repair or turns it into a HALT.
  set +e
  push_branch >>"$SESSION_LOG" 2>&1
  local autofix_push_exit=$?
  set -e
  if [[ $autofix_push_exit -ne 0 ]]; then
    log "WARNING: push of autofix repair $fix_sha failed (exit $autofix_push_exit) — commit is local only."
  fi

  {
    echo ""
    echo "## [$(TIMESTAMP)] AUTO-FIXED — REVIEW ME ($phase_label / $red_gate)"
    echo ""
    echo "The overnight loop auto-repaired an auto-fixable gate failure and committed it"
    echo "SEPARATELY as $fix_sha (base $pre_sha). $verdict_line"
    echo "The diff-scan passed and make check + make principles were re-run green, but this"
    echo "repair was NOT human-reviewed at write time — review commit $fix_sha before trusting it."
    if [[ $autofix_push_exit -ne 0 ]]; then
      echo ""
      echo "Push FAILED (exit $autofix_push_exit) — $fix_sha is local-only on $START_BRANCH; push it manually."
    fi
    echo ""
  } >> "$VERIFICATION_MD"
  rm -f "$report" "$fix_log"
  return 0
}

_gate_red_continue() {
  # A phase gate stayed red after the autofix attempt. Curator policy: don't halt
  # the night over it — log it for morning review and let the loop move on to the
  # next phase (the caller pushes the phase's commits regardless of gate color).
  # MAX_CONSECUTIVE_RED_GATES is the one backstop: that many in a row means the
  # base itself is likely broken, not just cosmetically red, so THAT halts for
  # real rather than compounding more phases on top of it. Resets to 0 on any
  # green gate (see run_phase_gate).
  local phase_label="$1" red_gate="$2"
  CONSECUTIVE_RED_GATES=$((CONSECUTIVE_RED_GATES + 1))
  if [[ $CONSECUTIVE_RED_GATES -ge $MAX_CONSECUTIVE_RED_GATES ]]; then
    log "ERROR: $CONSECUTIVE_RED_GATES consecutive red phase gates (latest: $red_gate @ $phase_label, cap $MAX_CONSECUTIVE_RED_GATES) — halting."
    log_verify "Consecutive red gates ($CONSECUTIVE_RED_GATES/$MAX_CONSECUTIVE_RED_GATES) — halting" \
      "$CONSECUTIVE_RED_GATES phase gates in a row stayed red after autofix (latest: $red_gate at $phase_label). That many in a row suggests the base itself is broken rather than just cosmetically red (file length, magic numbers, a flaky test) — halting instead of compounding further phases on top of it. Commits through $phase_label are on local branch $START_BRANCH and were pushed; review and fix before resuming."
    LAST_STATUS="HALT"
    return 1
  fi
  log "Phase gate red for $phase_label ($red_gate) — continuing to the next phase anyway (curator policy: red gates don't block roadmap progress; ${CONSECUTIVE_RED_GATES}/${MAX_CONSECUTIVE_RED_GATES} consecutive)."
  return 0
}

run_phase_gate() {
  # Soft gate: make check + make principles, run directly from bash. No Claude
  # session needed — these are deterministic commands, not LLM tasks. A red
  # result no longer halts the loop on its own — see _gate_red_continue above —
  # it only does when MAX_CONSECUTIVE_RED_GATES is hit. Sets LAST_STATUS=HALT
  # and returns 1 only in that circuit-breaker case; returns 0 otherwise
  # (including "red but tolerated"), and the caller pushes either way.
  local phase_label="$1"
  log "Phase gate ($phase_label): running make check..."
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 900 $GATE_CHECK_CMD 2>&1 | tee -a "$SESSION_LOG"
  local check_exit=${PIPESTATUS[0]}
  set -e
  if [[ $check_exit -ne 0 ]]; then
    log "ERROR: make check FAILED for $phase_label (exit $check_exit)"
    if try_autofix "$phase_label" "make-check"; then
      log "Phase gate PASSED for $phase_label (auto-fix repaired make check)."
      CONSECUTIVE_RED_GATES=0
      return 0
    fi
    log_verify "Phase gate red — make check ($phase_label)" \
      "make check failed after all tasks in $phase_label were committed. Commits are on local branch $START_BRANCH and get pushed regardless; the gate is red for morning review."
    set +e
    _gate_red_continue "$phase_label" "make-check"
    local red_continue_exit=$?
    set -e
    return $red_continue_exit
  fi
  log "Phase gate ($phase_label): running make principles..."
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 120 $GATE_PRINCIPLES_CMD 2>&1 | tee -a "$SESSION_LOG"
  local principles_exit=${PIPESTATUS[0]}
  set -e
  if [[ $principles_exit -ne 0 ]]; then
    log "ERROR: make principles FAILED for $phase_label (exit $principles_exit)"
    if try_autofix "$phase_label" "make-principles"; then
      log "Phase gate PASSED for $phase_label (auto-fix repaired make principles)."
      CONSECUTIVE_RED_GATES=0
      return 0
    fi
    log_verify "Phase gate red — make principles ($phase_label)" \
      "make principles failed after all tasks in $phase_label were committed. Commits are on local branch $START_BRANCH and get pushed regardless; review and fix at your convenience."
    set +e
    _gate_red_continue "$phase_label" "make-principles"
    local red_continue_exit=$?
    set -e
    return $red_continue_exit
  fi
  log "Phase gate ($phase_label): running make roadmap-verify..."
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 60 $GATE_ROADMAP_VERIFY_CMD 2>&1 | tee -a "$SESSION_LOG"
  local roadmap_verify_exit=${PIPESTATUS[0]}
  set -e
  if [[ $roadmap_verify_exit -ne 0 ]]; then
    # Not an autofix-class check (/fix-make-failure only repairs ruff/mypy/principles):
    # roadmap drift is a structural edit to ROADMAP.md, so log it and continue under the
    # same red-gate tolerance as the others. Cursor selection degrades to the skill's
    # full-read failsafe until the roadmap is fixed, so the loop keeps making progress.
    log "ERROR: make roadmap-verify FAILED for $phase_label (exit $roadmap_verify_exit)"
    log_verify "Phase gate red — roadmap-verify ($phase_label)" \
      "roadmap_cursor --verify found ROADMAP.md drift (duplicate/malformed phases or bad task ids) after $phase_label. Cursor phase-selection may be degraded to the full-read failsafe until the roadmap structure is fixed. Commits are on local branch $START_BRANCH and were pushed regardless."
    set +e
    _gate_red_continue "$phase_label" "roadmap-verify"
    local red_continue_exit=$?
    set -e
    return $red_continue_exit
  fi
  log "Phase gate PASSED for $phase_label."
  CONSECUTIVE_RED_GATES=0
  return 0
}

# Records a phase's soft-review output into the run-scoped accumulator ONLY when it
# names real findings — "No findings." / empty / diff-skipped / timeout outputs are not
# recorded, so file_soft_review_issues() files issues only for phases that flagged
# something. Best-effort: a failure here never affects the review itself.
_soft_review_record() {
  local phase_label="$1" review_out="$2"
  [[ -s "$review_out" ]] || return 0
  grep -qiE "no findings|nothing to review|timed out or failed" "$review_out" && return 0
  { echo ""; echo "## [$phase_label] $(TIMESTAMP)"; echo ""; cat "$review_out"; } >> "$SOFT_REVIEW_ACCUM"
}

run_soft_review() {
  # Best-effort per-phase code review appended to REVIEW_REPORT (and, when it flags
  # real findings, to SOFT_REVIEW_ACCUM for end-of-night issue filing).
  # Failure never halts the loop — every exit path uses || true.
  local phase_label="$1" base_sha="$2" review_out diff_content
  { echo ""; echo "## [$phase_label] $(TIMESTAMP)"; echo ""; } >> "$REVIEW_REPORT"

  # Capture the phase diff, capped at 51 200 chars to keep the review session
  # well inside the model's context limit.
  diff_content="$(git diff "${base_sha}..HEAD" 2>/dev/null | head -c 51200)" || true
  if [[ -z "$diff_content" ]]; then
    echo "(no diff — nothing to review)" >> "$REVIEW_REPORT"
    log "Soft review ($phase_label): no diff, skipped."
    return 0
  fi

  review_out="$(mktemp)"
  timeout 300 claude \
    -p "Review this diff for a Python async pipeline codebase. List ONLY:
(1) correctness bugs, (2) CLAUDE.md structural violations (file >300 lines,
function >40 lines, nesting >3, bare raises, swallowed exceptions, magic
literals, print() calls). One bullet per finding. If none, write 'No findings.'
Do not mention Claude, Anthropic, or AI tools.

\`\`\`diff
${diff_content}
\`\`\`" \
    --output-format text \
    ${PERMISSION_MODE} \
    ${REVIEW_MODEL:+--model "$REVIEW_MODEL"} \
    > "$review_out" 2>&1 || echo "(soft review timed out or failed)" >> "$review_out"
  cat "$review_out" >> "$REVIEW_REPORT"
  _soft_review_record "$phase_label" "$review_out"
  rm -f "$review_out"
  log "Soft review complete for $phase_label (appended to $REVIEW_REPORT)."
}

# End-of-night: turn this run's soft-review findings (SOFT_REVIEW_ACCUM, populated by
# run_soft_review only for phases that flagged something) into Active ISSUES.md entries —
# each marked NEEDS RE-VERIFICATION so /plan-issues re-grounds it against current code (a
# later phase may already have fixed it) before it ever becomes a ROADMAP phase. Best-effort
# throughout: never sets LAST_STATUS, never changes the exit code. Skipped on a usage-limit
# stop — a fresh claude session would just re-hit the wall.
file_soft_review_issues() {
  [[ "$LAST_STATUS" == "USAGE_LIMIT_STOP" ]] && { log "Soft-review issue filing: skipped (usage-limit stop)."; return 0; }
  [[ -s "$SOFT_REVIEW_ACCUM" ]] || { log "Soft-review issue filing: no findings this run — nothing to file."; return 0; }
  local today findings
  today="$(TZ="$RESTART_TZ" date +%F)"
  findings="$(cat "$SOFT_REVIEW_ACCUM")"
  log "Soft-review issue filing: recording this run's flagged findings into ISSUES.md ..."
  set +e
  timeout "$REVIEW_SESSION_TIMEOUT" claude \
    -p "You maintain project_harness/ISSUES.md. Below are code-review findings from tonight's
per-phase soft reviews ($today), grouped by phase. For each DISTINCT, still-relevant finding,
append one entry to the '## Active' section of project_harness/ISSUES.md using the file's template:
- Use the next monotonic ID from the top-of-file 'Next ID' line; increment it and update that line.
- MERGE findings sharing one root cause into a single entry; DROP any that duplicate an existing
  Active issue (compare by file + symptom).
- Severity: P1 correctness/security, P2 real bug, P3 nice-to-fix.
- '**Found:** $today, during overnight soft-review (UNVERIFIED)'
- '**Status:** SOFT-REVIEW — NEEDS RE-VERIFICATION before any ROADMAP phase (a later phase may already have fixed it).'
- '**Where:**' must cite the file:line/component named in the finding.
Edit ONLY project_harness/ISSUES.md. Finish by printing exactly one line:
'SOFT_REVIEW_ISSUES: filed <N> new, merged/dropped <M>'. Do not mention Claude, Anthropic, or any AI tool.

Findings:
${findings}" \
    --output-format text \
    ${PERMISSION_MODE} \
    ${REVIEW_MODEL:+--model "$REVIEW_MODEL"} \
    >> "$SESSION_LOG" 2>&1
  set -e
  git add "$ISSUES_FILE" 2>/dev/null || true
  if git diff --cached --quiet 2>/dev/null; then
    log "Soft-review issue filing: no ISSUES.md change (all findings duplicate/dropped)."
  else
    git commit -q -m "chore(project-harness): file overnight soft-review findings as issues" || true
    log "Soft-review issue filing: committed new ISSUES.md entries."
    set +e
    push_branch >>"$SESSION_LOG" 2>&1 || log "Soft-review issue filing: push failed (non-fatal)."
    set -e
  fi
  rm -f "$SOFT_REVIEW_ACCUM"
}

# ── clean-slate gate (make check + make principles) ──────────────────────────
# Used for both pre-flight and post-roadmap checks.  Sets LAST_STATUS=HALT and
# returns 1 on failure so callers can halt or continue as appropriate.
run_clean_slate_gate() {
  local label="$1"
  log "Clean-slate ($label): running make check..."
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 900 $GATE_CHECK_CMD 2>&1 | tee -a "$SESSION_LOG"
  local check_exit=${PIPESTATUS[0]}
  set -e
  if [[ $check_exit -ne 0 ]]; then
    log "ERROR: make check FAILED ($label, exit $check_exit)"
    if try_autofix "$label" "make-check"; then
      log "Clean-slate PASSED ($label) (auto-fix repaired make check)."
      return 0
    fi
    log_verify "Clean-slate red — make check ($label)" \
      "make check failed at $label. See $SESSION_LOG for details."
    LAST_STATUS="HALT"
    return 1
  fi
  log "Clean-slate ($label): running make principles..."
  set +e
  timeout -k "$GATE_TIMEOUT_KILL_AFTER" 120 $GATE_PRINCIPLES_CMD 2>&1 | tee -a "$SESSION_LOG"
  local principles_exit=${PIPESTATUS[0]}
  set -e
  if [[ $principles_exit -ne 0 ]]; then
    log "ERROR: make principles FAILED ($label, exit $principles_exit)"
    if try_autofix "$label" "make-principles"; then
      log "Clean-slate PASSED ($label) (auto-fix repaired make principles)."
      return 0
    fi
    log_verify "Clean-slate red — principles ($label)" \
      "make principles failed at $label. See $SESSION_LOG for details."
    LAST_STATUS="HALT"
    return 1
  fi
  log "Clean-slate PASSED ($label)."
  return 0
}

# ── main loop state (declared before pre-flight so it can flip SKIP_ROADMAP_LOOP) ─
TASK_COUNT=0
PHASE_COUNT=0
CONSECUTIVE_RED_GATES=0
CONSECUTIVE_BLOCKED_PHASES=0  # see MAX_CONSECUTIVE_BLOCKED_PHASES above; resets on any task/phase progress
CONSECUTIVE_RED_COMMITS=0    # see MAX_RED_COMMITS above; consecutive task-introduced regressions; resets on any non-regression progress
BLOCKED_PHASES=""            # space-separated ROADMAP phase numbers skipped-ahead this run (blocked-prerequisite only — a committed regression no longer forfeits its phase); the exclusion list for next_roadmap_phase_after
FORCE_PHASE_OVERRIDE=""      # non-empty while skipping ahead past a skipped phase (see next_roadmap_phase_after)
LAST_STATUS="UNKNOWN"
SKIP_ROADMAP_LOOP=""   # set when a halt-retry lineage's pre-flight is still red: skip the
                       # loop but still fall through to the tail report checkpoint.

# ── pre-flight clean-slate gate ───────────────────────────────────────────────
# Original launch: a red pre-flight is a genuine "don't start" signal — fail fast
# (CLAUDE.md startup invariant). Halt-retry lineage: the halt that scheduled this
# retry was most likely a red `make check`, which pre-flight re-runs — so a still-red
# pre-flight here means "the retry can't drain the roadmap". Rather than exit and lose
# the morning signal, skip the roadmap loop and fall through to the tail checkpoint.
if [[ -z "$NO_PREFLIGHT" ]]; then
  log "=== Pre-flight clean-slate gate ==="
  if ! run_clean_slate_gate "pre-flight"; then
    if [[ "${EXPAND_LOOP_HALT_RETRY_COUNT:-0}" -ge 1 ]]; then
      log "Pre-flight still red on the halt-retry lineage — skipping the roadmap loop, going straight to verification."
      LAST_STATUS="HALT"
      SKIP_ROADMAP_LOOP=1
    else
      log "Pre-flight FAILED — aborting before roadmap expansion."
      exit 1
    fi
  fi
fi

# ── main loop ─────────────────────────────────────────────────────────────────
# Commit the loop's own append-only report artifacts if they dirty the tree.
# run_soft_review/log_verify/log append to these after every phase gate, but
# /expand-linear-next refuses to run on a dirty tree — so leaving them uncommitted
# halts the loop one task into the next phase. Scoped to the regenerable LOG_DIR
# markdown reports; never touches code or ROADMAP. Also called once more after the
# post-roadmap clean-slate tail so writes made there don't sit uncommitted until
# the next launch.
checkpoint_reports() {
  git add "$REVIEW_REPORT" "$VERIFICATION_MD" "$AUTO_LOG" 2>/dev/null || true
  if ! git diff --cached --quiet 2>/dev/null; then
    git commit -q -m "chore(project-harness): checkpoint loop run reports" || true
    log "Checkpointed harness report artifacts to keep the tree clean."
  fi
}

# Capture HEAD before the first task of each phase so the soft review diff
# spans exactly the phase's commits. Reset after each successful phase push.
PHASE_BASE_SHA="$(git rev-parse HEAD)"

# ── tolerant-gate baseline: seeded once per PHASE ──────────────────────────────
# The union of BASELINE_SEED_RUNS halt-class runs on the current HEAD, so each task is
# judged only on the failures IT introduces (scripts/gate_attribution.py diffs against
# this file, read-only). Re-seeded at every phase boundary — on a clean tree, right
# after the phase's commits are pushed — rather than carried forward across the whole
# run: a stale baseline drifts further from the tree with every task, and the old
# write-back-on-every-diff carry-forward let a task launder its own regression into it.
# Non-fatal: on timeout/error the file is left absent and the skill falls back to
# treating every red as task-introduced (conservative — worst case an over-flagged
# UNVERIFIED marker, never a silently-committed real regression). Skipped when
# tolerance is off or we bypass the loop, since nothing would consume the baseline then.
seed_gate_baseline() {
  local label="$1"
  [[ "$RED_COMMIT_TOLERANCE" == "1" && -z "$SKIP_ROADMAP_LOOP" ]] || return 0
  log "Seeding tolerant-gate baseline ($label; union of $BASELINE_SEED_RUNS halt-class runs) → $EXPAND_BASELINE_FILE ..."
  set +e
  BASELINE_SEED_OUT="$(timeout -k "$GATE_TIMEOUT_KILL_AFTER" "$BASELINE_SEED_TIMEOUT_SECS" \
    $PY_RUN scripts/classify_gate_failure.py \
      --write-baseline "$EXPAND_BASELINE_FILE" --seed-runs "$BASELINE_SEED_RUNS" 2>&1)"
  BASELINE_SEED_EXIT=$?
  set -e
  if [[ $BASELINE_SEED_EXIT -ne 0 ]]; then
    rm -f "$EXPAND_BASELINE_FILE"
    log "WARNING: baseline seed failed (exit $BASELINE_SEED_EXIT, $label) — tasks will treat every red as task-introduced (conservative fallback). Tail: $(tail -c 300 <<<"$BASELINE_SEED_OUT")"
    return 0
  fi
  BASELINE_SEED_LINE="$(grep -oE 'BASELINE_SEEDED=.*' <<<"$BASELINE_SEED_OUT" | head -1)"
  log "Baseline seeded ($label): $BASELINE_SEED_LINE"
  report_seed_absorption "$label" "$BASELINE_SEED_LINE"
}

# A per-phase re-seed deliberately absorbs whatever is red at the boundary — including
# real failures a previous phase committed as debt. Absorbing them is the lesser evil
# (otherwise every later task re-flags the same ids and every phase reads as a
# regression), but absorbing them SILENTLY would relaunder exactly what the read-only
# diff stopped, one level up. So every id entering the baseline is named in the morning
# queue. Only for a re-seed: the first seed of a run has no previous baseline to differ
# from, so its "entered" set is just the starting state and carries no signal.
report_seed_absorption() {
  local label="$1" seed_line="$2" entered_count entered_ids
  grep -q 'PREVIOUS_KNOWN=1' <<<"$seed_line" || return 0
  entered_count="$(grep -oE 'SEED_ENTERED=[0-9]+' <<<"$seed_line" | grep -oE '[0-9]+')"
  [[ -n "$entered_count" && "$entered_count" -gt 0 ]] || return 0
  entered_ids="$(sed -E 's/.*ENTERED_IDS=//' <<<"$seed_line")"
  log "Baseline absorbed $entered_count newly-red id(s) at $label: $entered_ids"
  log_verify "Baseline absorbed $entered_count failing test(s) ($label)" \
    "These ids were NOT failing at the previous phase boundary and are now part of the tolerated baseline, so later tasks will report them as pre-existing rather than as regressions: $entered_ids
They are real, unfixed failures — most likely debt committed by the phase that just finished (check its ⚠️ UNVERIFIED markers). Fix them or they stay invisible for the rest of the run."
}

# Everything a completed phase earns: gate, review, push, count against --max-phases,
# and a fresh baseline for the phase about to start. Factored out of the PHASE_COMPLETE
# arm because it is no longer reachable only from that token — any task-committed
# outcome can be the one that finishes a phase (see phase_now_complete), and each of
# those paths owes the phase the same treatment. Returns 1 when the caller must break
# out of the task loop; LAST_STATUS is already set in that case.
run_phase_boundary() {
  # ── Soft gate: make check + make principles (bash, no Claude session) ───
  # Returns 1 (LAST_STATUS=HALT already set) only via the consecutive-red-gate
  # circuit breaker; a red-but-tolerated gate returns 0 and the phase's
  # commits still get pushed below, same as a green gate.
  run_phase_gate "$COMPLETED_PHASE_LABEL" || return 1

  # ── Soft review (best-effort, never halts) ──────────────────────────────
  run_soft_review "$COMPLETED_PHASE_LABEL" "$PHASE_BASE_SHA"

  # ── Push ────────────────────────────────────────────────────────────────
  # push_branch() logs its own "skipped" line when PUSH_ENABLED=0 and returns 0, so
  # suppress this pair of push-happened messages rather than claiming a push that
  # never ran — a false green here is exactly what a morning reader would trust.
  if [[ "$PUSH_ENABLED" == "1" ]]; then
    log "Pushing $START_BRANCH after $COMPLETED_PHASE_LABEL..."
  fi
  set +e
  push_branch 2>&1 | tee -a "$SESSION_LOG"
  PUSH_EXIT=${PIPESTATUS[0]}
  set -e
  if [[ $PUSH_EXIT -ne 0 ]]; then
    log "ERROR: git push failed (exit $PUSH_EXIT) after $COMPLETED_PHASE_LABEL"
    log_verify "Push failed ($COMPLETED_PHASE_LABEL)" \
      "git push origin $START_BRANCH exited $PUSH_EXIT after $COMPLETED_PHASE_LABEL. All commits are local. Resolve credentials or divergence and push manually before resuming."
    LAST_STATUS="HALT"
    return 1
  fi
  if [[ "$PUSH_ENABLED" == "1" ]]; then
    log "Pushed $START_BRANCH successfully after $COMPLETED_PHASE_LABEL."
  fi

  # Reset phase base SHA so the next phase's soft review diff is scoped correctly.
  PHASE_BASE_SHA="$(git rev-parse HEAD)"
  PHASE_COUNT=$((PHASE_COUNT + 1))
  CONSECUTIVE_BLOCKED_PHASES=0  # real progress happened — the blocked streak, if any, is over
  CONSECUTIVE_RED_COMMITS=0     # ...and a clean/green task ends any regression streak too
  LAST_STATUS="PHASE_COMPLETE"

  # ── phase cap (--max-phases, for bounded daytime smoke tests) ────────────
  # Checked here — after the phase's gate, soft review, and push all ran — so
  # each capped phase is exercised end-to-end (the whole point of the test).
  # A clean, intended stop: MAX_PHASES_REACHED exits 0 and still runs the tail
  # verification, exactly like the CAP_REACHED task cap.
  if [[ $MAX_PHASES -gt 0 && $PHASE_COUNT -ge $MAX_PHASES ]]; then
    log "Reached max-phases cap ($MAX_PHASES completed phase(s)). Stopping."
    log_verify "Max-phases cap reached ($MAX_PHASES)" \
      "$PHASE_COUNT phase(s) fully completed (gated + reviewed + pushed) this run, hitting the --max-phases cap. Re-run without --max-phases (or with a higher value) to continue from the next unfinished phase."
    LAST_STATUS="MAX_PHASES_REACHED"
    return 1
  fi

  # If we were skip-ahead-forcing this exact phase past one or more blocked
  # phases, advance the forced target to the next candidate now rather than
  # clearing it — an unforced next iteration would auto-detect back to the
  # earliest still-blocked phase (lowest not-done phase in file order) and
  # immediately re-hit it instead of continuing past it.
  if [[ "$FORCE_PHASE_OVERRIDE" == "${COMPLETED_PHASE_LABEL#phase-}" ]]; then
    if FORCE_PHASE_OVERRIDE="$(next_roadmap_phase_after "$FORCE_PHASE_OVERRIDE" "$BLOCKED_PHASES")"; then
      log "Skip-ahead continues: forcing phase $FORCE_PHASE_OVERRIDE next (skipped so far: $BLOCKED_PHASES)."
    else
      log "Skip-ahead done: no ROADMAP phase remains after $COMPLETED_PHASE_LABEL (skipped: $BLOCKED_PHASES) — resuming normal auto-detection."
      FORCE_PHASE_OVERRIDE=""
    fi
  fi

  # Re-seed on the clean, just-pushed tree so the next phase's tasks are judged against
  # what the tree actually looks like as that phase starts.
  seed_gate_baseline "after $COMPLETED_PHASE_LABEL"
  return 0
}

# A just-completed phase gets the longer PHASE_SLEEP_SECS pause (default ~7 min)
# instead of the ordinary inter-task SLEEP_SECS, to space out phases and give usage
# headroom time to regenerate between them.
sleep_between_tasks() {
  [[ $ITERATION -lt $MAX_TASKS ]] || return 0
  if [[ "$LAST_STATUS" == "PHASE_COMPLETE" ]]; then
    log "Sleeping ${PHASE_SLEEP_SECS}s before the next phase..."
    sleep "$PHASE_SLEEP_SECS"
  else
    log "Sleeping ${SLEEP_SECS}s before next task..."
    sleep "$SLEEP_SECS"
  fi
}

# Shared tail for every "a task committed" outcome: if that task finished its phase,
# run the phase boundary. Sets COMPLETED_PHASE_LABEL for run_phase_boundary's messages.
# Returns 1 only when the caller must break out of the task loop.
finish_phase_if_complete() {
  local phase_num="$1"
  phase_now_complete "$phase_num" || return 0
  COMPLETED_PHASE_LABEL="phase-$phase_num"
  log "ROADMAP shows $COMPLETED_PHASE_LABEL fully done — running the phase boundary."
  run_phase_boundary
}

seed_gate_baseline "startup — before the first phase"

for ITERATION in $(seq 1 "$MAX_TASKS"); do
  # A halt-retry lineage whose pre-flight is still red never enters the loop —
  # LAST_STATUS is already HALT; fall through to the always-on verification.
  [[ -n "$SKIP_ROADMAP_LOOP" ]] && break

  log "--- Task iteration $ITERATION / $MAX_TASKS ---"

  # ── morning stop (every lineage) ──────────────────────────────────────────
  # Checked only here, at the top of an iteration — never mid-task — so a task
  # already running always finishes normally; this just declines to start the
  # next one. Not a HALT: nothing is wrong, so no overnight halt-retry, and
  # whatever's already committed gets pushed now rather than waiting on the
  # next phase boundary (which past this hour may not come tonight).
  if past_morning_stop; then
    log "Morning stop reached ($MORNING_STOP_HOUR_LOCAL $RESTART_TZ) — not starting task iteration $ITERATION."
    LAST_STATUS="MORNING_STOP"
    set +e
    push_branch >>"$SESSION_LOG" 2>&1 \
      || log "WARNING: morning-stop push failed (non-fatal) — see $SESSION_LOG."
    set -e
    break
  fi

  # Clear any report-artifact writes the previous phase gate left uncommitted,
  # otherwise the skill's clean-tree gate halts this iteration.
  checkpoint_reports

  # Build the skill invocation: always --auto --single-task.
  # FORCE_PHASE_OVERRIDE takes priority whenever it's set — it means we're skipping
  # ahead past one or more blocked-prerequisite phases (see the AUTO_STATUS token
  # handling below) and must keep forcing the same target every iteration; without
  # this, an unforced iteration would auto-detect back to the earlier blocked phase
  # (still the lowest not-done phase in file order) and immediately re-hit it.
  # FORCE_PHASE only applies on the first iteration so the loop starts at the
  # right phase; subsequent unforced iterations let the skill auto-detect the next task.
  if [[ -n "$FORCE_PHASE_OVERRIDE" ]]; then
    SKILL_ARG="--auto --single-task phase $FORCE_PHASE_OVERRIDE"
    # Thread the skipped-phase exclusion list through to the skill so its
    # arg-forced-but-done fallback (Step 4, `--next-after N --exclude ...`) can
    # never re-select a phase we already skipped this run — belt-and-suspenders on
    # top of the forward-from-N selection. read -a normalizes the leading space in
    # BLOCKED_PHASES (" 234 235") to a clean, single-spaced list.
    read -r -a _blocked_arr <<<"$BLOCKED_PHASES"
    if [[ ${#_blocked_arr[@]} -gt 0 ]]; then
      SKILL_ARG="$SKILL_ARG exclude ${_blocked_arr[*]}"
    fi
  elif [[ $ITERATION -eq 1 && -n "$FORCE_PHASE" ]]; then
    SKILL_ARG="--auto --single-task $FORCE_PHASE"
  else
    SKILL_ARG="--auto --single-task"
  fi

  TASK_OUTPUT_FILE="/tmp/expand_task_${ITERATION}_$$.txt"
  # grep -c already prints 0 on no-match (and exits 1); `|| true` keeps that
  # single "0" instead of appending a second line via `echo 0`.
  DONE_BEFORE="$(grep -c '✅ DONE' "$ROADMAP_FILE" 2>/dev/null || true)"

  log "Running: claude -p '/expand-linear-next $SKILL_ARG'"
  run_task

  # One retry on a transient signal-kill of the outer claude process (137/143 — see
  # SIGNAL_KILL_RETRY_EXIT_CODES above). A real CLI error surfaces under a different exit
  # code and falls through to the non-zero-exit HALT below, unretried.
  if [[ " $SIGNAL_KILL_RETRY_EXIT_CODES " == *" $CLAUDE_EXIT "* && $SIGTERM_RETRIES -gt 0 ]]; then
    log "WARNING: claude killed by signal (exit $CLAUDE_EXIT) on iteration $ITERATION — retrying once after ${SIGTERM_RETRY_BACKOFF_SECS}s"
    sleep "$SIGTERM_RETRY_BACKOFF_SECS"
    run_task
  fi

  DONE_AFTER="$(grep -c '✅ DONE' "$ROADMAP_FILE" 2>/dev/null || true)"

  # ── roadmap_cursor failsafe surfacing (log-only; the skill already recovered) ──
  # scripts/roadmap_cursor.py finds/slices/marks the target phase so the skill loads
  # only one phase body instead of the whole ROADMAP.md. If it fails, the skill falls
  # back to a full-roadmap read and prints a ROADMAP_CURSOR_FAILSAFE: line. Surface it
  # to the morning review so a persistent breakage gets fixed — but do NOT alter control
  # flow: this is graceful degradation, not a HALT, and the task still completed.
  if grep -qE 'ROADMAP_CURSOR_FAILSAFE:' "$TASK_OUTPUT_FILE" 2>/dev/null; then
    ROADMAP_CURSOR_FS_LINE="$(grep -E 'ROADMAP_CURSOR_FAILSAFE:' "$TASK_OUTPUT_FILE" | head -1)"
    log "roadmap_cursor failsafe on iteration $ITERATION: $ROADMAP_CURSOR_FS_LINE"
    log_verify "ROADMAP-CURSOR FAILSAFE (iteration $ITERATION)" "$ROADMAP_CURSOR_FS_LINE"
  fi

  # ── usage-limit auto-restart ──────────────────────────────────────────────
  # Checked ahead of the timeout/non-zero-exit HALTs below: a usage-limit reply
  # can arrive under any exit code, and it means "come back later", not "halt
  # for human review". Two independent guards against misrouting a REAL halt
  # or crash into this path:
  #   1. Gated on the ABSENCE of a completion token — including HALT, not just
  #      ALL_DONE/TASK_COMPLETE/PHASE_COMPLETE. Several roadmap tasks touch this
  #      codebase's own LLM rate-limit handling (core/llm/_claude_cli_common.py
  #      etc.), so a session that finished normally (including a deliberate,
  #      correctly-reported HALT) can still mention "rate limit" in its
  #      narration. A real usage-limit hit blocks the skill before it can emit
  #      ANY AUTO_STATUS token, so requiring the absence of every one of them
  #      — not just the success ones — rules out that false-positive path.
  #   2. Excludes CLAUDE_EXIT -eq 124 (timeout) and the SIGNAL_KILL_RETRY_EXIT_CODES
  #      (137/143, after the one retry above is already spent): a killed-mid-task
  #      transcript is cut off at an arbitrary point and can end on unrelated text
  #      that happens to match. Those cases already get their own clear,
  #      deterministic HALT below and should never be text-sniffed instead.
  # looks_like_usage_limit() itself further narrows the marker search to the
  # last USAGE_LIMIT_TAIL_LINES of output, since a genuine refusal is the CLI's
  # own last message, not something buried mid-transcript.
  # Re-execs on a fresh window (no return); returns 1 only when the reset lands past
  # the morning stop, in which case we stop this lineage for tonight (USAGE_LIMIT_STOP,
  # not HALT — no halt-retry, and the review cycle is skipped so we never hammer a
  # still-rate-limited account).
  if [[ $CLAUDE_EXIT -ne 124 && " $SIGNAL_KILL_RETRY_EXIT_CODES " != *" $CLAUDE_EXIT "* ]] \
     && ! grep -qE '^[`[:space:]]*AUTO_STATUS: *(ALL_DONE|HALT|TASK_COMPLETE|PHASE_COMPLETE)' "$TASK_OUTPUT_FILE" \
     && looks_like_usage_limit "$TASK_OUTPUT_FILE"; then
    if usage_limit_should_halt; then
      LAST_STATUS="HALT"
      break
    fi
    restart_after_usage_reset || { LAST_STATUS="USAGE_LIMIT_STOP"; break; }
  fi

  # ── timeout ────────────────────────────────────────────────────────────────
  if [[ $CLAUDE_EXIT -eq 124 ]]; then
    log "ERROR: claude timed out after ${CLAUDE_TIMEOUT}s on iteration $ITERATION"
    log_verify "claude timed out (iteration $ITERATION)" \
      "The task runner was killed after ${CLAUDE_TIMEOUT}s. The task may be partially applied. Check git log on $START_BRANCH and project_harness/ROADMAP.md before resuming."
    LAST_STATUS="HALT"
    break
  fi

  # ── non-zero exit ──────────────────────────────────────────────────────────
  if [[ $CLAUDE_EXIT -ne 0 ]]; then
    log "ERROR: claude exited with code $CLAUDE_EXIT on iteration $ITERATION"
    log_verify "claude non-zero exit (iteration $ITERATION, code $CLAUDE_EXIT)" \
      "The claude process exited unexpectedly. Last 20 lines of output:
$(tail -n 20 "$TASK_OUTPUT_FILE" 2>/dev/null)"
    LAST_STATUS="HALT"
    break
  fi

  # ── branch-drift guard ─────────────────────────────────────────────────────
  if ! assert_on_start_branch "$ITERATION"; then
    LAST_STATUS="HALT"
    break
  fi

  # ── parse AUTO_STATUS tokens (line-start after optional markdown backticks/
  #    indentation, so a fenced `AUTO_STATUS: …` token still matches; a mid-prose
  #    mention like "the `AUTO_STATUS: …`" is still ignored) ────────────────────
  if grep -qE '^[`[:space:]]*AUTO_STATUS: *ALL_DONE' "$TASK_OUTPUT_FILE"; then
    log "All phases complete — loop finished successfully."
    LAST_STATUS="ALL_DONE"
    rm -f "$TASK_OUTPUT_FILE"
    break
  fi

  # Checked BEFORE the generic HALT branch below (whose regex would otherwise match
  # this too): a blocked-prerequisite HALT skips ahead instead of stopping the run —
  # see MAX_CONSECUTIVE_BLOCKED_PHASES above for the policy and its one backstop.
  if grep -qE '^[`[:space:]]*AUTO_STATUS: *HALT blocked-prerequisite' "$TASK_OUTPUT_FILE"; then
    BLOCKED_LINE="$(grep -E '^[`[:space:]]*AUTO_STATUS: *HALT blocked-prerequisite' "$TASK_OUTPUT_FILE" | head -1)"
    rm -f "$TASK_OUTPUT_FILE"
    BLOCKED_PHASE_NUM="$(grep -oE 'phase-[0-9]+' <<<"$BLOCKED_LINE" | head -1 | grep -oE '[0-9]+')"
    if [[ -z "$BLOCKED_PHASE_NUM" ]]; then
      log "WARNING: blocked-prerequisite token had no parseable phase number ($BLOCKED_LINE) — halting rather than guessing what to skip."
      log_verify "Unparseable blocked-prerequisite token (iteration $ITERATION)" "$BLOCKED_LINE"
      LAST_STATUS="HALT"
      break
    fi
    log "Phase $BLOCKED_PHASE_NUM blocked on an unmet prerequisite — $BLOCKED_LINE"
    log_verify "Phase $BLOCKED_PHASE_NUM skipped (blocked-prerequisite)" \
      "$BLOCKED_LINE — skipping ahead to the next phase for the rest of tonight's run instead of halting; its tasks stay un-DONE, so it will be retried automatically (tonight's halt-retry, or tomorrow) since the blocker is usually transient."
    BLOCKED_PHASES="$BLOCKED_PHASES $BLOCKED_PHASE_NUM"
    CONSECUTIVE_BLOCKED_PHASES=$((CONSECUTIVE_BLOCKED_PHASES + 1))
    if [[ $CONSECUTIVE_BLOCKED_PHASES -ge $MAX_CONSECUTIVE_BLOCKED_PHASES ]]; then
      log "ERROR: $CONSECUTIVE_BLOCKED_PHASES consecutive blocked-prerequisite phases (cap $MAX_CONSECUTIVE_BLOCKED_PHASES) — halting."
      log_verify "Consecutive blocked phases ($CONSECUTIVE_BLOCKED_PHASES/$MAX_CONSECUTIVE_BLOCKED_PHASES) — halting" \
        "$CONSECUTIVE_BLOCKED_PHASES phases in a row halted blocked-prerequisite with no task progress between them (phases:$BLOCKED_PHASES). That many in a row suggests a systemic blocker shared by the remaining roadmap, not independent stalls — halting for review instead of skipping through the rest of the roadmap for nothing."
      LAST_STATUS="HALT"
      break
    fi
    if FORCE_PHASE_OVERRIDE="$(next_roadmap_phase_after "$BLOCKED_PHASE_NUM" "$BLOCKED_PHASES")"; then
      log "Skipping phase $BLOCKED_PHASE_NUM — forcing phase $FORCE_PHASE_OVERRIDE for the rest of this run."
    else
      log "No ROADMAP phase remains after phase $BLOCKED_PHASE_NUM — nothing left to attempt tonight (blocked: $BLOCKED_PHASES)."
      LAST_STATUS="SKIPPED_EXHAUSTED"
      break
    fi
    # Same courtesy pacing pause as a normal completed task (respects --no-sleep);
    # nothing was implemented here, but back-to-back `claude -p` calls with zero
    # gap is still worth avoiding.
    if [[ $ITERATION -lt $MAX_TASKS ]]; then
      log "Sleeping ${SLEEP_SECS}s before the next (skipped-ahead) task..."
      sleep "$SLEEP_SECS"
    fi
    continue
  fi

  # ── tolerant gate: task committed but INTRODUCED >=1 new failure (regression) ─
  # Checked before the generic HALT/TASK_COMPLETE branches. Committed + flagged, and
  # the run CONTINUES to this phase's next task. It used to skip the rest of the phase
  # on the theory that sibling tasks share files and would cascade the breakage; in
  # practice (2026-07-31) the first regression of the night was two flaky tests the task
  # had never touched, and forfeiting the phase left an irreversible two-ring migration
  # half-applied with its cutover task unrun. Confirmation re-runs (gate_confirm.py) now
  # make a reported regression far likelier to be real, and MAX_RED_COMMITS in a row
  # remains the backstop for a tree that genuinely is systemically broken.
  if grep -qE '^[`[:space:]]*AUTO_STATUS: *TASK_COMMITTED_REGRESSION' "$TASK_OUTPUT_FILE"; then
    REGRESSION_LINE="$(grep -E '^[`[:space:]]*AUTO_STATUS: *TASK_COMMITTED_REGRESSION' "$TASK_OUTPUT_FILE" | head -1)"
    rm -f "$TASK_OUTPUT_FILE"
    REG_PHASE_NUM="$(grep -oE 'phase-[0-9]+' <<<"$REGRESSION_LINE" | head -1 | grep -oE '[0-9]+')"
    TASK_COUNT=$((TASK_COUNT + 1))               # the task did commit (with debt)
    CONSECUTIVE_BLOCKED_PHASES=0                  # a task committed — the blocked streak, if any, is over
    CONSECUTIVE_RED_COMMITS=$((CONSECUTIVE_RED_COMMITS + 1))
    LAST_STATUS="TASK_COMPLETE"
    log "Task committed with an INTRODUCED regression (debt): $REGRESSION_LINE"
    log_verify "Phase ${REG_PHASE_NUM:-?} task committed with a regression (⚠️ UNVERIFIED)" \
      "$REGRESSION_LINE — the task's own change introduced >=1 new test/schema failure that reproduced on re-run. Committed + marked ⚠️ UNVERIFIED and flagged; continuing with the rest of phase ${REG_PHASE_NUM:-?} so the phase is not left half-applied. Consecutive regressions: ${CONSECUTIVE_RED_COMMITS}/${MAX_RED_COMMITS}."
    if [[ $CONSECUTIVE_RED_COMMITS -ge $MAX_RED_COMMITS ]]; then
      log "ERROR: $CONSECUTIVE_RED_COMMITS consecutive task-introduced regressions (cap $MAX_RED_COMMITS) — halting."
      log_verify "Consecutive red commits (${CONSECUTIVE_RED_COMMITS}/${MAX_RED_COMMITS}) — halting" \
        "$CONSECUTIVE_RED_COMMITS tasks in a row each introduced NEW failures with no clean task between them — the tree is likely systemically broken, not accumulating isolated debt. Halting for review; committed work is on local branch $START_BRANCH (unpushed until a phase completes)."
      LAST_STATUS="HALT"
      break
    fi
    finish_phase_if_complete "$REG_PHASE_NUM" || break
    sleep_between_tasks
    continue
  fi

  # ── tolerant gate: task committed over a PRE-EXISTING red (no new failures) ───
  # Checked before the plain TASK_COMPLETE branch (whose regex is a prefix of this
  # token and would otherwise swallow it). gate_baseline confirmed the task added
  # nothing new, so this is zero-real-debt progress: treat like TASK_COMPLETE.
  if grep -qE '^[`[:space:]]*AUTO_STATUS: *TASK_COMPLETE_BASELINE_RED' "$TASK_OUTPUT_FILE"; then
    BASELINE_RED_LINE="$(grep -E '^[`[:space:]]*AUTO_STATUS: *TASK_COMPLETE_BASELINE_RED' "$TASK_OUTPUT_FILE" | head -1)"
    rm -f "$TASK_OUTPUT_FILE"
    BASELINE_RED_PHASE_NUM="$(grep -oE 'phase-[0-9]+' <<<"$BASELINE_RED_LINE" | head -1 | grep -oE '[0-9]+')"
    log "Task committed over a PRE-EXISTING red gate (baseline debt, no new failures): $BASELINE_RED_LINE"
    log_verify "Task committed over a pre-existing red gate (⚠️ UNVERIFIED)" \
      "$BASELINE_RED_LINE — the per-task make check was red, but gate_baseline confirmed the failures pre-date this task (it introduced none). Committed + marked ⚠️ UNVERIFIED and continuing to the next task. The pre-existing failures still need a separate fix."
    TASK_COUNT=$((TASK_COUNT + 1))
    CONSECUTIVE_RED_COMMITS=0     # no new failure introduced — the regression streak is over
    CONSECUTIVE_BLOCKED_PHASES=0  # real progress happened
    LAST_STATUS="TASK_COMPLETE"
    finish_phase_if_complete "$BASELINE_RED_PHASE_NUM" || break
    sleep_between_tasks
    continue
  fi

  if grep -qE '^[`[:space:]]*AUTO_STATUS: *HALT' "$TASK_OUTPUT_FILE"; then
    HALT_REASON="$(grep -E '^[`[:space:]]*AUTO_STATUS: *HALT' "$TASK_OUTPUT_FILE" | head -1)"
    log "Task halted for human review: $HALT_REASON"
    log "Check $VERIFICATION_MD for details."
    LAST_STATUS="HALT"
    break
  fi

  if grep -qE '^[`[:space:]]*AUTO_STATUS: *TASK_COMPLETE' "$TASK_OUTPUT_FILE"; then
    COMPLETED="$(grep -E '^[`[:space:]]*AUTO_STATUS: *TASK_COMPLETE' "$TASK_OUTPUT_FILE" | head -1)"
    COMPLETED_PHASE_NUM="$(grep -oE 'phase-[0-9]+' <<<"$COMPLETED" | head -1 | grep -oE '[0-9]+')"
    log "Task complete: $COMPLETED"
    TASK_COUNT=$((TASK_COUNT + 1))
    CONSECUTIVE_BLOCKED_PHASES=0  # real progress happened — the blocked streak, if any, is over
    CONSECUTIVE_RED_COMMITS=0     # ...and a clean/green task ends any regression streak too
    LAST_STATUS="TASK_COMPLETE"
    rm -f "$TASK_OUTPUT_FILE"
    # A green last task normally reports PHASE_COMPLETE below, but the roadmap is the
    # authority either way — this catches a phase finished under a token that did not
    # say so, at the cost of one cheap cursor call per task.
    finish_phase_if_complete "$COMPLETED_PHASE_NUM" || break

  elif grep -qE '^[`[:space:]]*AUTO_STATUS: *PHASE_COMPLETE' "$TASK_OUTPUT_FILE"; then
    COMPLETED="$(grep -E '^[`[:space:]]*AUTO_STATUS: *PHASE_COMPLETE' "$TASK_OUTPUT_FILE" | head -1)"
    COMPLETED_PHASE_LABEL="$(echo "$COMPLETED" | grep -oE 'phase-[0-9]+')" \
      || COMPLETED_PHASE_LABEL="phase-?"
    log "Last task in phase complete: $COMPLETED"
    TASK_COUNT=$((TASK_COUNT + 1))
    rm -f "$TASK_OUTPUT_FILE"
    run_phase_boundary || break

  elif [[ "$DONE_AFTER" -gt "$DONE_BEFORE" ]]; then
    # Fallback: DONE markers increased but the skill emitted no recognised token.
    # Treat as task complete and continue; the loop will self-correct on the next
    # iteration when the skill finds the next unfinished task.
    log "WARNING: No AUTO_STATUS token but ROADMAP gained $((DONE_AFTER - DONE_BEFORE)) DONE marker(s). Treating as TASK_COMPLETE."
    TASK_COUNT=$((TASK_COUNT + 1))
    CONSECUTIVE_BLOCKED_PHASES=0  # real progress happened — the blocked streak, if any, is over
    CONSECUTIVE_RED_COMMITS=0     # ...and a clean/green task ends any regression streak too
    LAST_STATUS="TASK_COMPLETE"
    rm -f "$TASK_OUTPUT_FILE"

  else
    # No recognised status and no ROADMAP change — skill stopped unexpectedly.
    log "WARNING: No AUTO_STATUS token and ROADMAP unchanged on iteration $ITERATION"
    log_verify "Missing AUTO_STATUS token (iteration $ITERATION)" \
      "The skill did not emit a recognisable AUTO_STATUS token and the ROADMAP was not updated. The skill may have stopped mid-way or the output format changed. Last 20 lines of output:
$(tail -n 20 "$TASK_OUTPUT_FILE" 2>/dev/null)"
    LAST_STATUS="HALT"
    break
  fi

  # ── safety sleep before next task ─────────────────────────────────────────
  sleep_between_tasks
done

# ── cap reached without finishing ─────────────────────────────────────────────
if [[ "$LAST_STATUS" == "TASK_COMPLETE" || "$LAST_STATUS" == "PHASE_COMPLETE" ]] \
   && [[ $TASK_COUNT -ge $MAX_TASKS ]]; then
  log "Reached max-tasks cap ($MAX_TASKS). Stopping."
  log_verify "Max-tasks cap reached ($MAX_TASKS)" \
    "$TASK_COUNT tasks completed this run. Re-run the script to continue from the next unfinished task."
  LAST_STATUS="CAP_REACHED"
fi

# ── halt → one overnight retry before we give up ──────────────────────────────
# If the roadmap loop halted with tasks unfinished, give it a single re-attempt at
# HALT_RETRY_HOUR_LOCAL (schedule_halt_retry re-execs and never returns when it is
# eligible). When it is NOT eligible — budget spent, no progress last time, drifted
# branch, or the retry hour is too far off — it returns here and we fall straight
# through to the always-on verification below, still exiting non-zero for review.
if [[ "$LAST_STATUS" == "HALT" ]]; then
  schedule_halt_retry
fi

# ── post-roadmap clean-slate gate ─────────────────────────────────────────────
# Only when the roadmap loop finished without halting (ALL_DONE / CAP_REACHED /
# MAX_PHASES_REACHED / PHASE_COMPLETE / TASK_COMPLETE).
if [[ "$LAST_STATUS" != "HALT" ]]; then

  if [[ -z "$NO_PREFLIGHT" ]]; then
    log "=== Post-roadmap clean-slate gate ==="
    run_clean_slate_gate "post-roadmap" || true  # LAST_STATUS set to HALT inside on failure
  fi
fi

# Checkpoint AND push now, before the (kill-prone) issue-filing session below: an
# unexpected kill there should not strand what the clean-slate tail already produced
# above, uncommitted or unpushed.
checkpoint_reports
set +e
push_branch 2>&1 | tee -a "$SESSION_LOG"
PRE_REVIEW_PUSH_EXIT=${PIPESTATUS[0]}
set -e
[[ $PRE_REVIEW_PUSH_EXIT -eq 0 ]] || log "WARNING: pre-issue-filing report push failed (exit $PRE_REVIEW_PUSH_EXIT, non-fatal)."

# ── file this run's soft-review findings as issues ────────────────────────────
# Turn the per-phase soft reviews into NEEDS-VERIFICATION ISSUES.md entries before the
# loop exits. Best-effort; self-skips on a usage-limit stop or an empty run.
file_soft_review_issues || log "Soft-review issue filing returned non-zero (non-fatal)."

# ── final summary ──────────────────────────────────────────────────────────────
log "=== expand_loop.sh finished ==="
log "Tasks completed this run: $TASK_COUNT"
log "Phases pushed this run:   $PHASE_COUNT"
log "Final status:             $LAST_STATUS"
log "Full session log:         $SESSION_LOG"
log "Human verification file:  $VERIFICATION_MD"
log "Review report:            $REVIEW_REPORT"
log "Auto run log:             $AUTO_LOG"

{
  echo ""
  echo "## [$(TIMESTAMP)] expand_loop.sh session ended"
  echo "- Tasks completed: $TASK_COUNT"
  echo "- Phases pushed: $PHASE_COUNT"
  echo "- Final status: $LAST_STATUS"
  echo "- Session log: $SESSION_LOG"
} >> "$AUTO_LOG"

# Final checkpoint: the post-roadmap clean-slate tail can write to
# VERIFICATION_MD/AUTO_LOG after the last mid-loop
# checkpoint_reports() call, and this summary block just added more — commit
# and push them now so nothing is left for the next launch's dirty-tree gate
# to sweep into an unrelated commit. Best-effort: never changes the exit code.
checkpoint_reports
set +e
push_branch 2>&1 | tee -a "$SESSION_LOG"
FINAL_PUSH_EXIT=${PIPESTATUS[0]}
set -e
[[ $FINAL_PUSH_EXIT -eq 0 ]] || log "WARNING: final report push failed (exit $FINAL_PUSH_EXIT, non-fatal)."

notify "$LAST_STATUS" \
  "expand_loop.sh ended: status=$LAST_STATUS, tasks=$TASK_COUNT, phases=$PHASE_COUNT (log: $SESSION_LOG)"

# Exit non-zero on unexpected stops so cron/systemd can fire an alert.
# SMOKE_FAIL (exit 2) is distinct so monitoring can separate pipeline regressions
# from roadmap failures (exit 1). MORNING_STOP is a clean, expected stop — not a
# failure — so it exits 0 alongside ALL_DONE/CAP_REACHED/MAX_PHASES_REACHED (the
# --max-phases daytime-test cap is likewise a clean, intended stop).
case "$LAST_STATUS" in
  ALL_DONE|CAP_REACHED|MAX_PHASES_REACHED|MORNING_STOP) exit 0 ;;
  SMOKE_FAIL)                        exit 2 ;;
  *)                                 exit 1 ;;
esac

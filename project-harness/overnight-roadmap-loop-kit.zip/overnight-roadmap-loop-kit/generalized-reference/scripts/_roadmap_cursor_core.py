"""Pure parsing/rendering logic for the ROADMAP phase cursor (no I/O, no argparse).

This is the reader+renderer library behind ``scripts/roadmap_cursor.py``. It owns the
one true understanding of ``project_harness/ROADMAP.md``'s phase/task/DONE-marker shape
so that finding the next unfinished phase, slicing a phase's body, and appending a DONE
marker are all governed by a single parser — a marker written here always parses back
here. All functions are pure over a ``list[str]`` of physical lines (produced by
``str.splitlines(keepends=True)``), so writing is a caller concern and every code path
is trivially unit-testable.

Mirrors the pure-library role of ``scripts/gate_baseline.py`` (imported by a thin CLI).
"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict

# --- ROADMAP grammar (all magic strings named; see project_harness/ROADMAP.md) ---
DONE_TOKEN = "✅ DONE"
DEFERRED_TOKEN = "⏸️"
PHASE_HEADING_RE = re.compile(r"^## Phase (\d+):")
PHASE_HEADING_PREFIX = "## Phase "
TASK_BULLET_RE = re.compile(r"^- \*\*(\d+)\.(\d+) —")
# A task block runs until the next sibling bullet, sub-heading, rule, phase heading,
# or the trailing "Full make check ..." line.
BLOCK_END_PREFIXES = ("- **", "### ", "---", "## ", "Full ")
MARKER_TEMPLATE = " — ✅ DONE (phase-{phase}.task-{task_id}, {date})"
UNVERIFIED_TEMPLATE = " — ✅ DONE ⚠️ UNVERIFIED (phase-{phase}.task-{task_id}, {reason}, {date})"


class RoadmapCursorError(Exception):
    """Raised when the roadmap cannot be parsed or a requested phase/task is absent."""

    def __init__(self, message: str, *, kind: str) -> None:
        super().__init__(message)
        self.kind = kind


class TaskEntry(BaseModel):
    """One numbered ``- **N.M —`` execution-plan task and its DONE state + line span."""

    model_config = ConfigDict(frozen=True)

    id: str
    phase: int
    m: int
    done: bool
    start: int
    end: int


class PhaseEntry(BaseModel):
    """One ``## Phase N:`` section: its number, deferral flag, line span, and tasks."""

    model_config = ConfigDict(frozen=True)

    number: int
    deferred: bool
    start: int
    end: int
    tasks: tuple[TaskEntry, ...]

    @property
    def is_done(self) -> bool:
        """A phase is done iff it has at least one task and all tasks are done."""
        return bool(self.tasks) and all(task.done for task in self.tasks)

    @property
    def pending(self) -> tuple[str, ...]:
        """Ids of this phase's not-done tasks, in file order."""
        return tuple(task.id for task in self.tasks if not task.done)


def _phase_bounds(lines: list[str]) -> list[tuple[int, int, int]]:
    """Return ``(number, start, end)`` for every ``## Phase N:`` heading, in file order."""
    heads: list[tuple[int, int]] = []
    for index, line in enumerate(lines):
        match = PHASE_HEADING_RE.match(line)
        if match:
            heads.append((index, int(match.group(1))))
    bounds: list[tuple[int, int, int]] = []
    for position, (start, number) in enumerate(heads):
        end = heads[position + 1][0] if position + 1 < len(heads) else len(lines)
        bounds.append((number, start, end))
    return bounds


def _block_end(lines: list[str], bullet: int, limit: int) -> int:
    """First line at/after ``bullet+1`` that opens a new block, capped at ``limit``."""
    for index in range(bullet + 1, limit):
        if lines[index].startswith(BLOCK_END_PREFIXES):
            return index
    return limit


def _parse_tasks(lines: list[str], start: int, end: int) -> tuple[TaskEntry, ...]:
    """Parse every ``- **N.M —`` task block inside a phase's ``[start, end)`` span."""
    tasks: list[TaskEntry] = []
    for index in range(start, end):
        match = TASK_BULLET_RE.match(lines[index])
        if not match:
            continue
        block_end = _block_end(lines, index, end)
        phase_no, task_m = int(match.group(1)), int(match.group(2))
        done = any(DONE_TOKEN in lines[inner] for inner in range(index, block_end))
        tasks.append(
            TaskEntry(
                id=f"{phase_no}.{task_m}",
                phase=phase_no,
                m=task_m,
                done=done,
                start=index,
                end=block_end,
            )
        )
    return tuple(tasks)


def parse_roadmap(lines: list[str]) -> tuple[PhaseEntry, ...]:
    """Parse all phases and their tasks. Never raises on shape; ``verify`` audits shape."""
    phases: list[PhaseEntry] = []
    for number, start, end in _phase_bounds(lines):
        deferred = DEFERRED_TOKEN in lines[start]
        phases.append(
            PhaseEntry(
                number=number,
                deferred=deferred,
                start=start,
                end=end,
                tasks=_parse_tasks(lines, start, end),
            )
        )
    return tuple(phases)


def compute_next(
    phases: tuple[PhaseEntry, ...],
    *,
    after: int | None = None,
    exclude: frozenset[int] = frozenset(),
) -> PhaseEntry | None:
    """First actionable unfinished phase in file order, else ``None``.

    Honours the overnight auto-loop's curator policy so a parked phase can never
    stall an unattended run:
    - **DEFERRED phases are surfaced last** — a ``⏸️`` phase is curator-parked
      ("don't auto-attempt"), so it is only returned when *no* non-deferred
      unfinished phase remains in the candidate window. Otherwise the auto loop
      would hand a deferred phase to a session that can only HALT on it.
    - ``after`` restricts candidates to phases numbered ``>= after`` — the loop's
      skip-ahead resumes *forward* from a forced phase (``--next-after N``) instead
      of re-selecting the globally-earliest unfinished phase it is trying to skip.
    - ``exclude`` drops already-skipped phase numbers so a blocked phase can't be
      re-selected on the arg-forced-but-done fallback.
    """
    candidates = [
        phase
        for phase in phases
        if not phase.is_done
        and phase.number not in exclude
        and (after is None or phase.number >= after)
    ]
    non_deferred = [phase for phase in candidates if not phase.deferred]
    ranked = non_deferred or candidates
    return ranked[0] if ranked else None


def slice_range(phases: tuple[PhaseEntry, ...], number: int) -> tuple[int, int]:
    """The ``[start, end)`` line span of phase ``number``; error if absent or duplicated."""
    matches = [phase for phase in phases if phase.number == number]
    if not matches:
        raise RoadmapCursorError(f"Phase {number} not found.", kind="not_found")
    if len(matches) > 1:
        raise RoadmapCursorError(f"Phase {number} is duplicated.", kind="duplicate")
    return matches[0].start, matches[0].end


def find_task(phases: tuple[PhaseEntry, ...], task_id: str) -> TaskEntry:
    """Locate a task by its ``N.M`` id; error if absent or duplicated."""
    matches = [task for phase in phases for task in phase.tasks if task.id == task_id]
    if not matches:
        raise RoadmapCursorError(f"Task {task_id} not found.", kind="not_found")
    if len(matches) > 1:
        raise RoadmapCursorError(f"Task {task_id} is duplicated.", kind="duplicate")
    return matches[0]


def _last_content_line(lines: list[str], start: int, end: int) -> int:
    """Index of the last non-blank line in ``[start, end)`` — where the marker lands."""
    for index in range(end - 1, start - 1, -1):
        if lines[index].strip():
            return index
    return start


def _append_marker(line: str, marker: str) -> str:
    """Append ``marker`` before the line's trailing newline (if any)."""
    if line.endswith("\n"):
        return f"{line[:-1]}{marker}\n"
    return f"{line}{marker}"


def render_marked(
    lines: list[str], task: TaskEntry, date: str, unverified: str | None
) -> list[str]:
    """Return a new line list with the DONE marker appended to ``task``'s last line."""
    template = UNVERIFIED_TEMPLATE if unverified else MARKER_TEMPLATE
    marker = template.format(phase=task.phase, task_id=task.id, reason=unverified, date=date)
    target = _last_content_line(lines, task.start, task.end)
    updated = list(lines)
    updated[target] = _append_marker(updated[target], marker)
    return updated


def _unparseable_headings(lines: list[str]) -> list[str]:
    """Lines that open a phase heading but fail the ``## Phase N:`` grammar."""
    findings: list[str] = []
    for index, line in enumerate(lines):
        if line.startswith(PHASE_HEADING_PREFIX) and not PHASE_HEADING_RE.match(line):
            findings.append(f"line {index + 1}: unparseable phase heading: {line.strip()}")
    return findings


def _duplicate_numbers(phases: tuple[PhaseEntry, ...]) -> list[str]:
    """Phase numbers that appear more than once in the active roadmap."""
    seen: set[int] = set()
    findings: list[str] = []
    for phase in phases:
        if phase.number in seen:
            findings.append(f"phase {phase.number}: duplicate phase number")
        seen.add(phase.number)
    return findings


def _task_findings(phases: tuple[PhaseEntry, ...]) -> list[str]:
    """Duplicate task ids, phase-mismatched ids, and zero-task non-deferred phases."""
    findings: list[str] = []
    seen: set[str] = set()
    for phase in phases:
        if not phase.tasks and not phase.deferred:
            findings.append(f"phase {phase.number}: no tasks and not deferred")
        for task in phase.tasks:
            if task.id in seen:
                findings.append(f"task {task.id}: duplicate task id")
            seen.add(task.id)
            if task.phase != phase.number:
                findings.append(f"task {task.id}: id phase != enclosing phase {phase.number}")
    return findings


def verify(phases: tuple[PhaseEntry, ...], lines: list[str]) -> list[str]:
    """Return every structural finding (empty list means the roadmap is well-formed)."""
    empty = ["roadmap: no ## Phase headings found"] if not phases else []
    return (
        empty + _unparseable_headings(lines) + _duplicate_numbers(phases) + _task_findings(phases)
    )

# Roadmap (active backlog)

> **Grammar reference.** `scripts/roadmap_cursor.py` is the single reader *and* writer of
> this file's phase/task/DONE shape. Match the forms below exactly or the cursor cannot
> find your next task. `make roadmap-verify` doctors the file for drift and is part of
> every phase gate — run it after any hand edit.

## Status convention

Tasks are **never deleted** — completing one preserves the historical record. A finished
task is marked by appending `— ✅ DONE (phase-N.task-M, YYYY-MM-DD)` to its title line.
Prefer `roadmap_cursor.py --mark N.M --date YYYY-MM-DD` over hand-editing, so the written
marker always parses back.

The loop is **stateless**: these DONE markers are the only record of progress. There is no
side state file, no cursor position, nothing to reconcile after a crash. A task is done iff
its marker is committed — which is why the loop commits every task individually.

## Definition of Done

Edit this section to your own bar; `/expand-linear-next` reads it and enforces it per task.
A task is done only when: (1) the code change is in place, (2) a test asserts the new
behaviour **including the failure path**, (3) `make check` is green, and (4) any docs the
change invalidates are updated. State the task's one-line acceptance criterion in the
commit body.

---

## Active phases

## Phase 1: Short imperative phase title (risk: L)

> **Spec:** one short paragraph of context — why this phase exists, what problem it closes,
> and anything the implementer would otherwise have to reverse-engineer. The skill reads
> this before the tasks, so background that prevents a wrong guess belongs here.

- **1.1 — Task title, stated as the change to make, not the problem to solve.** One or two
  sentences of detail: which module, which existing helper to reuse, which paradigm to
  follow. **Acceptance (failure path first):** the single observable condition that proves
  this task is done — a named test asserting the error case, then the happy path.

- **1.2 — Second task.** Tasks within a phase run sequentially, each getting its own commit
  and its own full `make check`. Keep them independently completable: if 1.2 cannot start
  until 1.1 lands, that's fine, but if it depends on something *outside* this roadmap that
  doesn't exist yet, the skill will emit `HALT blocked-prerequisite` and the loop will skip
  ahead to the next phase rather than guess.

## Phase 2: The next phase (risk: M)

> **Spec:** …

- **2.1 — …** **Acceptance:** …

---

## Grammar rules the cursor enforces

| Element | Exact form | Notes |
|---|---|---|
| Phase heading | `## Phase <N>: <title>` | `N` an integer. A `## Phase` line that doesn't match this is flagged by `--verify`. |
| Task bullet | `- **<N>.<M> — <title>` | `N` **must** equal the enclosing phase number. Bold, em-dash. |
| Task block | everything up to the next bullet/heading/rule | Multi-line detail is fine; keep it indented. |
| DONE marker | ` — ✅ DONE (phase-<N>.task-<M>, <YYYY-MM-DD>)` | Appended to the block's **last** line by `--mark`. |
| Unverified marker | ` — ✅ DONE ⚠️ UNVERIFIED (phase-<N>.task-<M>, <reason>, <date>)` | Written by the loop when a task's own `make check` was red but the work was committed as visible debt. Review these in the morning. |

Phases are selected in ascending numeric order; the next phase is the lowest-numbered one
with at least one unmarked task. Completed phases can be moved verbatim into an archive
file to keep this one small — the cursor only reads what's here.

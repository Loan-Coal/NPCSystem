#!/usr/bin/env python3
"""Classify a red make-gate failure as auto-fixable or halt-worthy (token-free).

The overnight loop (`scripts/expand_loop.sh`) runs `make check` + `make
principles` as its phase gate. When that gate goes red this script decides
whether the failure is safe for an unsupervised LLM repair or must halt for a
human — the safety-critical routing decision, kept in deterministic Python so an
LLM can never talk its way past it.

Two failure classes:
  - HALT-class  — unit tests, integration tests, schema-check. A red test almost
    always means the code's logic is wrong; "fixing" it tends to weaken the test
    and commit a real bug. These never trigger an auto-fix.
  - AUTOFIX-class — ruff lint/format, mypy typecheck, structural principles.
    Objective, mechanical, and cheap to verify.

The HALT-class checks are run FIRST and short-circuit: if any is red the verdict
is HALT immediately (and the slow checks after it are skipped). Crucially, this
means an auto-fix is dispatched only after every test has been proven green, so
the repair cannot be masking a red test. If all HALT-class checks pass, the
AUTOFIX-class checks identify exactly what to repair.

Emits one machine-readable `VERDICT:` line on stdout (parsed by the loop) and,
for an AUTOFIX verdict, writes the failing checks' output to the `--report` path
so the bounded repair session knows precisely what to fix.

Baseline mode (for the tolerant per-task loop) is additive and leaves the
`VERDICT:` contract untouched. `--write-baseline PATH` seeds PATH at a phase
boundary with the union of `--seed-runs` halt-class runs. `--baseline PATH`
additionally diffs the current failing set against PATH — emitting a second
`NEW_FAILURES=…` line that distinguishes a task-introduced regression from a
pre-existing red — after re-running the candidate-new ids to weed out flakes.
That diff never writes PATH: it is idempotent, so a task that classifies twice
gets the same verdict both times instead of diffing against its own breakage.
The set math lives in `scripts/gate_baseline.py`, the re-run confirmation in
`scripts/gate_confirm.py`, and the two operations in `scripts/gate_attribution.py`.

Usage:
  python scripts/classify_gate_failure.py --report /tmp/autofix.txt
  python scripts/classify_gate_failure.py --write-baseline /tmp/baseline.json
  python scripts/classify_gate_failure.py --report /tmp/autofix.txt --baseline /tmp/baseline.json
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

# Run directly (`python scripts/classify_gate_failure.py`) Python puts scripts/ on
# sys.path[0], not the repo root, so the `scripts.` package import below needs the
# repo root added explicitly — the same pattern the unit tests use.
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from scripts.gate_attribution import (  # noqa: E402
    DEFAULT_SEED_RUNS,
    attribute,
    format_attribution_line,
    format_seed_line,
    seed_baseline,
)
from scripts.gate_baseline import collect_failing_set  # noqa: E402
from scripts.gate_confirm import pytest_rerun  # noqa: E402

# Per-check wall-clock cap. Matches the loop's own `make check` timeout so a
# hung check is killed and treated as a failure rather than stalling the gate.
CHECK_TIMEOUT_SECS = 900

# Failure-class tags.
HALT = "halt"
AUTOFIX = "autofix"

Verdict = Literal["AUTOFIX", "HALT"]


@dataclass(frozen=True)
class Check:
    """One gate sub-check: a name, the command to run it, and its failure class."""

    name: str
    cmd: tuple[str, ...]
    klass: str


@dataclass(frozen=True)
class CheckResult:
    """Outcome of running one check."""

    name: str
    passed: bool
    output: str


@dataclass(frozen=True)
class Classification:
    """The routing decision plus the checks and reason behind it."""

    verdict: Verdict
    checks: tuple[str, ...]
    reason: str


Runner = Callable[[Check], CheckResult]

# HALT-class first: a red test short-circuits before the cheap detectors run, and
# reaching the AUTOFIX phase therefore proves every test is green.
HALT_CHECKS: tuple[Check, ...] = (
    Check("schema-check", ("uv", "run", "python", "scripts/export_schema.py", "--check"), HALT),
    Check("unit-test", ("uv", "run", "pytest", "tests/unit", "-q", "-m", "not integration"), HALT),
    Check("integration-test", ("uv", "run", "pytest", "tests/integration", "-q"), HALT),
)
AUTOFIX_CHECKS: tuple[Check, ...] = (
    Check("principles", ("uv", "run", "python", "scripts/check_principles.py"), AUTOFIX),
    Check("ruff-check", ("uv", "run", "ruff", "check", "."), AUTOFIX),
    Check("ruff-format", ("uv", "run", "ruff", "format", "--check", "."), AUTOFIX),
    Check("typecheck", ("uv", "run", "mypy", "core/", "agents_src/"), AUTOFIX),
)


def run_check(check: Check) -> CheckResult:
    """Run one check as a subprocess; passed iff it exits 0 (a timeout is a failure)."""
    try:
        proc = subprocess.run(
            list(check.cmd), capture_output=True, text=True, timeout=CHECK_TIMEOUT_SECS
        )
    except subprocess.TimeoutExpired:
        return CheckResult(check.name, False, f"timed out after {CHECK_TIMEOUT_SECS}s")
    return CheckResult(check.name, proc.returncode == 0, (proc.stdout + proc.stderr).strip())


def _failures(checks: tuple[Check, ...], runner: Runner, stop_at_first: bool) -> list[CheckResult]:
    """Run checks in order, collecting failures; stop after the first if asked."""
    failures: list[CheckResult] = []
    for check in checks:
        result = runner(check)
        if not result.passed:
            failures.append(result)
            if stop_at_first:
                break
    return failures


def evaluate(runner: Runner) -> tuple[list[CheckResult], list[CheckResult]]:
    """Return (halt_failures, autofix_failures); short-circuit on the first halt-class red."""
    halt_failures = _failures(HALT_CHECKS, runner, stop_at_first=True)
    if halt_failures:
        return halt_failures, []
    return [], _failures(AUTOFIX_CHECKS, runner, stop_at_first=False)


def evaluate_full(
    runner: Runner,
) -> tuple[list[CheckResult], list[CheckResult], list[CheckResult]]:
    """Baseline-mode evaluate: run EVERY halt-class check (no short-circuit).

    The failing-set diff needs the complete halt-class picture — a short-circuit on the
    first red would hide the rest of the failing tests from attribution — so this trades
    the short-circuit speed-up for completeness. Returns the full halt results too, so the
    caller can build the failing set. Verdict routing is unchanged: any halt-class red
    still forbids the autofix phase.
    """
    halt_results = [runner(check) for check in HALT_CHECKS]
    halt_failures = [r for r in halt_results if not r.passed]
    if halt_failures:
        return halt_results, halt_failures, []
    return halt_results, [], _failures(AUTOFIX_CHECKS, runner, stop_at_first=False)


def decide(halt_failures: list[CheckResult], autofix_failures: list[CheckResult]) -> Classification:
    """Pure routing rule over the two failure lists."""
    if halt_failures:
        names = tuple(r.name for r in halt_failures)
        return Classification("HALT", names, f"halt-class check red: {','.join(names)}")
    if autofix_failures:
        names = tuple(r.name for r in autofix_failures)
        return Classification("AUTOFIX", names, f"auto-fixable check(s) red: {','.join(names)}")
    # Gate was red upstream but every reclassification check now passes — a flake or
    # an environment blip. Halt rather than turn an LLM loose with nothing to fix.
    return Classification("HALT", (), "gate red but all checks now pass (flake) — halting")


def write_report(path: str, failures: list[CheckResult]) -> None:
    """Write the failing checks' captured output for the repair session to read."""
    blocks = ["# Auto-fixable gate failures to repair\n"]
    for result in failures:
        blocks.append(f"\n## {result.name}\n\n```\n{result.output}\n```\n")
    Path(path).write_text("".join(blocks), encoding="utf-8")


def _run_halt_once() -> list[tuple[str, bool, str]]:
    """Run every halt-class check once, as the (name, passed, output) triples seeding wants."""
    return [(r.name, r.passed, r.output) for r in (run_check(check) for check in HALT_CHECKS)]


def _emit_baseline_diff(halt_results: list[CheckResult], baseline_path: str) -> None:
    """Attribute the current halt-class red against the stored baseline and emit it.

    Read-only: unlike the carry-forward this replaced, it leaves the baseline exactly as
    the phase seeded it, so re-running the classifier within a task cannot turn that
    task's own regression into pre-existing debt.
    """
    current = collect_failing_set((r.name, r.passed, r.output) for r in halt_results)
    print(format_attribution_line(attribute(current, baseline_path, pytest_rerun)))


def parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse the CLI arguments."""
    parser = argparse.ArgumentParser(description="Classify a red make-gate failure.")
    parser.add_argument("--report", help="Write AUTOFIX failing-check output to this path.")
    parser.add_argument(
        "--baseline",
        help="Diff the halt-class failing set against this baseline file and emit "
        "NEW_FAILURES=… . Distinguishes a task-introduced regression from a pre-existing "
        "red; candidate-new ids are re-run before being reported. Never writes the file.",
    )
    parser.add_argument(
        "--write-baseline",
        help="Seed the baseline file with the union of --seed-runs halt-class runs and exit "
        "(emits BASELINE_SEEDED=…). Run once per phase, before the phase's first task.",
    )
    parser.add_argument(
        "--seed-runs",
        type=int,
        default=DEFAULT_SEED_RUNS,
        help=f"Halt-class runs to union when seeding (default {DEFAULT_SEED_RUNS}). More runs "
        "catch more load-dependent flakes at the cost of a full run each.",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    """Classify the current gate state and print the machine-readable verdict."""
    args = parse_args(argv)
    if args.write_baseline:
        print(format_seed_line(seed_baseline(args.write_baseline, _run_halt_once, args.seed_runs)))
        return 0
    halt_results: list[CheckResult] | None = None
    if args.baseline:
        halt_results, halt_failures, autofix_failures = evaluate_full(run_check)
    else:
        halt_failures, autofix_failures = evaluate(run_check)
    classification = decide(halt_failures, autofix_failures)
    if classification.verdict == "AUTOFIX" and args.report:
        write_report(args.report, autofix_failures)
    print(
        f"VERDICT: {classification.verdict} "
        f"checks={','.join(classification.checks)} reason={classification.reason}"
    )
    if halt_results is not None:
        _emit_baseline_diff(halt_results, args.baseline)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

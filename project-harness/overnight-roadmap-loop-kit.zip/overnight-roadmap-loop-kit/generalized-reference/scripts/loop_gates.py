"""Gate sub-check definitions — THE ONE FILE TO EDIT for a new project.

`make check` is a single pass/fail command, which is not enough for the overnight loop:
when it goes red the loop has to decide whether the failure is *auto-fixable* (style,
types, structure — worth one bounded repair session) or *HALT-class* (a real test or
schema failure — never auto-fixed, always escalated to a human). To decide that it
re-runs the gate's constituent checks individually, and those constituents are
necessarily project-specific.

That is all this module holds. Everything below is data, not logic: a name plus the
argv to run it. Add, remove, or rewrite entries to match your project's gate.

Classification rule of thumb:
  HALT-class    — anything asserting *behaviour*. A red test means the code is wrong;
                  a repair session would be guessing at intent, and a "fix" that edits
                  the test to pass is exactly the gaming scan_fix_diff.py exists to
                  catch. Escalate to the human instead.
  AUTOFIX-class — anything asserting *form*. Lint, formatting, type annotations and
                  structural rules have mechanical, verifiable fixes with no behaviour
                  change, so one bounded repair attempt is safe and usually lands.

HALT checks run first: a red test short-circuits before the cheap form checks run, so
reaching the AUTOFIX phase at all proves every test is already green.

The defaults below describe a standard uv + ruff + mypy + pytest layout. Drop the
`("uv", "run")` prefix if you invoke tools directly, and keep the paths in step with
your own source and test directories.
"""

from __future__ import annotations

# Each entry is (check_name, argv). The name is what the loop logs and what appears in
# human_verification.md, so make it readable.
HALT_CHECK_SPECS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("unit-test", ("uv", "run", "pytest", "tests/unit", "-q", "-m", "not integration")),
    ("integration-test", ("uv", "run", "pytest", "tests/integration", "-q")),
)

AUTOFIX_CHECK_SPECS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("principles", ("uv", "run", "python", "scripts/check_principles.py")),
    ("ruff-check", ("uv", "run", "ruff", "check", ".")),
    ("ruff-format", ("uv", "run", "ruff", "format", "--check", ".")),
    ("typecheck", ("uv", "run", "mypy", "src/")),
)

# Directories check_principles.py walks for structural violations (file/function length,
# nesting depth, bare raises, swallowed excepts, print()). Must be real directories in
# the repo root; a missing one is skipped silently, which is how a typo here turns the
# structural gate into a no-op — keep it in step with your layout.
SCAN_ROOTS: tuple[str, ...] = ("src", "scripts")

# Test-file prefix. scan_fix_diff.py flags a repair session that touched a test as
# potential gate-gaming: making a red test green by editing the test is the single most
# likely way an autofix attempt "passes" without fixing anything.
TEST_DIR_PREFIX = "tests/"

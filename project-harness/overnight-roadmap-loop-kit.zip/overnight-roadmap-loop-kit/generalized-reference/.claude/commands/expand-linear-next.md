---
description: Run the next not-yet-done phase of project_harness/ROADMAP.md LINEARLY in a single agent — no subagents, no worktrees, no branches, no cherry-picks. Tasks run sequentially on the current branch, one commit per task (its ROADMAP DONE marker included), with a full `make check` after each. Built for the unattended overnight loop where reliability beats wall-clock. Stateless — ROADMAP DONE markers are the only source of truth, so it resumes cleanly in a fresh session for any current or future phase.
argument-hint: "[status | phase N]   (no arg = run the next phase; --auto = push + emit status tokens; --single-task = implement one task and stop)"
---

# /expand-linear-next — linear, single-agent phase runner (no parallelism)

You implement **ONE** phase of `project_harness/ROADMAP.md` per invocation — the next phase that still has
unfinished tasks — then STOP. Within the phase you implement tasks **sequentially in your own
context**: no sub-agents, no `Agent` tool, no worktrees, no separate branches, no cherry-picks.
Every change lands directly on the branch that is already checked out (the "current branch").

This is the **stability-first** sibling of `/expand-next`. It trades the parallel speed-up for a far
smaller failure surface, which is the right trade for the unattended nightly loop. It is
**content-agnostic and stateless**: it never hardcodes phase numbers or task lists and keeps no side
state file. Everything is derived live from `project_harness/ROADMAP.md`, whose
`— ✅ DONE (phase-N.task-M, DATE)` markers are the single source of truth.

Execute every step in order. Do not skip the DONE-marking or cleanup steps — they are what make this
resumable in a fresh session.

---

## Execution model — headless, one-shot (read this FIRST)

You run inside a single non-interactive `claude -p` turn. **There is no event loop and no human to
wake you.** Therefore:

- **Never background anything.** Do not pass `run_in_background: true`, do not poll `BashOutput`, and
  never say you will "wait for a notification" or "wait for completion." The instant you stop calling
  tools to await an async result, the turn ends and the run dies with your work **uncommitted and
  lost**. (This is the exact failure that motivated this skill — do not reintroduce it.)
- **Run every command in the foreground and block on its result.** For the slow gate, run
  `make check` in the foreground with an explicit long Bash timeout (10 minutes — `timeout: 600000`).
  The Bash tool's 2-minute default being too short is **not** a reason to background it.
- **Commit before you stop.** A task's work only survives if its commit lands (Step 3.5). If you end
  the turn with edits still in the working tree, the next run's clean-tree gate refuses them and they
  are lost. Finish the loop: implement → foreground `make check` → commit → next task → emit the
  `AUTO_STATUS:` token.

---

## The quality bar (this is the whole point — apply it relentlessly)

Every task is implemented to the **strongest** standard: the simplest, most maintainable,
paradigm-respecting change that satisfies the acceptance criterion. In priority order:

1. **Less code is better.** Prefer deleting or reusing over adding. The best diff is the smallest one
   that meets the acceptance line. Do not add a line you cannot justify against acceptance.
2. **No speculative abstraction.** Solve exactly the task — no new layers, options, flags, or
   "future-proofing" the acceptance line did not ask for. YAGNI.
3. **Follow the codebase's existing paradigms**, not generic best practice: match the surrounding
   module's structure, naming, error types, and idioms. Reuse existing helpers, constants, and
   patterns instead of introducing parallel ones.
4. **Obey every CLAUDE.md strict rule** as a hard gate, not a nicety: one responsibility per module;
   files ≤300 lines; functions ≤40 lines; nesting ≤3; no magic numbers/strings (named constants or
   config); `Literal`/`Enum` for fixed sets; Pydantic v2 at every boundary; typed exception hierarchy
   (never `raise Exception(...)`, never swallow); async I/O wrapped; `run_id` in pipeline logs;
   prompts via `load_prompt_scaffold` (never hardcoded in `.py`).
5. **Sad-path first.** The required test asserts the failure path, then the happy path — the project's
   Definition of Done demands the failure-path test.

A change that is correct but bloated, cleverly abstract, or paradigm-foreign is **not** done.

---

## Step 0 — Parse the argument

`$ARGUMENTS` selects the mode:

- **empty** → run the next phase that has unfinished tasks (default). Commit each task on the current
  branch; at the end, STOP without pushing and report.
- **`status`** → print a phase/task completion table derived from `project_harness/ROADMAP.md` (which
  phase is next, and per-phase done/total counts) and STOP. Make no changes.
- **`phase N`** → force phase `N` regardless of the cursor (resume a partially-done phase; already-`✅
  DONE` tasks are skipped).
- **`--auto`** (flag, combinable with the above) → at the end, push the current branch and emit the
  `AUTO_STATUS:` tokens for the overnight loop. Use this for the automated pipeline.
- **`--single-task`** (flag, combinable with `--auto`) → implement exactly **ONE** not-done task,
  then STOP. After the task commits green:
  - If more tasks remain in the phase: emit `AUTO_STATUS: TASK_COMPLETE phase-<N>.task-<id>` on its
    own line, then STOP.
  - If this was the last task in the phase: emit `AUTO_STATUS: PHASE_COMPLETE phase-<N>` on its own
    line, then STOP.
  - Never run the phase gate (Step 4) and never push (Step 5) — the overnight loop runs the gate
    directly in bash and handles the push after the gate passes.
  - Combine with `--auto` so the loop receives the correct `AUTO_STATUS:` tokens.

This skill **never creates a branch and never opens a PR/MR in any mode.** All work is committed on
the current branch.

---

## Step 1 — Choose the phase and load ONLY its body (stateless)

`project_harness/ROADMAP.md` holds a large backlog. Do **not** read the whole file — use the cursor
script so only the one target phase's body enters your context. `ROADMAP.md` stays the single source of
truth (its `✅ DONE` markers); the script only derives from it.

1. Capture the **current branch**: `git rev-parse --abbrev-ref HEAD`. Ensure the working tree is clean
   (`git status --porcelain` empty); if not, STOP and ask (never fold unrelated changes into a task).
2. **Pick the target phase (fast path).**
   - If a phase was arg-forced (`phase N`): `TARGET = N` (skip `--next`).
   - Else run `uv run python scripts/roadmap_cursor.py --next` in the foreground (if an `exclude
     <nums>` argument was passed, append `--exclude "<nums>"`):
     - stdout `ALL_DONE` → report completion, emit `AUTO_STATUS: ALL_DONE` on its own line, STOP.
     - stdout `PHASE=<N> TASKS=<ids> DEFERRED=<0|1>` → `TARGET = N`; `TASKS` is the phase's ordered
       not-done task ids (use it directly in Step 2). `--next` already skips curator-`⏸️ DEFERRED`
       phases (surfacing one only when nothing else is left), so `DEFERRED=1` here means *every*
       remaining phase is parked — treat it as a `blocked-prerequisite` HALT (Step 3.2), not work.
     - **any nonzero exit, or no `PHASE=`/`ALL_DONE` line** → run the **Failsafe fallback** below.
3. **Load the phase body (fast path).** Run `uv run python scripts/roadmap_cursor.py --slice <TARGET>`.
   Its stdout (the phase heading through the line before the next `## Phase`) is the **only** roadmap
   context you load — use it for Step 2's acceptance sentences and Step 3's per-task context.
   - If it exits nonzero or does not start with `## Phase <TARGET>:` → run the **Failsafe fallback**.
4. **Arg-forced-but-done.** If `phase N` was forced and the sliced body shows every task already
   `✅ DONE`, do not error: fall back to `uv run python scripts/roadmap_cursor.py --next-after N`
   (N = the forced phase; if an `exclude <nums>` argument was passed, append `--exclude "<nums>"`).
   This resumes selection **forward from the forced phase** — picking the first not-done, non-deferred
   phase numbered `>= N` — so the overnight loop force-advancing past a skipped phase never lands back
   on the earlier phase it is trying to skip. Handle its `ALL_DONE` / `PHASE=` output exactly as in
   step 2 (`ALL_DONE` here means no actionable phase remains at or after `N`).

> **Failsafe fallback (used ONLY when `roadmap_cursor.py` fails — never in the normal path).** The
> script is a context optimization, not a correctness dependency; on any failure, degrade to the
> original behavior so the run still completes:
> 1. Emit, on its own line, `ROADMAP_CURSOR_FAILSAFE: mode=<next|slice> reason="<one-line cause>"` —
>    this is **not** an `AUTO_STATUS:` token, so it cannot disturb the loop's token parser; the overnight
>    loop surfaces it to `human_verification.md` for a morning fix, and the task still proceeds.
> 2. Read `project_harness/ROADMAP.md` with the Read tool — **pass an explicit `limit` well above the
>    file's line count** (e.g. `limit: 4000`), because the default 2000-line cap would silently drop the
>    tail phases (the exact bug this script removes).
> 3. Enumerate phases by their `## Phase N:` headings in file order. A task is a `- **N.M —` item; a task
>    is **done** iff its block contains `✅ DONE`; a phase is **done** iff it has ≥1 task and all are done;
>    a phase is **deferred** iff its heading contains `⏸️`. `TARGET` = the arg-forced phase, else the first
>    not-done phase in file order **skipping deferred phases** (a deferred phase is chosen only when no
>    non-deferred not-done phase remains — mirror `compute_next`), and any `exclude <nums>` phase numbers
>    are skipped too. ALL_DONE handling and the arg-forced-but-done fallback (first not-done non-deferred
>    phase `>= N`, honoring `exclude`) are identical to steps 2 and 4 above.

---

## Step 2 — Derive the ordered task list (no batching)

For the target phase, list every **not-done** task in **ascending id order** as `{id, title, acceptance}`,
using the `--next` `TASKS=` ids and the sliced phase body from Step 1 (no re-read of the whole file):

- `id` = `N.M` from the phase number and the task's list number (already given by `TASKS=` on the fast
  path; on the failsafe path, from the enumerated body).
- `acceptance` = the task's `_Acceptance: …_` sentence (or the closest acceptance statement) in the slice.

There is no file-set inference and no batching — tasks run one after another. **Print the ordered task
list to the user before executing**, e.g. `Phase 41 tasks (linear): 41.1 → 41.2 → 41.3 → 41.4`.

---

## Step 3 — Implement each task sequentially (this is the core loop)

For each task in ascending id order, on the current branch:

1. Use the task's full context block from the **sliced phase body** (Step 1) for the precise finding,
   `file:line` evidence, and acceptance criterion — it is already loaded; do not re-read the whole
   `project_harness/ROADMAP.md` (re-run `--slice <TARGET>` if you need the body again).
2. **Prerequisite check.** If the task's acceptance criterion genuinely cannot be implemented or
   verified yet — it depends on an artifact, sibling task, or curator validation that does not exist on
   disk/in ROADMAP.md right now (e.g. it references "once phase M lands", a config/fixture another
   not-yet-done task is supposed to produce, or a human sign-off step with no recorded result) — do not
   guess or stub it out. Do not commit anything for this task. Emit
   `AUTO_STATUS: HALT blocked-prerequisite phase-<N> task-<id>` on its own line, with one sentence naming
   the specific unmet prerequisite, and STOP the phase (leave the working tree as-is for inspection, same
   as the gate-red halt below). This is distinct from `gate-red`: nothing was implemented and no gate ran
   — the task simply cannot start yet. The overnight loop treats this halt differently from the others:
   it skips ahead to the next phase for the rest of that run instead of stopping entirely, since the
   blocker is almost always transient (something that will exist tomorrow), not a defect to fix tonight.
3. Implement the change in the working tree, holding the **quality bar** above as a hard gate: the
   smallest, simplest, paradigm-respecting diff that meets acceptance; reuse existing helpers; obey
   every CLAUDE.md strict rule. **To delete a file use `git rm`, never bare `rm`.**
4. Add a test that asserts the new behaviour **including the failure path first**, then the happy path
   (project Definition of Done).
5. Run `uv run make check` **in the foreground with an explicit 10-minute Bash timeout
   (`timeout: 600000`)** — never background it or wait on a notification (see Execution model). If it
   is **red**:
   - Fix it **within this task's scope only**, same as always, until either it is green (continue to
     step 6) or you judge it cannot be made green without touching work that belongs to another task or
     a human decision.
   - Before halting, make **one bounded, classifier-gated repair attempt** — the same safety-netted path
     the overnight loop's phase gate uses, applied here instead of waiting for the phase to end (per-task
     halts are far more common than phase-wide ones, and most are a stray mechanical nit, not a real
     failure):
     a. Run `uv run python scripts/classify_gate_failure.py --report /tmp/task_autofix_report.txt` in
        the foreground and read its `VERDICT:` line.
     b. If `VERDICT: HALT` (a real unit/integration/schema-check failure): this is not mechanical — never
        attempt to reason your way past a red test with a code edit. Go straight to the **tolerant-gate
        decision (Step 3.6)** below, which either commits the work as flagged debt (the overnight default)
        or HALTs (strict mode).
     c. If `VERDICT: AUTOFIX` (only ruff/mypy/`check_principles.py` are red): repair exactly the failing
        checks named in the report, under the `/fix-make-failure` prohibitions — no
        `# type: ignore`/`# noqa`/`# pragma`/`cast(...)`; never swallow or broaden an `except`; never
        weaken a test (no deleted assertions, no deleted test files); never edit
        `scripts/check_principles.py`, `scripts/classify_gate_failure.py`, `scripts/scan_fix_diff.py`,
        `Makefile`, or `pyproject.toml`. Stage the repair and run
        `uv run python scripts/scan_fix_diff.py --staged`; a reported violation means the repair is not
        trustworthy — `git reset` it and go straight to the HALT below. Otherwise re-run
        `uv run make check` in the foreground; if it's still red, `git reset` the repair and HALT below.
     d. If the repair lands and `make check` re-runs green: continue to step 6 as normal — this is still
        the task's own commit, not a separate one. Add one line to the commit body noting the automated
        pass, e.g. `Includes an automated ruff/mypy/principles repair pass.` Then, in a **separate,
        second commit right after it** (never folded into the task commit — keep that one atomic),
        append a block to `project_harness/human_verification.md` flagging it for morning review, the
        same "AUTO-FIXED — REVIEW ME" convention the overnight loop's own phase-level auto-fix uses:
        ```
        ## AUTO-FIXED — REVIEW ME (phase-<N>.task-<id> / <checks from the VERDICT line>)
        Automated ruff/mypy/principles repair pass applied to this task's own commit <sha>.
        Diff-scanned clean and make check re-ran green, but not human-reviewed at write time.
        ```
        Commit it yourself (message: `chore(project-harness): flag phase-<N>.task-<id> autofix for
        review`) so the tree is clean before Step 6 either way — do not rely on the overnight loop to
        clean this up, since this skill also runs standalone outside it.
   - If the one AUTOFIX repair attempt is still red afterwards, `git reset` it — a stubborn autofix-class
     red is then handled by the same tolerant-gate decision (Step 3.6) as a HALT-class red.

3.6 **Tolerant-gate decision** — reached on a HALT-class red (Step 3.5.b), or a stubborn autofix-class red.
   The overnight loop's policy is *never lose a night to a red gate — accumulate small, visible, capped debt
   instead.* Read the `RED_COMMIT_TOLERANCE` environment variable:

   - **Strict** — `RED_COMMIT_TOLERANCE=0` (the loop's `--no-red-commit`), **or** you are running standalone
     (both `RED_COMMIT_TOLERANCE` and `EXPAND_BASELINE_FILE` are unset): keep the old safety. **Do not
     commit.** Emit `AUTO_STATUS: HALT gate-red phase-<N> task-<id>` on its own line, leave the working tree
     as-is for inspection, and STOP the phase. Never commit a red task in strict mode.

   - **Tolerant** (the overnight default — `RED_COMMIT_TOLERANCE` is `1` or unset while `EXPAND_BASELINE_FILE`
     is set): attribute the red deterministically — never eyeball it. Run
     `uv run python scripts/classify_gate_failure.py --report /tmp/task_autofix_report.txt --baseline "$EXPAND_BASELINE_FILE"`
     in the foreground (10-min Bash timeout) and read its `NEW_FAILURES=<n>` and `NEW_IDS=<…>` lines.
     `NEW_FAILURES` counts only failures that were absent from the phase baseline **and** reproduced on two
     consecutive id-scoped re-runs (`scripts/gate_confirm.py`); ids that did not reproduce are reported
     separately on `FLAKY_CLEARED=`/`CLEARED_IDS=` and are **not** yours. The call is read-only and
     idempotent — it never rewrites `EXPAND_BASELINE_FILE` (the loop re-seeds that once per phase), so
     running it twice gives the same verdict rather than absorbing your own new failures into the baseline.
     Then:
     - **`NEW_FAILURES=0` — pre-existing red** (the failing tests pre-date your change; you introduced none).
       Zero real debt. Commit the task now per Step 6 but with the **UNVERIFIED marker** (`baseline-red`
       reason), add the Step 3.7 flag commit, then emit
       `AUTO_STATUS: TASK_COMPLETE_BASELINE_RED phase-<N> task-<id>` on its own line and STOP.
     - **`NEW_FAILURES≥1` — regression** (your change introduced the failures listed on `NEW_IDS=`).
       Commit the task now per Step 6 with the **UNVERIFIED marker** (`regression` reason), add the Step 3.7
       flag commit naming the new ids, then emit
       `AUTO_STATUS: TASK_COMMITTED_REGRESSION phase-<N> task-<id>` on its own line and STOP.
     Committing a red-*test* tree is mechanically fine — the pre-commit hooks run only
     ruff/yaml/large-files/merge-conflict, never the suite — so the commit lands. **Never** weaken, delete,
     or `# type: ignore` a test to green the gate; the entire point is to commit the red *honestly*, marked
     and flagged. Do not push (the loop pushes at phase boundaries).

3.7 **Committed-red flag** (tolerant mode only) — a second admin commit right after the task commit, exactly
   like the autofix flag in 3.5.d, so the task commit stays atomic. Append to
   `project_harness/human_verification.md`:
   ```
   ## COMMITTED-RED — REVIEW ME (phase-<N>.task-<id> / <baseline-red|regression>)
   Task committed with a red `make check` (<failing check names>). Commit <task-sha>.
   Marked `✅ DONE ⚠️ UNVERIFIED` in ROADMAP.md — NOT human-reviewed; these failures are real and unfixed:
   <the NEW_IDS list, or "none — the red is pre-existing (baseline)">.
   ```
   Commit it (message: `chore(project-harness): flag phase-<N>.task-<id> committed-red for review`) so the
   tree is clean before you STOP.
6. When green: mark the task done via the cursor script (it owns the exact marker format, so the reader
   and writer can never drift): run
   `uv run python scripts/roadmap_cursor.py --mark <N.M> --date "$(date +%F)"`.
   - **Tolerant-gate committed-red variant (Step 3.6):** add
     `--unverified <baseline-red|regression>:<failing-check-names>` — it renders the
     `— ✅ DONE ⚠️ UNVERIFIED (phase-<N>.task-<id>, …, <today>)` form, which keeps the literal `✅ DONE`
     (so it still counts as done and is never re-attempted) while `⚠️ UNVERIFIED` makes it greppable as
     debt. The commit is otherwise identical.
   - On exit 0 (`MARKED=<N.M>` or `ALREADY_MARKED=<N.M>`) the working tree now holds the marker on the
     task's last block line — proceed to commit.
   - **Failsafe:** if `--mark` exits nonzero, do **not** abort — emit
     `ROADMAP_CURSOR_FAILSAFE: mode=mark reason="<one-line cause>"` on its own line (not an `AUTO_STATUS:`
     token), then hand-append `— ✅ DONE (phase-<N>.task-<id>, <today>)` (or the `⚠️ UNVERIFIED` variant
     above) to the **end of that task's block** in `project_harness/ROADMAP.md` — after its acceptance
     sentence, on the task's last line (not the `N.` title line), matching where existing markers sit.
     **Never delete a task line; only append.** The marker MUST land in this task's commit or the task is
     lost/re-run.
   Then make **exactly ONE commit**
   containing the code change, the test, and the ROADMAP marker:
   - Message: `<type>(phase-<N>.task-<id>): <description>`, with the one-line acceptance in the body.
   - Follow CLAUDE.md commit rules strictly: **never mention Claude, Anthropic, or any AI tool anywhere
     — no `Co-Authored-By` trailer, no body references.**
   - Folding the DONE marker into the task commit makes resumption atomic: a task is done iff its commit
     landed, so a crash mid-phase resumes cleanly at the next unfinished task.
7. **If `--single-task` was passed:** STOP immediately after this commit.
   - Count remaining not-done tasks in the phase (any task whose lines do not contain `✅ DONE`
     beyond the one just committed).
   - If tasks remain: emit `AUTO_STATUS: TASK_COMPLETE phase-<N>.task-<id>` on its own line, then STOP.
   - If this was the last task (phase now fully done): emit `AUTO_STATUS: PHASE_COMPLETE phase-<N>`
     on its own line, then STOP.
   - **If the task committed red via the tolerant gate (Step 3.6):** you already emitted
     `TASK_COMPLETE_BASELINE_RED` or `TASK_COMMITTED_REGRESSION` there — that token *replaces* the
     `TASK_COMPLETE`/`PHASE_COMPLETE` one (even if it was the phase's last task). Do not emit a second
     token. The loop no longer infers phase completion from which token you chose: it reads the ROADMAP
     via `roadmap_cursor.py --next-after <N>` after every committed task and runs the phase boundary
     (gate, review, push, `--max-phases` count, baseline re-seed) whenever the phase has no task left.
     Both tokens must still name the phase (`phase-<N>`) so the loop knows which phase to check.
   - Do not run the phase gate. Do not push. Report the commit SHA and the acceptance line satisfied.
8. Continue to the next task.

---

## Step 4 — Phase gate

**If `--single-task` was passed, skip this step entirely.** The phase gate is run by the overnight
loop directly in bash (`uv run make check` then `uv run make principles`) after it observes
`AUTO_STATUS: PHASE_COMPLETE`. Proceed to Step 5.

After all tasks in the phase are committed green, run the full gate on the current branch:
`uv run make check`, `uv run make principles`, **and** `uv run make roadmap-verify` (the last one
doctors `ROADMAP.md` for cursor-parse drift — duplicate/malformed phases or bad task ids — so a
selection-breaking edit is caught the moment it lands).

- If red: emit `AUTO_STATUS: HALT gate-red phase-<N>` on its own line, STOP, and report. The committed
  task work stays (already DONE-marked); re-run later via `phase N` to address what the phase-wide
  gate caught. Do not push.
- If green: continue.

---

## Step 5 — Publish and stop

1. **If `--single-task` was passed:** do not push regardless of `--auto`. Push is handled by the
   overnight loop after the phase gate passes. Proceed to Step 6.
2. **If `--auto` was NOT passed:** STOP. Report the per-task commit SHAs, the gate result, and how to
   continue — run `/expand-linear-next` again for the next phase (or `/expand-linear-next status`).
   Do not push.
2. **If `--auto` was passed:** push the current branch (`git push origin <current_branch>`).
   - **If the push fails** for any reason (non-fast-forward because the remote advanced, an auth/proxy
     failure, or any non-zero `git push` exit): do NOT retry with `--force` and do NOT rebase. Emit
     `AUTO_STATUS: HALT push-failed phase-<N>` on its own line and STOP, leaving the commits on the
     local branch for a human to reconcile. Report the exact `git push` error.
   - **On success:** emit `AUTO_STATUS: PHASE_COMPLETE phase-<N>` on its own line, then STOP. Report the
     per-task commit SHAs, the gate result, and the push result. No PR/MR is opened.

---

## Step 6 — Self-maintenance (always run, even on early stop)

Before ending ANY invocation, confirm the repo is left clean and on the **current branch** you started
on (`git rev-parse --abbrev-ref HEAD` unchanged; `git status --porcelain` empty except a deliberate
HALT's uncommitted work). Because the skill is stateless, this plus the ROADMAP DONE markers is all a
fresh session needs to resume with `/expand-linear-next`.

---

## Invariants

- One phase per invocation. Never auto-advance into the next phase.
- Tasks run **sequentially in this agent** — never spawn a sub-agent, create a worktree, create a
  branch, or cherry-pick. All work lands on the current branch.
- One commit per task, and that commit includes the task's ROADMAP `✅ DONE` marker — a task-level
  autofix (Step 3.5.d) adds one *extra* administrative commit flagging it for review, never folded
  into the task's own commit and never a substitute for it.
- Never commit or mark DONE a task whose `make check` is red **in strict mode** (`--no-red-commit`, or a
  standalone run with no `EXPAND_BASELINE_FILE`). In the overnight loop's default **tolerant** mode a
  HALT-class red instead commits the work with a `✅ DONE ⚠️ UNVERIFIED` marker plus a committed-red flag,
  and emits `TASK_COMPLETE_BASELINE_RED` (failures pre-date the task) or `TASK_COMMITTED_REGRESSION`
  (task-introduced) per Step 3.6 — never by weakening, deleting, or ignoring a test.
- Never delete a task line from `project_harness/ROADMAP.md`; only append the DONE marker.
- A failed `--auto` push HALTs the phase (`push-failed`) — never force-push and never rebase
  automatically.
- A task blocked on an unmet prerequisite HALTs the phase (`blocked-prerequisite`, Step 3.2) before any
  implementation is attempted — never guess, stub, or partially implement around a missing dependency.
- A `phase N` argument for an already-fully-done phase is not an error — fall back to the first
  not-done, non-deferred phase numbered `>= N` (Step 4, via `--next-after N`). The overnight loop
  relies on this to force past a `blocked-prerequisite` phase without needing to know in advance
  whether the next one is finished — and the forward-from-`N` selection is what stops the fallback
  from re-selecting the earlier phase being skipped.
- In `--single-task` mode, implement exactly one task per invocation — never continue to the next
  task, run the phase gate, or push. Emit `AUTO_STATUS: TASK_COMPLETE phase-<N>.task-<id>` if tasks
  remain, or `AUTO_STATUS: PHASE_COMPLETE phase-<N>` if the phase is now fully done — or, when the task
  committed red via the tolerant gate, the `TASK_COMPLETE_BASELINE_RED` / `TASK_COMMITTED_REGRESSION`
  token from Step 3.6 instead (never both).
- Commits never mention Claude/Anthropic/any AI tool — no `Co-Authored-By` trailers (per CLAUDE.md).
- Hold the quality bar above as a gate: minimal, simple, paradigm-respecting code; less is better.

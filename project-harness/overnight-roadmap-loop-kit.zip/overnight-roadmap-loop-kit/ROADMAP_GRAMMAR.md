# The roadmap format

`scripts/roadmap_cursor.py` is the single reader **and** writer of this format. Nothing else
parses the roadmap — the loop and the skill both go through the cursor. Keep it that way when
porting: the one-parser rule is why the format has stayed stable while everything around it
changed.

`_roadmap_cursor_core.py` holds the pure functions (parse, find, slice, mark, verify); the CLI
is a thin wrapper. Port both together.

---

## The grammar

| Element | Exact form | Notes |
|---|---|---|
| Phase heading | `## Phase <N>: <title>` | `N` an integer. Selected in ascending numeric order. |
| Task bullet | `- **<N>.<M> — <title>` | `N` **must** match the enclosing phase. Bold, em-dash `—`. |
| Task block | the bullet through to the next bullet, sub-heading, horizontal rule, or phase heading | Multi-line detail is fine. |
| DONE marker | ` — ✅ DONE (phase-<N>.task-<M>, <YYYY-MM-DD>)` | Appended to the **last line** of the task's block. |
| Unverified marker | ` — ✅ DONE ⚠️ UNVERIFIED (phase-<N>.task-<M>, <reason>, <date>)` | Written by the loop when a task's own gate was red but the work was committed as visible debt (§6.5 of HOW_IT_WORKS). Review these in the morning. |

A phase is unfinished if it has at least one task block containing no `✅ DONE`. The next phase
is the lowest-numbered unfinished one.

Note the marker is matched by the presence of the `✅ DONE` token anywhere in the task's block,
which is why the block boundary rules matter — a marker that lands in the wrong block marks the
wrong task.

---

## The CLI

```
roadmap_cursor.py --next                      # → "PHASE=N TASKS=N.M,... DEFERRED=K"  or  "ALL_DONE"
roadmap_cursor.py --next-after N              # the next unfinished phase after N
roadmap_cursor.py --slice N                   # print ONLY phase N's body
roadmap_cursor.py --mark N.M --date YYYY-MM-DD   # append the DONE marker; → "MARKED=N.M"
roadmap_cursor.py --verify                    # doctor for drift; non-zero on malformed input
```

`--slice` is what keeps the skill's context small: it loads one phase, not a 2000-line backlog.
Any port that has the skill read the whole roadmap will work at first and degrade as the backlog
grows.

`--verify` runs as part of every phase gate (`make roadmap-verify`). It catches duplicate phase
numbers, `## Phase` lines that do not match the heading regex, and task ids whose phase number
disagrees with their heading. Run it after any hand edit.

---

## Writing a roadmap the loop can actually execute

The format is the easy part. These are the properties that decide whether an unattended night
produces useful work.

**Every task needs an explicit acceptance criterion.** One observable condition that proves the
task is done. Without it the model decides for itself when to stop, and it stops early. The
source project writes them failure-path-first: *"a named test asserts the error case, then the
happy path."*

**Tasks should be independently completable.** Sequential dependency within a phase is fine
(1.2 after 1.1). A dependency on something *outside* the roadmap that does not exist yet is not:
the skill will emit `HALT blocked-prerequisite` rather than guess, and the loop skips the phase.
That is the correct behaviour, but a roadmap full of external blockers drains a night into skips.

**Put context in the phase spec, not the task.** Each phase gets a `> **Spec:**` block. Anything
the implementer would otherwise have to reverse-engineer — why the phase exists, which module
owns the concern, what was already tried — belongs there. The skill reads it before the tasks.

**Size a task to one session.** Roughly one focused commit. Too large and the 90-minute timeout
kills it mid-way; too small and you spend more on session overhead than on work.

**Never delete a completed task.** The DONE markers are the progress record (§1 of
HOW_IT_WORKS). Move finished phases verbatim into an archive file if the active file gets long —
the cursor only reads what is present.

**Prefer `--mark` to hand-editing.** A hand-written marker that does not parse back is invisible
to the cursor, and the task will be implemented again on the next run.
